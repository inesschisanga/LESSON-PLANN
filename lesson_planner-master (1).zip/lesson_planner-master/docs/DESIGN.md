# Design System

## Design Goal
Create a calm, professional education-focused interface that helps teachers concentrate on lesson-plan preparation and review without unnecessary visual complexity.

The product is primarily a productivity application, not a marketing website. Clarity, hierarchy, form usability, review status visibility, and accessibility take priority over decoration.

## Design Principles
1. **Teacher-first** — optimize for fast lesson-plan work.
2. **Structured** — lesson-plan sections should be visually easy to scan.
3. **Consistent** — the same action/status should look and behave the same everywhere.
4. **Calm** — avoid excessive gradients, animation, glass effects, and visual noise.
5. **Transparent AI** — AI content must look like assistance, not authoritative teacher content.
6. **Accessible** — keyboard navigation, labels, contrast, and focus states are required.
7. **Responsive** — usable on common laptops and tablets; core flows should remain functional on mobile browsers.

## Visual Direction
Use a clean academic dashboard style inspired by compact finance/workflow dashboards:
- Soft near-white canvas with bright white surfaces.
- Emerald actions and mint active states that feel calm rather than fluorescent.
- Compact navigation rail with a clear page-context header.
- Inter-style typography with strong numeric hierarchy.
- Flat bordered surfaces and generous rounded panels; avoid decorative drop shadows.
- Status communicated by text + icon/color, never color alone.

## Brand Colors
No formal institutional/product brand palette was specified in the proposal. Use these as **provisional UI tokens** until branding is approved:

```text
Primary:        #078B5C
Primary Hover:  #056B47
Background:     #F5F7F6
Surface:        #FFFFFF
Mint Surface:   #E3F5ED
Text:           #14140F
Muted Text:     #6E6E64
Border:         #E4E9E6
Success:        #15803D
Warning:        #B45309
Danger:         #B91C1C
Info:           #0369A1
```

Do not scatter raw hex values through views. Define tokens through Tailwind/theme configuration so branding can be changed centrally.

## Typography
Use Inter as the primary UI font, with Aptos/Segoe UI/system fallbacks.

Recommended hierarchy:
- Page title: 28–32px, semibold/bold.
- Section title: 20–24px, semibold.
- Card title: 16–18px, semibold.
- Body: 14–16px.
- Helper/meta text: 12–14px.

Rules:
- Avoid long all-caps headings.
- Keep line length comfortable for lesson-plan content.
- Use font weight and spacing before adding decorative separators.

## Spacing
Use a consistent 4px-based spacing scale.

Common spacing:
- 4px: compact icon/text gap.
- 8px: small internal spacing.
- 12–16px: normal control spacing.
- 20–24px: card padding.
- 32px+: major section separation.

Do not invent arbitrary spacing for each page.

## Layout
### Application Shell
Desktop:
- Persistent compact sidebar with workspace icons, profile, and sign-out actions.
- Page-context header below the navigation.
- Main content area with readable max width where appropriate.

Mobile/tablet:
- Sidebar becomes a slide-over drawer opened from a menu toggle, with a dismissible backdrop.
- Important actions remain easy to reach.

### Main Navigation
Recommended items:
- Dashboard
- My Lesson Plans
- Peer Reviews

Profile and sign-out belong in the top account control rather than the workspace sidebar.

Admin-only items should appear only for authorized users.

## Dashboard
Dashboard should answer:
- What am I working on?
- What needs my attention?
- What reviews are waiting?

Suggested blocks:
- Draft lesson plans.
- Submitted/under-review plans.
- Reviews assigned to me.
- Recently updated plans.

Avoid vanity metrics with no workflow value.

## Lesson-Plan Editor
This is the most important screen.

Recommended structure:
- Header with title/status/save state.
- Section navigation or progress indicator matching the service-derived CBC structure.
- Main structured form.
- A distinct generated-draft review state before content is saved.
- Contextual AI assistance panel or inline suggestion area for later refinements.
- Save Draft / Submit for Review actions separated by importance.
- Export to Word as a secondary action after a valid plan exists.

Long-form lesson notes use spacious plain textareas with clear placeholders and the existing field names, so drafts, generated plans, and revisions share the same persistence path without adding a separate editor dependency.

### Editor Sections
Use the service-derived grouping:
1. Lesson information — school, teacher, date, class, ICT subject, duration, topic, lesson, and enrollment.
2. Competence and purpose — general competence, specific competence, lesson goal, rationale, and prior knowledge.
3. Preparation — references, natural/artificial learning environment, teaching materials, and expected standards.
4. Teaching and learning activities — Introduction, Lesson Development, Class Exercise, Conclusion, and Homework.
5. Lesson evaluation.

Avoid one visually overwhelming form if sections can be grouped clearly.

## AI Assistance UI
AI must be visually identifiable.

The complete generated result should open in a review state that shows:
- `AI-generated draft` label/icon.
- All generated sections in the same structure as the manual editor.
- Any missing or invalid sections called out near the affected field.
- Actions such as `Edit draft`, `Save as draft`, or `Discard`.

Rules:
- Never persist AI text as the official lesson plan without explicit teacher confirmation.
- Keep the original generation inputs visible or easy to revisit.
- Never use wording such as “Correct answer” for subjective pedagogical suggestions.
- Show loading state while generating.
- Show recoverable error state if AI is unavailable.
- Avoid a general chatbot in MVP.

## Word Export UI
- Show `Export to Word` only when the plan has passed structural validation.
- Keep export visually secondary to save and submit actions.
- Show a progress/disabled state while the file is generated.
- Preserve activity-stage durations in the labels shown in preview and export.
- If export fails, keep the plan unchanged and provide a retry action.

## Peer Review UI
The review screen should visually separate:
- Submitted lesson-plan content.
- Review criteria.
- Reviewer comments.
- Rating/assessment controls.
- Review action/status.

A reviewer should always know which lesson-plan version is being reviewed.

### Review Criteria Pattern
Each criterion should contain:
- Criterion name.
- Short description/help text.
- Rating/control if required.
- Comment field.

Use a final overall comment before submit.

## Review Feedback UI
Teacher feedback view should include:
- Review status.
- Reviewer/date.
- Version reviewed.
- Criterion-by-criterion feedback.
- Overall feedback.
- Clear `Create Revision` action when changes are requested.

Do not edit the reviewed historical version in place.

## Status Badges
Use consistent labels:
- Draft
- Submitted
- Under Review
- Changes Requested
- Reviewed
- Revised
- Resubmitted

Each badge must include readable text; color is supplementary.

## Buttons
### Primary Button
Use for the single main action in a section/page.
Examples:
- Create Lesson Plan
- Save Changes
- Submit Review

### Secondary Button
Use for supporting actions.
Examples:
- Save Draft
- Cancel
- Download

### Destructive Button
Use only for destructive actions and require confirmation where data loss is possible.

### Button Rules
- Minimum comfortable touch target.
- Visible focus state.
- Disabled state must remain readable.
- Include spinner/loading text for async actions.
- Avoid more than one visually dominant primary action in the same local area.

## Forms
- Every input has a visible label.
- Required fields are indicated consistently.
- Helper text appears below the field when needed.
- Validation error appears close to the affected field.
- Preserve input after recoverable validation errors.
- Use textarea/editor controls appropriate to long lesson content.
- Avoid placeholder-only labels.

## Cards
Use cards only to group related information.

Recommended:
- Subtle border.
- Little or no shadow.
- 12–16px radius maximum unless design tokens change.
- Consistent padding.

Do not create a card around every small piece of content.

## Tables and Lists
Use tables for data that benefits from column comparison.
Use responsive lists/cards when tables become unusable on narrow screens.

Lesson-plan list columns may include:
- Title/topic.
- Class.
- Updated date.
- Review status.
- Actions.

Always paginate large lists.

## Modals
Use modals for short focused decisions only:
- Confirm delete.
- Confirm submission.
- Quick assignment selection.

Do not place the entire lesson-plan editor or complex review form in a modal.

## Alerts and Feedback
Use clear system feedback:
- Success: saved/submitted/review completed.
- Warning: unsaved changes, AI-generated draft disclaimer.
- Error: validation/API failure.
- Info: workflow guidance.

Auto-dismiss only low-risk success messages. Keep errors visible until acknowledged or resolved.

## Icons
- Use one icon library consistently.
- Icons supplement text for important actions; they should not replace ambiguous labels.
- Use recognizable education/document/review icons.

## Empty States
Every empty state should explain what the user can do next.

Example:
`You have no lesson plans yet. Create your first ICT lesson plan to begin.`

Provide the relevant action when authorized.

## Loading States
- Use button-level loading indicators for short actions.
- Use skeletons/spinners for longer content loads.
- AI generation must show a visible loading state and prevent duplicate requests.

## Responsive Design
### Desktop
Optimize lesson-plan editing and review for common laptop screens.

### Tablet
Keep two-column layouts only when content remains readable.

### Mobile
- Stack content.
- Make navigation compact.
- Keep form controls full width where appropriate.
- Preserve all core functionality even if dense review tasks are more comfortable on larger screens.

## Accessibility
Target practical WCAG-aligned behavior:
- Semantic HTML.
- Keyboard navigation.
- Visible focus indicators.
- Sufficient contrast.
- Form labels and error associations.
- ARIA only where semantic HTML is insufficient.
- Do not communicate status using color alone.
- Respect reduced-motion preferences.

## Motion
Use minimal motion only to explain state changes:
- Accordion expand/collapse.
- Drawer open/close.
- Toast entrance.
- AI-generated draft appearance.

Avoid decorative parallax, continuous animation, or motion that distracts from academic work.

## Dark Mode
Dark mode is optional and not required for the MVP. If introduced, it must be token-based and complete; do not ship partially styled dark screens.

## Component Guidelines
Build/reuse components for:
- Page header.
- Status badge.
- Form field/error.
- Lesson-plan section.
- AI-generated draft review panel.
- Review criterion.
- Empty state.
- Confirmation modal.
- Pagination/list controls.

## Design Rule for AI-Generated UI
Before creating a new component, check whether an equivalent component already exists. New pages must inherit the existing layout, typography, button, form, badge, spacing, and feedback patterns rather than creating a new visual language.
