# Product Requirements Document

## Project Title
**Design and Development of an AI Web-Based ICT Lesson Planning Application for Secondary Schools**

## Product Overview
The product is a web-based lesson-planning platform for secondary-school ICT teachers. It provides one place for teachers to create, upload, organize, retrieve, review, revise, and improve ICT lesson plans.

The application will be built with **Laravel** and will use **Google AI Studio / Gemini API** to generate a structured first draft and provide bounded assistance during lesson planning. AI-generated content is always an editable draft; it is not a replacement for the teacher or peer reviewer.

## Problem Statement
ICT teachers may prepare lesson plans using paper files or general-purpose word processors. This can make plans difficult to organize, retrieve, reuse, validate, and improve collaboratively.

There is also limited support for a structured lesson-plan peer-review cycle. Teachers need a focused workflow where a lesson plan can be submitted to a peer, reviewed against defined criteria, returned with feedback, revised, and resubmitted.

The proposed system addresses these problems by combining structured digital lesson planning, document management, peer review, versioning, and practical AI-assisted suggestions and validation.

## Product Goals
1. Make ICT lesson-plan creation structured and consistent.
2. Allow teachers to upload and manage existing lesson-plan documents.
3. Provide reliable storage, search, retrieval, and download of lesson plans.
4. Support a complete peer-review workflow for lesson plans.
5. Use Gemini to generate a complete, structured Zambian Competence-Based Curriculum (CBC) lesson-plan draft from teacher-supplied context and support later improvements.
6. Preserve teacher control over final lesson-plan content.
7. Provide revision history so improvement can be traced over time.
8. Keep the scope focused on ICT lesson planning for secondary schools.

## Target Users
### Primary Users
- Secondary-school ICT teachers.
- ICT teachers acting as peer reviewers.

### Secondary Stakeholders
- Heads of Department or authorized academic staff who may observe review status where permitted.
- Project evaluators/research participants testing usability and functionality.

## User Roles
### Teacher
A teacher can:
- Register and log in.
- Manage a personal profile.
- Create and edit structured lesson plans.
- Upload existing lesson-plan documents.
- View, search, download, and organize owned lesson plans.
- Generate a structured lesson-plan draft from validated inputs, then review and edit every section.
- Export a lesson plan as a Word document.
- Submit a lesson plan for peer review.
- View feedback and ratings.
- Revise and resubmit a lesson plan.
- View the version and review history of owned lesson plans.

### Peer Reviewer
A peer reviewer is also a teacher but is assigned or selected to review a submitted lesson plan. The reviewer can:
- View lesson plans assigned for review.
- Review against predefined criteria.
- Add comments and suggestions.
- Provide a rating where required.
- Submit a review decision/status.

### Administrator
For the software implementation, an administrator may be provided for essential system management only. Administration must not expand the research scope into general departmental monitoring.

An administrator may:
- Manage users where necessary.
- Manage review criteria or controlled reference data.
- Handle technical moderation or support tasks.

## Core Features

### 1. Authentication and Profiles
- Teacher registration.
- Login and logout.
- Password reset.
- Basic teacher profile management.
- Role and permission enforcement.

### 2. Structured Lesson-Plan Creation
A teacher can create a lesson plan from a structured Zambian CBC form. The service-derived template is:
- Header: school, teacher, date, class, subject, duration, topic, lesson, and enrollment split into boys and girls.
- Lesson components: general competence, specific competence, lesson goal, rationale, prior knowledge, references, natural/artificial learning-environment setup, teaching materials, and expected standards.
- Teaching and learning activities: Introduction, Lesson Development, Class Exercise, Conclusion, and Homework.
- Each activity records its duration, teacher activity, learner activity, and assessment criteria.
- Lesson evaluation.

The application remains focused on ICT. The server must enforce ICT as the subject even though the underlying service accepts a subject value. The service-derived template remains subject to validation with intended teachers.

### 3. Lesson-Plan Editing
- Save drafts.
- Update lesson-plan content.
- Preserve timestamps.
- Prevent unauthorized editing of another teacher's work.

### 4. Upload Existing Lesson Plans
- Upload permitted lesson-plan documents, including PDF and Word formats where supported.
- Store file metadata and ownership.
- Associate uploaded files with lesson-plan records.
- Enforce allowed file types and maximum file sizes.

### 5. Lesson-Plan Repository
- List owned lesson plans.
- Search by title/topic and relevant metadata.
- Filter by status/date where useful.
- View lesson-plan details.
- Download permitted files.

### 6. AI-Assisted Lesson Planning
The application will use Google AI Studio / Gemini API to generate a complete structured draft from validated teacher inputs:
- Subject, class, topic, lesson, and duration.
- Optional references, prior knowledge, teaching materials, school, and teacher.
- Zambian CBC-aligned competencies, learner-centered activities, assessment criteria, and evaluation.
- Exactly five activity stages: Introduction, Lesson Development, Class Exercise, Conclusion, and Homework.

Google AI Studio is the only supported generation provider.

AI output must be visibly labeled as generated, validated against the expected schema, and shown in an editable review step. It must not become the official saved plan until the teacher confirms it.

### 7. Word Document Export
- Export the current lesson plan as an A4 `.docx` file.
- Include the plan header, lesson components, references, learning environment, materials, expected standards, and activity table.
- Show activity duration with its stage label in preview/export output.
- Generate files temporarily on the server and deliver them through an authorized download response.
- Include lesson-evaluation content in the completed export.

### 8. Basic Validation
The system must perform deterministic validation without AI for required fields and structural rules.

Examples:
- Required lesson sections cannot be empty when submitting for review.
- Duration must be valid.
- Only supported files can be uploaded.

AI validation is supplementary and must not replace Laravel validation rules.

### 9. Peer-Review Workflow
Workflow:

`Draft -> Submitted -> Under Review -> Changes Requested or Reviewed -> Revised -> Resubmitted`

Capabilities:
- Submit a lesson plan for peer review.
- Assign/select a reviewer according to configured rules.
- Reviewer evaluates predefined criteria.
- Reviewer adds comments and suggestions.
- Reviewer provides rating if enabled.
- Review status is recorded.
- Teacher receives and views feedback.

### 10. Revision and Resubmission
- Teacher creates a new revision after feedback.
- Previous submitted versions remain preserved.
- Teacher can resubmit the revised plan.
- Review history remains associated with the relevant version.

### 11. Review History
Store:
- Submission date.
- Reviewer.
- Review status.
- Criterion scores/ratings where used.
- Comments and suggestions.
- Version reviewed.
- Review completion timestamp.

## MVP Scope
The MVP includes:
- Authentication and teacher profiles.
- Structured Zambian CBC ICT lesson-plan CRUD using the service-derived schema.
- File upload and secure storage.
- Lesson-plan repository/search.
- Gemini-powered full-draft generation with an editable teacher review step.
- Authorized Word document export.
- Peer-review submission and review form.
- Feedback and ratings.
- Status tracking.
- Version/revision and resubmission.
- Basic notifications inside the application.
- Authorization, validation, logging, and core tests.

## User Stories
### Lesson Planning
- As a teacher, I want to create a structured ICT lesson plan so that I do not have to build the format from scratch each time.
- As a teacher, I want to save a draft so that I can continue working later.
- As a teacher, I want to upload an existing lesson plan so that old work can be centralized.
- As a teacher, I want to search previous lesson plans so that I can retrieve and reuse relevant material.

### AI Assistance
- As a teacher, I want to provide the essential lesson context and receive a complete CBC-structured draft so that I can start from a relevant plan instead of a blank page.
- As a teacher, I want to inspect and edit every generated section before saving so that I retain professional control over the final plan.
- As a teacher, I want to export the reviewed plan to Word so that I can print, share, or use it offline.

### Peer Review
- As a teacher, I want to submit a plan to a peer so that I can receive structured professional feedback.
- As a reviewer, I want a consistent review form so that I can evaluate plans against the same criteria.
- As a teacher, I want to revise and resubmit a reviewed plan so that improvements are documented.

## Functional Requirements
| ID | Requirement |
|---|---|
| FR-01 | The system shall allow teachers to register, log in, log out, and reset passwords. |
| FR-02 | The system shall allow teachers to create lesson plans using a structured ICT lesson-plan template. |
| FR-03 | The system shall allow owners to edit draft and revision lesson plans. |
| FR-04 | The system shall allow supported lesson-plan files to be uploaded and stored. |
| FR-05 | The system shall allow teachers to search, view, retrieve, and download permitted lesson plans. |
| FR-06 | The system shall allow a teacher to generate a structured Zambian CBC lesson-plan draft from validated lesson context. |
| FR-07 | The system shall perform deterministic validation before submission. |
| FR-08 | The system shall allow a lesson plan to be submitted for peer review. |
| FR-09 | The system shall allow an authorized reviewer to review an assigned plan. |
| FR-10 | The system shall allow reviewers to record comments, suggestions, criterion results, and ratings. |
| FR-11 | The system shall track review statuses. |
| FR-12 | The system shall allow teachers to revise and resubmit plans after feedback. |
| FR-13 | The system shall preserve review and version history. |
| FR-14 | The system shall enforce authorization for viewing, editing, reviewing, and downloading resources. |
| FR-15 | The system shall record important system events required for traceability. |
| FR-16 | The system shall allow an authorized teacher to export a lesson plan as a `.docx` document. |
| FR-17 | The system shall validate generated AI output against the required lesson-plan schema before preview or persistence. |

## Non-Functional Requirements
### Usability
- Interface should be simple for teachers with varying levels of technical experience.
- Common actions should have clear labels and visible status feedback.

### Security
- Protect accounts and lesson-plan documents from unauthorized access.
- Keep all Google AI Studio credentials on the server only.
- Validate and sanitize all user-controlled input.
- Enforce access through Laravel policies/gates.
- Apply secure file-upload controls.

### Reliability
- Lesson plans, reviews, and versions must be stored consistently.
- Failed AI calls must not corrupt or block saved lesson-plan content.

### Performance
- Common CRUD actions should feel responsive under normal project usage.
- AI requests should have timeouts and graceful error states.

### Maintainability
- Business logic should be separated from controllers/components.
- AI generation and document export should be isolated behind dedicated service contracts.

### Accessibility
- Use semantic labels, keyboard-friendly controls, readable contrast, and visible focus states.

### File Integrity
- Uploaded files must not be modified unintentionally.
- Store generated filenames separately from original display names where appropriate.

## Out of Scope
The following are explicitly outside the project scope unless the proposal is formally changed:
- Schemes of work.
- Records of work.
- Teaching timetables.
- General departmental monitoring.
- General-purpose chat/messaging.
- Native mobile applications.
- National education-management-system integrations.
- External education databases.
- Subjects other than ICT.
- Advanced custom machine-learning model training.
- Fully autonomous saving, publication, submission, or approval of generated lesson plans without teacher review.

## Success Metrics
During project evaluation, collect evidence such as:
- Percentage of participants able to create and save a lesson plan successfully.
- Percentage able to upload and retrieve an existing lesson plan.
- Percentage able to complete the submit-review-revise-resubmit workflow.
- Task completion time for core workflows.
- Number/rate of validation failures prevented before submission.
- User-rated usefulness and editability of AI-generated lesson-plan drafts.
- Percentage able to generate, review, and export a valid lesson plan.
- User-rated usefulness of peer-review feedback.
- Usability satisfaction from evaluation participants.

Exact targets should be finalized during the research evaluation design rather than invented during implementation.

## Future Features
Only consider after the MVP and research scope are complete:
- Rubric customization by school.
- Rich analytics on common lesson-plan improvement areas.
- Optional notifications by email.
- Curriculum-aware reference libraries.
- Export to additional formats.
- Collaboration beyond the defined peer-review workflow.

## Product Constraint
Every new feature must answer this question:

> Does this directly improve ICT lesson-plan creation, management, AI-assisted preparation, peer review, revision, or retrieval?

If not, it is probably outside the current research scope.
