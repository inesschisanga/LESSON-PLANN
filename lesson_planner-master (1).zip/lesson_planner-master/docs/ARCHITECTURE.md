# System Architecture

## Architecture Overview
The application will use a **Laravel monolith with a three-tier architecture**:

1. **Presentation layer** — browser-based teacher/reviewer UI.
2. **Application layer** — Laravel business logic, authorization, peer-review workflow, AI orchestration, validation, and file management.
3. **Data layer** — MySQL database plus protected file storage.

Google AI Studio / Gemini API is the only external AI generation dependency and is accessed **only by the Laravel backend**. Word export is generated server-side.

```text
Browser
  |
  v
Laravel Web UI
  |
  +--> Application Services / Domain Actions
  |      |--> LessonPlannerService
  |      |      `--> Google AI Studio
  |      |--> LessonPlanDocxService
  |      |--> Peer Review Service
  |      |--> Versioning Service
  |      `--> AI Assistance Service
  |
  +--> MySQL
  +--> File Storage
  `--> Temporary DOCX output
```

## Technology Stack
### Backend
- PHP compatible with the selected Laravel release.
- Laravel.
- Eloquent ORM.
- Laravel validation, policies, queues, notifications, logging, and HTTP client.

### Frontend
Recommended Laravel-native stack:
- Blade.
- Livewire for interactive forms/workflows where useful.
- Alpine.js for small client-side interactions.
- Tailwind CSS for styling.

Do not introduce React, Vue, or another frontend framework unless the architecture is explicitly revised.

### Database
- MySQL.

### AI
- Google AI Studio / Gemini API as the lesson-plan generation provider.
- Laravel HTTP client behind an internal lesson-planner contract.

### Document Generation
- `LessonPlanDocxService` for server-side Word export.
- PhpOffice PhpWord is the intended document library and must be installed before export is wired.

### Version Control
- Git and GitHub.

### Deployment
Target deployment can use:
- Linux server.
- Nginx.
- PHP-FPM.
- MySQL.
- HTTPS.
- Laravel scheduler/queue worker if queued tasks are enabled.

## Frontend Architecture
UI should be organized around the main workflows:

```text
Dashboard
├── My Lesson Plans
│   ├── Create Lesson Plan
│   ├── Upload Lesson Plan
│   ├── View Lesson Plan
│   ├── Edit Draft / Revision
│   └── Review History
├── Peer Reviews
│   ├── Assigned to Me
│   ├── Review Form
│   └── Completed Reviews
├── AI Assistance
│   └── Contextual actions inside lesson-plan editor
└── Profile
```

The AI experience should be embedded into the lesson-plan workflow. Do not create an unrestricted general chatbot for the MVP.

## Backend Architecture
Prefer thin controllers/Livewire components with application logic in dedicated classes.

Suggested structure:

```text
app/
├── Actions/
│   ├── LessonPlans/
│   ├── Reviews/
│   └── AI/
├── Enums/
├── Http/
│   ├── Controllers/
│   └── Requests/
├── Livewire/
├── Models/
├── Notifications/
├── Policies/
├── Services/
│   ├── LessonPlannerService.php
│   └── LessonPlanDocxService.php
└── Support/
```

Exact folders may be adjusted to match the generated Laravel application, but responsibilities must remain separated.

## Core Domain Models
### User
Key responsibilities:
- Authentication identity.
- Teacher/reviewer role information.
- Ownership and review relationships.

### LessonPlan
Suggested fields:
- `id`
- `user_id`
- `title`
- `topic`
- `class_level`
- `lesson_date`
- `duration_minutes`
- `status`
- `current_version_id` or equivalent version relationship
- timestamps

### LessonPlanVersion
Stores version-specific lesson content so previous submitted/reviewed versions remain immutable.

Suggested fields:
- `id`
- `lesson_plan_id`
- `version_number`
- structured lesson-plan fields/content
- `created_by`
- `created_at`

### LessonPlanFile
For uploaded supporting/original lesson-plan files.

Suggested fields:
- `id`
- `lesson_plan_id`
- `version_id` where applicable
- `disk`
- `path`
- `original_name`
- `mime_type`
- `size`
- checksum where implemented

### ReviewSubmission
Represents a particular version submitted for peer review.

Suggested fields:
- `id`
- `lesson_plan_id`
- `lesson_plan_version_id`
- `submitted_by`
- `reviewer_id`
- `status`
- `submitted_at`
- `completed_at`

### ReviewCriterion
Defines structured peer-review criteria.

Examples:
- Clarity of learning objectives.
- Suitability of teaching/learning activities.
- Appropriateness of resources.
- Alignment of assessment with objectives.
- Overall lesson organization.

### Review
Stores review summary/decision for a submission.

### ReviewResponse
Stores criterion-level ratings/comments if normalized separately.

### AiAssistanceLog
Optional but recommended for traceability and debugging. Store metadata rather than unnecessary sensitive prompt content.

Possible fields:
- feature/action requested
- user id
- lesson plan/version id
- model identifier
- request status
- latency
- error category
- token/usage metadata if available and needed
- timestamps

Do not store secrets or raw credentials.

## Authentication
Use Laravel's session guard with an Eloquent `User` provider and the browser `auth`/`guest` middleware split.

Requirements:
- Hashed passwords.
- CSRF protection for browser forms.
- Password reset.
- Rate limiting on sensitive authentication endpoints.
- Session regeneration after login.
- Registration, login, logout, password reset, and profile update are implemented with server-rendered Blade forms.
- Dashboard, lesson plans, generation, exports, files, reviews, revisions, and admin routes are inside the authenticated route group.
- Guest access to workspace routes redirects to the named login route; authenticated users are redirected away from guest auth pages.
- Authentication and AI generation endpoints are rate-limited.

## Authorization
Use Laravel Policies or Gates.

Rules include:
- A teacher can edit only owned drafts/revisions unless explicitly authorized.
- A submitted historical version must not be silently overwritten.
- A reviewer can access only reviews assigned to them or otherwise explicitly permitted.
- Uploaded files must be served only after authorization.
- Admin access must remain limited to defined system-management functions.

## Lesson-Plan State Model
Recommended states:

```text
DRAFT
  -> SUBMITTED
  -> UNDER_REVIEW
  -> CHANGES_REQUESTED -> REVISED -> RESUBMITTED -> UNDER_REVIEW
  -> REVIEWED
```

A transition must be validated by application logic. Do not let arbitrary UI input set workflow status.

## Lesson Plan Generation Service
### Principle
AI produces an editable Zambian CBC lesson-plan draft. It must not be the source of truth for authorization, required-field validation, review status, persistence, or final educational decisions.

### Integration Boundary
The current implementation is `App\Services\LessonPlannerService`. Its intended provider-neutral contract is:

```php
interface LessonPlanGenerator
{
    public function generate(array $input): array;
}
```

`generate()` uses Google AI Studio through the internal `LessonPlanGenerator` contract so callers do not depend on vendor request shapes.

### Configuration
Keep configuration in environment/config files:

```text
GOOGLE_AI_API_KEY=...
GOOGLE_AI_MODEL=gemini-3.8-flash
GOOGLE_AI_CONNECT_TIMEOUT=15
GOOGLE_AI_TIMEOUT=120

```

Map these values to `services.google_ai.*`. Do not rely on the service's fallback model identifiers as production configuration because model availability changes over time.

### Prompt Design
The current prompt supplies subject, class, topic, lesson, duration, references, prior knowledge, teaching materials, school, and teacher. It instructs the provider to create learner-centered Zambian CBC content and the fixed five-stage activity sequence.

Avoid sending unrelated user/profile information.

### Structured Responses
The generator requests JSON with:
- Header fields and enrollment.
- General/specific competence, lesson goal, rationale, and prior knowledge.
- References, learning-environment setup, teaching materials, and expected standards.
- Teaching/learning activities containing stage, duration, teacher activity, learner activity, and assessment criteria.
- Lesson evaluation.

The activity list must contain Introduction, Lesson Development, Class Exercise, Conclusion, and Homework. JSON decoding alone is insufficient; validate field types, required keys, stage membership/order, and ICT subject scope before previewing or storing the result.

### AI Failure Handling
If a provider is unavailable, times out, returns invalid data, or blocks a response:
- Preserve the teacher's lesson-plan data.
- Show a clear non-destructive error.
- Allow the teacher to continue manually.
- Log the provider, safe error category, and request metadata without secrets or raw lesson content.

AI failure must never prevent normal lesson-plan CRUD.

## DOCX Export Service
`App\Services\LessonPlanDocxService` accepts the normalized lesson-plan array and returns a temporary `.docx` path. It produces:
- An A4 document using Arial 11 with standard margins.
- A subject-based lesson-plan title.
- Header rows for school, teacher, date, class, duration, topic, lesson, and enrollment.
- Lesson components, list fields, learning-environment fields, and expected standards.
- A bordered activity table with stage, teacher activity, learner activity, and assessment criteria.

Activity duration is included in the stage label without duplication. The service currently creates a lesson-evaluation heading but does not render the evaluation values; that must be completed before export is considered finished. The caller must authorize the lesson plan, return a download response, and delete the temporary file after delivery.

## API Structure
The initial application can remain server-rendered and does not require a public API.

If internal JSON endpoints are added, use versioned and authenticated routes when appropriate.

Possible endpoints/actions:
- Generate a complete lesson-plan draft.
- Preview, edit, save, or discard generated content.
- Export an authorized lesson plan to DOCX.
- Review status actions.

Never expose an AI-provider credential to JavaScript or client-visible responses.

## Data Flow
### Create Lesson Plan
```text
Teacher -> Form -> Laravel validation -> Authorization -> Save draft/version -> MySQL
```

### AI Draft Generation
```text
Teacher -> Generation form -> Validate ICT/CBC context -> LessonPlanGenerator
        -> Google AI Studio
        -> Decode and validate exact schema -> Display editable draft
        -> Teacher edits/confirms -> Save draft/version
```

### Word Export
```text
Teacher -> Authorized export action -> Load normalized lesson plan
        -> LessonPlanDocxService -> Temporary DOCX
        -> Download response -> Delete temporary file
```

### Peer Review
```text
Teacher -> Submit version -> Assign reviewer -> Reviewer -> Structured review
        -> Feedback/status -> Teacher -> New revision -> Resubmit
```

## File Storage
- Use Laravel Storage abstraction.
- Prefer private storage for uploaded lesson plans.
- Never expose raw storage paths as public authorization bypasses.
- Validate MIME type, extension, size, and upload success.
- Generate server-side storage names.
- Preserve original filenames only as metadata for display/download.
- Consider malware scanning if deployment requirements justify it.

## Background Jobs
Queue operations that may become slow or unreliable in a synchronous request, including:
- AI calls if UX is designed asynchronously.
- Large document processing.
- Email notifications if later enabled.

For the MVP, short AI requests may be synchronous if timeouts and graceful errors are implemented.

## Notifications
Initial notification scope:
- In-app indication that a review was assigned.
- In-app indication that feedback is available.
- In-app indication that changes were requested/review completed.

Email can be added later if required.

## Security Architecture
- Server-side authorization on every protected action.
- CSRF protection.
- Strict validation.
- Output escaping.
- Private file access controls.
- Rate limit AI endpoints to control abuse and cost.
- Store AI-provider credentials only in server secrets/environment configuration.
- Never commit `.env`.
- Avoid sending sensitive or unnecessary user data to any AI provider.
- Log audit-relevant state changes.
- Use HTTPS in production.
- Keep dependencies updated.

## Scalability Considerations
The research project does not require premature distributed architecture.

Scale first through:
- Proper database indexing.
- Pagination.
- Efficient Eloquent relationships/eager loading.
- Queued long-running work.
- Caching controlled reference data when needed.
- Object storage if uploaded-file volume outgrows local storage.

Do not introduce microservices unless a proven requirement emerges.

## Architecture Constraints
1. Laravel remains the primary application framework.
2. MySQL remains the relational database unless the project formally changes.
3. AI provider access occurs through the backend only.
4. Generated plans remain editable previews until a teacher explicitly confirms them.
5. Review/version history must remain traceable.
6. The architecture must stay focused on ICT lesson planning and peer review.
7. Google AI Studio is the sole lesson-plan generation provider.
8. DOCX export operates on the normalized lesson-plan schema and must be authorized.
