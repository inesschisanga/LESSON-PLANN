# Development Tasks

## Status Legend
- `[ ]` Not started
- `[~]` In progress
- `[x]` Complete
- `[!]` Blocked

## Phase 0 — Confirm Project Decisions
- [ ] **TASK-001** Confirm final product/application name.
- [~] **TASK-002** Validate the service-derived Zambian CBC ICT lesson-plan template with intended users.
- [ ] **TASK-003** Confirm peer-review criteria and rating scale.
- [ ] **TASK-004** Confirm how reviewers are selected/assigned.
- [ ] **TASK-005** Confirm allowed upload formats and maximum size.
- [ ] **TASK-006** Confirm provisional UI branding or replace `DESIGN.md` colors with approved brand tokens.

### Acceptance Criteria
- Decisions are written in `MEMORY.md`.
- The PRD is updated only where confirmed requirements differ from current assumptions.

---

## Phase 1 — Laravel Project Setup
- [ ] **TASK-010** Initialize Laravel project and Git repository.
- [x] **TASK-011** Configure `.env.example` without secrets.
- [ ] **TASK-012** Configure MySQL database connection.
- [x] **TASK-013** Configure authentication.
- [x] **TASK-014** Install/configure selected frontend stack (Blade + Livewire/Tailwind as chosen).
- [x] **TASK-015** Configure application layout and navigation shell.
- [x] **TASK-016** Configure test environment.
- [x] **TASK-017** Configure code formatting/static checks used by the project.

### Acceptance Criteria
- Application boots locally.
- Database migrations run cleanly.
- A user can register/login/logout.
- Tests execute successfully.
- No secrets are committed.

---

## Phase 2 — Users, Roles, and Authorization
- [x] **TASK-020** Add required teacher profile fields.
- [x] **TASK-021** Define roles/permissions required for Teacher, Peer Reviewer behavior, and Administrator.
- [x] **TASK-022** Create foundational policies/gates.
- [x] **TASK-023** Add profile page.
- [x] **TASK-024** Add authorization tests.

### Acceptance Criteria
- Users can update permitted profile data.
- Protected routes/actions reject unauthorized access.
- Reviewer capabilities are permission/workflow based rather than trusting UI state.

---

## Phase 3 — Lesson-Plan Data Model
- [x] **TASK-030** Create `lesson_plans` schema/model.
- [x] **TASK-031** Create `lesson_plan_versions` schema/model.
- [x] **TASK-032** Create status enum(s).
- [x] **TASK-033** Define model relationships.
- [x] **TASK-034** Add factories/seeders for development/testing.
- [x] **TASK-035** Add indexes for ownership/status/date search patterns.

### Acceptance Criteria
- A lesson plan belongs to its creator.
- Multiple versions can exist without overwriting historical data.
- Status values cannot become arbitrary strings.

---

## Phase 4 — Lesson-Plan CRUD
- [x] **TASK-040** Create lesson-plan index page.
- [x] **TASK-041** Create structured lesson-plan form.
- [x] **TASK-042** Implement save draft.
- [x] **TASK-043** Implement lesson-plan detail page.
- [x] **TASK-044** Implement editing rules for draft/revision content.
- [x] **TASK-045** Implement validation.
- [x] **TASK-046** Add pagination/search/filtering.
- [x] **TASK-047** Add CRUD feature and authorization tests.

### Acceptance Criteria
- Teacher can create, save, view, search, and edit owned draft lesson plans.
- Invalid required data is rejected server-side.
- Another teacher cannot access/edit protected plans without permission.

---

## Phase 5 — File Upload and Repository
- [ ] **TASK-050** Create lesson-plan file metadata model/migration.
- [ ] **TASK-051** Implement secure upload validation.
- [ ] **TASK-052** Store uploaded files on private disk/storage.
- [ ] **TASK-053** Implement authorized download.
- [ ] **TASK-054** Display uploaded-file metadata in lesson-plan detail.
- [ ] **TASK-055** Add invalid-file and unauthorized-download tests.

### Acceptance Criteria
- Only approved types/sizes are accepted.
- Raw user filenames are not used as trusted paths.
- Files cannot be downloaded without authorization.
- Upload failure does not create broken metadata records.

---

## Phase 6 — AI Lesson-Plan Generation Foundation
- [ ] **TASK-060** Create a provider-neutral `LessonPlanGenerator` contract.
- [x] **TASK-061** Refactor the existing `LessonPlannerService` behind a provider-neutral lesson-plan generator contract.
- [x] **TASK-062** Add Google AI configuration to `config/services.php` or dedicated config.
- [x] **TASK-063** Add `.env.example` keys for Google AI credentials, model, connect timeout, and request timeout.
- [x] **TASK-064** Complete safe HTTP behavior: existing provider timeouts/error mapping plus retry policy and sanitized logging.
- [x] **TASK-065** Add schema validation/DTOs for the complete CBC lesson-plan response.
- [x] **TASK-066** Add fake AI implementation for automated tests.
- [x] **TASK-067** Add AI endpoint/action rate limiting.

### Acceptance Criteria
- No AI-provider credential appears in client-side code.
- Domain code depends on an internal interface, not vendor request shapes.
- Tests can run without live provider access.
- Malformed/blocked/timeout responses are handled safely.

---

## Phase 7 — Generated Draft and Document Export
- [x] **TASK-070** Wire the existing full-draft generation service into a validated application action.
- [x] **TASK-071** Enforce the canonical CBC schema and the five required activity stages.
- [x] **TASK-072** Build generated-draft preview/edit/save/discard behavior.
- [~] **TASK-073** Use the existing stage-duration normalization for preview and export.
- [x] **TASK-074** Wire `LessonPlanDocxService` after installing/configuring PhpOffice PhpWord and render lesson-evaluation values.
- [x] **TASK-075** Add authorized DOCX download and temporary-file cleanup.
- [x] **TASK-076** Add generation/export loading and recoverable error states.
- [x] **TASK-077** Add AI and DOCX behavior tests using fakes/mocks; tests must not call live providers.

### Acceptance Criteria
- AI runs only after explicit user action or a controlled workflow event.
- AI output remains an editable preview until the teacher explicitly saves it.
- User can continue if AI is unavailable.
- Returned data is schema-validated before rendering.
- Export includes all canonical lesson-plan sections and does not leave temporary files behind.

---

## Phase 8 — Peer Review Data Model
- [x] **TASK-080** Create review criteria schema/model.
- [x] **TASK-081** Create review submission schema/model.
- [x] **TASK-082** Create review/review-response schema/model.
- [ ] **TASK-083** Seed initial criteria after research confirmation.
- [x] **TASK-084** Implement review status transition logic.

### Acceptance Criteria
- A review submission references a specific lesson-plan version.
- Review feedback remains linked to the reviewed version.
- Invalid status transitions are rejected.

---

## Phase 9 — Peer Review Workflow
- [ ] **TASK-090** Implement `Submit for Review` action.
- [ ] **TASK-091** Implement reviewer assignment/selection mechanism.
- [ ] **TASK-092** Build `Assigned to Me` review queue.
- [ ] **TASK-093** Build structured review form.
- [ ] **TASK-094** Implement comments, suggestions, ratings, and overall feedback.
- [ ] **TASK-095** Implement `Changes Requested` and `Reviewed` outcomes.
- [ ] **TASK-096** Build teacher feedback view.
- [ ] **TASK-097** Add peer-review authorization and workflow tests.

### Acceptance Criteria
- Only authorized reviewer can review the assigned submission.
- Reviewer sees the exact submitted version.
- Feedback is visible to the plan owner after completion according to workflow.
- Historical reviewed content is not silently modified.

---

## Phase 10 — Revision and Resubmission
- [ ] **TASK-100** Implement `Create Revision` action.
- [ ] **TASK-101** Copy relevant content into a new editable version.
- [ ] **TASK-102** Preserve previous version and review feedback.
- [ ] **TASK-103** Implement resubmission.
- [ ] **TASK-104** Build version/review timeline.
- [ ] **TASK-105** Add revision history tests.

### Acceptance Criteria
- Revision creates a new version.
- Old submitted/reviewed versions remain unchanged.
- Resubmitted version can be reviewed independently.
- Teacher can see progression over time.

---

## Phase 11 — Notifications and Attention States
- [ ] **TASK-110** Add in-app indication for assigned reviews.
- [ ] **TASK-111** Add in-app indication for completed feedback/changes requested.
- [ ] **TASK-112** Add dashboard attention widgets.
- [ ] **TASK-113** Test notification visibility/authorization.

---

## Phase 12 — Security and Hardening
- [ ] **TASK-120** Review all policies and protected routes.
- [ ] **TASK-121** Review upload/download security.
- [ ] **TASK-122** Review AI data minimization and secret handling.
- [ ] **TASK-123** Add/request throttling for authentication and AI actions.
- [ ] **TASK-124** Review mass assignment, XSS output handling, CSRF, redirects, and file paths.
- [ ] **TASK-125** Run dependency/security audit.
- [ ] **TASK-126** Verify production error/debug configuration.

### Acceptance Criteria
- No Gemini secret is exposed or committed.
- Unauthorized object access tests pass.
- Debug mode is disabled in production configuration.
- Security-sensitive workflows have automated coverage.

---

## Phase 13 — Usability and Research Evaluation
- [ ] **TASK-130** Prepare evaluation/test scenarios for teachers.
- [ ] **TASK-131** Validate requirements against intended participants.
- [ ] **TASK-132** Conduct usability/functionality evaluation.
- [ ] **TASK-133** Record defects and user feedback.
- [ ] **TASK-134** Prioritize and implement in-scope corrections.
- [ ] **TASK-135** Record evaluation evidence required by the academic project.

---

## Phase 14 — Deployment
- [ ] **TASK-140** Provision/configure production hosting.
- [ ] **TASK-141** Configure Nginx/PHP-FPM/HTTPS.
- [ ] **TASK-142** Configure production database.
- [ ] **TASK-143** Configure protected file storage.
- [ ] **TASK-144** Configure Gemini production credential/restrictions.
- [ ] **TASK-145** Configure queue worker/scheduler if used.
- [ ] **TASK-146** Configure backups.
- [ ] **TASK-147** Configure logs/monitoring.
- [ ] **TASK-148** Run production smoke tests.

### Acceptance Criteria
- HTTPS works.
- Secrets are server-side only.
- Core create/upload/review/revision workflow works in production.
- Backups and recovery procedure are documented.

---

## Phase 15 — Final Documentation
- [ ] **TASK-150** Update system architecture diagrams.
- [ ] **TASK-151** Finalize database/UML documentation.
- [ ] **TASK-152** Document setup/deployment steps.
- [ ] **TASK-153** Document AI integration and limitations.
- [ ] **TASK-154** Document tests and evaluation results.
- [ ] **TASK-155** Reconcile implementation with project report/proposal scope.

---

# First Recommended Implementation Task
After Phase 0 decisions are sufficiently confirmed, begin with:

## TASK-010 — Initialize Laravel Project
**Status:** Not Started

### Requirements
- Create Laravel application.
- Initialize Git repository.
- Configure `.gitignore`.
- Create `.env` locally and safe `.env.example`.
- Configure local MySQL.
- Add the `docs/` directory containing these six project files.

### Acceptance Criteria
- `php artisan` runs successfully.
- Application loads locally.
- Database connection succeeds.
- Repository contains no secrets.
- Documentation is committed with the project.
