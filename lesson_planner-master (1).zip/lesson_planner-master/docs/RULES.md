# Development Rules

## Purpose
These rules are mandatory for both human developers and AI coding assistants working on the ICT Lesson Planning application.

## General Coding Principles
1. Follow the current project architecture before creating new abstractions.
2. Prefer simple, readable Laravel-native solutions.
3. Do not introduce a new framework, database, queue provider, or major dependency without documenting the reason.
4. Reuse existing components, services, validation rules, and patterns.
5. Do not duplicate business logic across controllers, Livewire components, jobs, or services.
6. Keep controllers/components thin.
7. Make business rules explicit and testable.
8. Do not change unrelated functionality while implementing a task.
9. Never silently expand the research scope.

## Naming Conventions
Follow Laravel/PHP conventions:
- Classes: `StudlyCase`.
- Methods/variables: `camelCase`.
- Database tables/columns: `snake_case`.
- Route names: consistent dot notation, e.g. `lesson-plans.show`.
- Policies: `{Model}Policy`.
- Form Requests: action-specific names, e.g. `StoreLessonPlanRequest`.
- Actions/services: describe intent, e.g. `SubmitLessonPlanForReview`.

Use domain terms consistently:
- `LessonPlan`
- `LessonPlanVersion`
- `ReviewSubmission`
- `Review`
- `ReviewCriterion`
- `LessonPlanGenerator`

Do not invent multiple names for the same concept.

## Coding Style
- Follow PSR-12 and the formatter/linter configured by the project.
- Use typed method signatures where practical.
- Use enums for controlled states when supported by the application design.
- Prefer early returns to deeply nested conditionals.
- Avoid large methods with mixed responsibilities.
- Add comments for intent or non-obvious constraints, not for self-evident syntax.

## File Organization
- Keep UI logic in controllers/Livewire components.
- Keep reusable domain operations in Actions/Services.
- Keep AI-provider code under a dedicated AI namespace.
- Keep authorization in Policies/Gates.
- Keep complex HTTP validation in Form Requests or equivalent Livewire validation classes.
- Keep status values centralized in enums/config, not scattered strings.

## Database Rules
1. Use migrations for all schema changes.
2. Add foreign keys for relational integrity where appropriate.
3. Define delete behavior deliberately; do not rely on accidental cascades.
4. Index fields used frequently for filtering/searching/status lookup.
5. Use Eloquent relationships rather than repeated ad-hoc joins when appropriate.
6. Prevent N+1 queries through eager loading.
7. Do not overwrite a historical lesson-plan version that has already been submitted/reviewed.
8. Use transactions for multi-record workflow changes that must succeed together.
9. Do not store API keys, passwords, or secret tokens in database seeders or source code.

## Validation Rules
Two kinds of validation must remain distinct.

### Deterministic Application Validation
Handled by Laravel. Examples:
- Required fields.
- File type/size.
- Valid IDs.
- Valid dates and duration.
- Authorized state transitions.

These checks are authoritative.

### AI-Assisted Validation
Handled by Gemini. Examples:
- Suggesting that an objective may be unclear.
- Suggesting that an assessment does not appear aligned with an objective.
- Identifying a potentially missing instructional element.

These checks are advisory and must never be represented as guaranteed truth.

## Error Handling
- Show users actionable, non-technical errors.
- Do not expose stack traces or secrets in production.
- Preserve unsaved/entered content where practical after recoverable errors.
- Treat AI failures as recoverable.
- Log exceptions with enough context to debug, but do not log passwords, credentials, session tokens, or unnecessary sensitive content.

## Authentication Rules
- Use Laravel-supported authentication.
- Passwords must be hashed using Laravel's password facilities.
- Regenerate sessions after successful login.
- Protect password-reset flows.
- Apply rate limiting where appropriate.

## Authorization Rules
- Every protected resource must be authorized on the server.
- Never trust hidden form fields or route parameters as proof of ownership.
- Teachers may not edit another teacher's lesson plan unless a future explicit permission allows it.
- Reviewers may access only reviews they are authorized to perform/view.
- File downloads must pass authorization.
- Admin capability does not imply unrestricted academic editing.

## Lesson-Plan Workflow Rules
1. A plan begins as a draft.
2. Submission must reference a specific immutable/versioned snapshot.
3. A reviewer reviews the submitted version, not an uncontrolled latest draft.
4. Feedback belongs to the version/submission reviewed.
5. Changes after feedback create a revision/new version.
6. Resubmission creates or updates the appropriate review submission without destroying historical review evidence.
7. Status transitions are performed through dedicated business logic.

## AI Provider Rules
1. All Google AI Studio calls are made server-side.
2. Never expose provider credentials in frontend code, HTML, JavaScript, logs, screenshots, or repository history.
3. Read credentials/model configuration from environment/config.
4. Do not hard-code the model name throughout the application.
5. Route generation through a provider-neutral contract implemented by `LessonPlannerService` or its successor.
6. Google AI Studio is the sole generation provider; do not implement provider fallback behavior.
7. Send only the minimum lesson-plan context needed for generation.
8. Do not send passwords, authentication data, or unrelated user information to any AI provider.
9. Require structured JSON responses for generated lesson plans.
10. Validate required keys, value types, ICT subject scope, and the five required activity stages before rendering or persisting a response.
11. AI output must be clearly presented as an editable generated draft.
12. AI must not automatically approve a lesson plan or complete a peer review on behalf of a human.
13. AI must not automatically overwrite or persist user-authored fields.
14. Provide timeouts and failure handling.
15. Rate-limit AI actions to reduce abuse and unexpected cost.
16. Record useful operational metadata for failures/cost analysis without storing secrets or raw lesson content.
17. Do not log complete provider response bodies or unparsed generated plans; log a request identifier, provider, status, and safe error category.

## Prompt Rules
Each prompt must:
- Have one clear feature goal.
- Define the teacher context supplied.
- Ask for concise, actionable output.
- Avoid asking the model to invent unknown curriculum facts as if verified.
- Prefer structured output where the UI expects structured data.

Prompts should be stored centrally rather than duplicated across views/controllers. The lesson-plan schema used by prompting, validation, preview, persistence, and export must have one canonical definition.

## Generated Document Rules
- Generate DOCX files server-side from an authorized, normalized lesson plan.
- Do not accept a client-provided storage path or arbitrary output filename.
- Use a temporary file and remove it after the download response completes.
- Export only validated fields from the canonical lesson-plan schema.
- Escape/normalize generated and teacher-authored values before passing them to the document library.
- Include lesson-evaluation values, not only the section heading.
- Cover document generation with tests that inspect content and confirm temporary-file cleanup.

## File Upload Rules
- Accept only explicitly allowed formats.
- Enforce file-size limits.
- Validate MIME type and extension.
- Store files outside public web root unless a secure access mechanism is used.
- Generate safe server-side filenames.
- Never use user-provided filenames as raw storage paths.
- Authorize every download.
- Prevent path traversal.

## Security Rules
- Never trust client-side input.
- Escape rendered user content by default.
- Use CSRF protection.
- Prevent mass-assignment vulnerabilities using explicit fillable/guarded strategy.
- Use prepared queries/Eloquent instead of raw SQL where possible.
- Validate redirect targets and file paths.
- Keep `.env` out of source control.
- Use HTTPS in production.
- Apply least privilege to database and server credentials.
- Review dependencies for known vulnerabilities before release.

## Privacy and Data-Minimization Rules
- Collect only information required for the research/application workflow.
- Do not send unnecessary personally identifiable information to AI services.
- Avoid storing full AI prompts/responses unless required for research, debugging, or audit and explicitly justified.
- If AI content is stored, document retention and access rules.

## Testing Requirements
Every completed feature should include appropriate tests.

### Required Categories
- Feature tests for core workflows.
- Authorization tests for protected resources.
- Validation tests.
- Workflow/status-transition tests.
- AI-service tests using fakes/mocks; normal CI tests must not require live Gemini calls.
- File-upload and protected-download tests.

### Critical Scenarios
Test at least:
- Unauthorized lesson-plan access is denied.
- Invalid uploads are rejected.
- A teacher cannot edit another teacher's plan.
- A reviewer cannot review an unassigned plan.
- A submitted version is preserved.
- Revision/resubmission preserves history.
- Gemini timeout/error does not lose lesson-plan data.
- Malformed AI output is handled safely.

## Dependency Rules
- Prefer Laravel core capabilities first.
- Before adding a package, document why Laravel/core PHP cannot reasonably provide the feature.
- Do not add abandoned or low-maintenance packages for critical functionality.
- Pin/lock dependencies through Composer/NPM lock files.
- Remove unused packages.

## API Standards
If JSON endpoints are introduced:
- Authenticate and authorize them.
- Return consistent status codes and JSON structure.
- Validate request payloads.
- Never return secrets.
- Version public APIs if the project later exposes them externally.

## Performance Rules
- Paginate lesson-plan and review lists.
- Avoid N+1 queries.
- Index commonly filtered columns.
- Do not call Gemini automatically on every keystroke.
- Trigger AI only through an explicit user action or controlled workflow step.
- Debounce/rate-limit interactive AI actions where appropriate.
- Queue long-running work.

## Git Conventions
Recommended branches:
- `main` — stable branch.
- `develop` — optional integration branch.
- `feature/<short-name>` — feature work.
- `fix/<short-name>` — bug fixes.

Recommended commit examples:
- `feat: add lesson plan creation workflow`
- `feat: add peer review submission`
- `fix: prevent unauthorized lesson plan download`
- `test: cover revision resubmission flow`
- `docs: record Gemini integration decision`

Do not commit secrets, `.env`, uploaded user files, or local build artifacts.

## AI Coding Assistant Rules
Before coding:
1. Read `PRD.md`.
2. Read `ARCHITECTURE.md`.
3. Read `RULES.md`.
4. Read `DESIGN.md` for UI work.
5. Read `TASKS.md` for the active task.
6. Read `MEMORY.md` for previous decisions.

While coding:
- Implement only the requested task.
- Do not redesign unrelated modules.
- Do not change architecture silently.
- Reuse existing components and patterns.
- Add/update tests.

After coding:
- Mark task progress in `TASKS.md`.
- Add important decisions/discoveries to `MEMORY.md`.
- Update `ARCHITECTURE.md` if architecture changed.
- Update `PRD.md` only when product requirements genuinely changed.
- Report modified files and migrations.

## Definition of Done
A task is complete only when:
- Required behavior works.
- Server-side validation exists.
- Authorization is enforced.
- Error states are handled.
- Tests pass.
- UI follows `DESIGN.md` where applicable.
- Documentation is updated if the task introduced a decision or new behavior.
