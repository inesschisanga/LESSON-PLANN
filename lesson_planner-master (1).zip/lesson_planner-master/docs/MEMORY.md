# Project Memory and Decision Log

## Purpose
This file records confirmed decisions, constraints, discoveries, and implementation history so future development sessions do not have to rediscover project context.

Do not treat assumptions as confirmed decisions. When a requirement is still unknown, keep it under **Open Decisions**.

## Project Summary
The project is a web-based application for **secondary-school ICT lesson planning**. It supports:
- Structured lesson-plan creation and editing.
- Uploading existing lesson-plan documents.
- Storage, retrieval, search, and download.
- Peer-review submission and structured feedback.
- Revision and resubmission.
- AI-generated Zambian CBC lesson-plan drafts that remain under teacher control.
- Word document export from the normalized lesson-plan structure.

## Confirmed Product Decisions
### 2026-09-30 — Framework
**Decision:** Use Laravel as the application framework.

**Reason:** Explicit project implementation choice.

### 2026-09-30 — AI Platform
**Decision:** Use Google AI Studio / Gemini API for AI-assisted lesson-planning features.

**Reason:** Explicit project implementation choice.

### 2026-09-30 — AI Scope
**Decision:** AI may generate a complete structured lesson-plan draft, while the teacher must review, edit, and explicitly save it.

**Reason:** `LessonPlannerService` implements full structured generation. Teacher confirmation preserves the research requirement that AI support professional judgement rather than replace it.

### 2026-09-30 — Academic Scope
**Decision:** The application focuses on ICT lesson planning for secondary schools.

**Included:**
- Create/edit lesson plans.
- Upload existing plans.
- Store/retrieve/download.
- Peer review.
- Feedback/ratings.
- Revision/resubmission.
- Basic intelligent assistance.

**Excluded:**
- Schemes of work.
- Records of work.
- Teaching timetables.
- General departmental monitoring.
- General-purpose chat.
- Native mobile application.
- National education management integrations.
- Subjects other than ICT.
- Advanced custom ML models.

## Architecture Decisions
### 2026-09-30 — Laravel Monolith
**Decision:** Start with a Laravel monolith using a three-tier application structure.

**Reason:** The project scope does not justify microservices. A Laravel monolith is simpler to build, test, deploy, and evaluate academically.

### 2026-09-30 — Gemini Behind Service Contract
**Decision:** AI-provider access must be isolated behind an internal interface such as `LessonPlanGenerator`.

**Reason:** Avoid provider-specific logic across the application and make AI behavior testable/fakeable.

### 2026-09-30 — Server-Side AI Calls
**Decision:** The browser must never call Gemini directly with a project credential.

**Reason:** Protect credentials, centralize validation/rate limiting, and keep prompts/business rules under server control.

### 2026-09-30 — Model Configuration
**Decision:** Gemini model identifier must be configuration-driven rather than hard-coded throughout the codebase.

**Reason:** Model availability and recommended versions can change.

### 2026-09-30 — AI Failure Isolation
**Decision:** AI failures must not prevent normal lesson-plan CRUD or destroy user-entered content.

**Reason:** AI is assistance, not a critical source of truth.

### 2026-09-30 — Versioned Lesson Plans
**Decision:** A peer review must reference a specific lesson-plan version.

**Reason:** Feedback needs an auditable relationship to the exact content reviewed. Revisions must not rewrite historical evidence.

### 2026-10-01 — Service-Derived Lesson Plan Structure
**Decision:** Use the current service schema as the provisional canonical plan shape: plan header and enrollment, CBC lesson components, learning-environment setup, resources/standards, five fixed teaching stages, and lesson evaluation.

**Reason:** `LessonPlannerService` and `LessonPlanDocxService` already share this structure. One canonical schema will prevent drift between prompting, validation, editing, persistence, and export.

### 2026-10-01 — AI Provider Routing
**Decision:** Google AI Studio is the sole lesson-plan generator.

**Reason:** This matches the public methods and documented intent in `LessonPlannerService`.

### 2026-10-01 — DOCX Export
**Decision:** Generate Word documents server-side from the normalized lesson-plan structure through `LessonPlanDocxService`.

**Reason:** This keeps export logic out of controllers and prevents provider-specific response shapes from leaking into document generation.

## Database Decisions
### 2026-09-30
**Decision:** Use MySQL as the relational database.

**Reason:** This matches the proposal's development specification.

### Initial Domain Entities
Planned entities:
- User
- LessonPlan
- LessonPlanVersion
- LessonPlanFile
- ReviewSubmission
- ReviewCriterion
- Review / ReviewResponse
- Optional AiAssistanceLog

These names may be refined before migrations are finalized, but their responsibilities should remain distinct.

## UI Decisions
### 2026-09-30
**Decision:** The UI should be a focused academic productivity interface rather than a visually heavy marketing-style interface.

**Reason:** Primary tasks are form completion, document management, and peer review.

### 2026-09-30 — AI Transparency
**Decision:** AI-generated content must be visibly labeled and require deliberate teacher review, editing, and confirmation.

**Reason:** Avoid confusing a generated draft with teacher-authored or reviewer-approved content.

### 2026-10-01 — Landing Page Direction
**Decision:** Use `Lesson Studio` as the product identity for the public landing page, with an electric-lime, parchment, and warm-black visual system. The landing page demonstrates the structured plan → assist → review → revise workflow and labels AI suggestions as optional.

**Reason:** The supplied style reference establishes the visual direction, while the product documentation requires the marketing experience to communicate teacher control, contextual AI assistance, and traceable peer review. The final product name remains an open decision.

## Security Decisions
### 2026-09-30
- Keep all AI-provider credentials in server-side environment configuration.
- Never expose credentials to frontend code.
- Authorize all lesson-plan/review/file actions on the server.
- Store uploaded lesson plans privately.
- Validate type and size of uploads.
- Rate-limit AI actions.
- Avoid logging secrets or unnecessary personal data.

## Completed Features
- Public responsive landing page for the ICT lesson-planning product.
- Session-based registration, login, logout, password reset routes, and auth-protected workspace routes.
- Teacher profiles and administrator role management with server-side authorization policies.
- Versioned CBC ICT lesson-plan CRUD, private attachments, peer review, revision, notifications, and DOCX export.
- PHPUnit feature coverage for authentication, authorization, generation, review workflow, revision, export, and profile updates.

## Current Work
### 2026-10-01
- Reconcile the application workflow with `LessonPlannerService` and `LessonPlanDocxService`.
- Introduce a canonical lesson-plan schema and provider-neutral generator contract.
- Wire generation and export into validated, authorized application actions.
- Complete the authenticated MVP workspace and browser navigation shell.

## Known Bugs
- The reviewer criteria are intentionally fixed for the MVP and still need validation with intended teachers.

## Resolved Bugs
- AI configuration and provider model selection are now configuration-driven.
- PhpWord is installed and DOCX export renders lesson-evaluation values with authorized temporary-file cleanup.
- Generated plans are validated against the canonical CBC schema and five-stage order before preview.
- Provider logging no longer records raw response bodies or generated content.
- Generation/export/auth/review flows now have routes, controllers, policies, and automated tests.

## Technical Discoveries
### Gemini Structured Output
For application-facing AI features, structured JSON responses should be preferred where supported so suggestions can be parsed and validated predictably.

### AI Provider Volatility
Gemini models/API details can evolve. The code should therefore use configuration and an internal service boundary rather than scattering provider/model assumptions throughout the application.

### Service Implementation Audit — 2026-10-01
- `LessonPlannerService::generate()` uses Google AI Studio and requests JSON output.
- Google AI Studio uses configurable connect/request timeouts so model/API changes remain isolated to configuration.
- `mergeStageDurationsIntoLabels()` normalizes activity labels for preview/export.
- `LessonPlanDocxService::generate()` returns a temporary DOCX path and expects the same array shape as the generator.

## Important Constraints
1. Scope is specifically secondary-school ICT lesson planning.
2. AI-generated drafts require teacher review and explicit confirmation.
3. Peer review is structured around lesson plans, not a general messaging module.
4. Historical review/version data must remain traceable.
5. Laravel is the main framework.
6. Google AI Studio/Gemini is the AI platform.
7. MySQL is the planned relational database.
8. Advanced custom ML is outside scope.
9. Native mobile development is outside scope.
10. Exact evaluation targets must come from the research/evaluation design rather than being invented during coding.

## Open Decisions
These should be confirmed before or during early requirements validation:
- Final product name/branding.
- Exact Laravel version selected at project initialization.
- Exact frontend stack/version (Blade only vs Blade + Livewire).
- Validate the service-derived Zambian CBC ICT template/fields with target teachers.
- Peer-review rating scale.
- Final peer-review criteria.
- Reviewer assignment method: teacher selection, system assignment, or authorized coordinator assignment.
- Allowed upload extensions and maximum size.
- Whether generated Word files need browser preview or download only.
- Whether in-app notifications are enough for MVP or email is required.
- Whether AI request/response text should be retained for research/debugging and, if so, retention/access policy.
- Approved brand colors and typography.
- Hosting environment/domain.

## Future Improvements
Only revisit after core scope is complete:
- Email notifications.
- Richer lesson-plan analytics.
- Rubric customization.
- Additional export formats.
- Curriculum-aware reference integrations.
- Expanded subjects.

## Update Rule
After meaningful development work:
1. Update completed/in-progress items in `TASKS.md`.
2. Record significant technical/product decisions here.
3. Move resolved issues from Known Bugs to Resolved Bugs.
4. Update `ARCHITECTURE.md` if system structure changes.
5. Update `PRD.md` only if product requirements change.
