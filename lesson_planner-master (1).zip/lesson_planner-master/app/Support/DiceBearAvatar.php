<?php

namespace App\Support;

use Composer\InstalledVersions;
use DiceBear\Avatar;
use DiceBear\Style;
use RuntimeException;

class DiceBearAvatar
{
    private Style $style;

    public function __construct()
    {
        $stylePath = InstalledVersions::getInstallPath('dicebear/styles').'/src/moods.json';
        $styleDefinition = file_get_contents($stylePath);

        if ($styleDefinition === false) {
            throw new RuntimeException('The DiceBear avatar style could not be loaded.');
        }

        $this->style = Style::fromJson($styleDefinition);
    }

    public function dataUri(string $seed, int $size = 44): string
    {
        return $this->avatar($seed, $size)->toDataUri();
    }

    public function svg(string $seed, int $size = 44): string
    {
        return $this->avatar($seed, $size)->toString();
    }

    private function avatar(string $seed, int $size): Avatar
    {
        return new Avatar($this->style, [
            'seed' => $seed,
            'size' => $size,
            'borderRadius' => 50,
            'backgroundColor' => ['078b5c'],
            'textColor' => ['ffffff'],
            'fontWeight' => [650],
            'title' => $seed,
        ]);
    }
}
