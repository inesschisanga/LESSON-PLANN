<?php

namespace App\Support;

use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rule;
use Illuminate\Validation\ValidationException;

class LessonPlanSchema
{
    public const STAGES = [
        'Introduction',
        'Lesson Development',
        'Class Exercise',
        'Conclusion',
        'Homework',
    ];

    /**
     * @return array<string, mixed>
     */
    public static function blank(): array
    {
        return [
            'school' => '',
            'teacher' => '',
            'date' => now()->toDateString(),
            'class' => '',
            'subject' => 'ICT',
            'duration' => 40,
            'topic' => '',
            'lesson' => '',
            'enrollment' => ['boys' => 0, 'girls' => 0],
            'lesson_components' => [
                'general_competence' => '',
                'specific_competence' => '',
                'lesson_goal' => '',
                'rationale' => '',
                'prior_knowledge' => '',
                'references' => [],
                'learning_environment_setup' => [
                    'natural_environment' => '',
                    'artificial_environment' => '',
                ],
                'teaching_materials' => [],
                'expected_standards' => [],
            ],
            'teaching_learning_activities' => array_map(
                fn (string $stage): array => [
                    'stage' => $stage,
                    'duration' => '',
                    'teacher_activity' => '',
                    'learner_activity' => '',
                    'assessment_criteria' => '',
                ],
                self::STAGES,
            ),
            'lesson_evaluation' => [],
            'visibility' => 'private',
        ];
    }

    /**
     * @return array<string, array<int, mixed>>
     */
    public static function rules(): array
    {
        return [
            'school' => ['nullable', 'string', 'max:255'],
            'teacher' => ['nullable', 'string', 'max:255'],
            'date' => ['required', 'date'],
            'class' => ['required', 'string', 'max:100'],
            'subject' => ['required', Rule::in(['ICT'])],
            'duration' => ['required', 'integer', 'min:10', 'max:240'],
            'topic' => ['required', 'string', 'max:255'],
            'lesson' => ['required', 'string', 'max:255'],
            'enrollment' => ['required', 'array:boys,girls'],
            'enrollment.boys' => ['required', 'integer', 'min:0', 'max:500'],
            'enrollment.girls' => ['required', 'integer', 'min:0', 'max:500'],
            'lesson_components' => ['required', 'array'],
            'lesson_components.general_competence' => ['required', 'string', 'max:3000'],
            'lesson_components.specific_competence' => ['required', 'string', 'max:3000'],
            'lesson_components.lesson_goal' => ['required', 'string', 'max:3000'],
            'lesson_components.rationale' => ['required', 'string', 'max:3000'],
            'lesson_components.prior_knowledge' => ['required', 'string', 'max:3000'],
            'lesson_components.references' => ['required', 'array', 'min:1', 'max:20'],
            'lesson_components.references.*' => ['required', 'string', 'max:500'],
            'lesson_components.learning_environment_setup' => ['required', 'array'],
            'lesson_components.learning_environment_setup.natural_environment' => ['nullable', 'string', 'max:3000'],
            'lesson_components.learning_environment_setup.artificial_environment' => ['nullable', 'string', 'max:3000'],
            'lesson_components.teaching_materials' => ['required', 'array', 'min:1', 'max:30'],
            'lesson_components.teaching_materials.*' => ['required', 'string', 'max:500'],
            'lesson_components.expected_standards' => ['required', 'array', 'min:1', 'max:20'],
            'lesson_components.expected_standards.*' => ['required', 'string', 'max:1000'],
            'teaching_learning_activities' => ['required', 'array', 'size:5'],
            'teaching_learning_activities.*' => ['required', 'array'],
            'teaching_learning_activities.*.stage' => ['required', 'string', Rule::in(self::STAGES)],
            'teaching_learning_activities.*.duration' => ['required', 'string', 'max:100'],
            'teaching_learning_activities.*.teacher_activity' => ['required', 'string', 'max:5000'],
            'teaching_learning_activities.*.learner_activity' => ['required', 'string', 'max:5000'],
            'teaching_learning_activities.*.assessment_criteria' => ['required', 'string', 'max:3000'],
            'lesson_evaluation' => ['required', 'array', 'min:1', 'max:20'],
            'lesson_evaluation.*' => ['required', 'string', 'max:1000'],
        ];
    }

    /**
     * @param  array<string, mixed>  $plan
     * @return array<string, mixed>
     *
     * @throws ValidationException
     */
    public function validate(array $plan): array
    {
        $plan['subject'] = 'ICT';

        $validated = Validator::make($plan, self::rules())->validate();

        $stages = array_column($validated['teaching_learning_activities'], 'stage');
        if ($stages !== self::STAGES) {
            throw ValidationException::withMessages([
                'teaching_learning_activities' => 'The five lesson stages must appear in the required order.',
            ]);
        }

        return $validated;
    }
}
