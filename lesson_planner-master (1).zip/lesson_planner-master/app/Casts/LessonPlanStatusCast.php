<?php

namespace App\Casts;

use App\LessonPlanStatus;
use Illuminate\Contracts\Database\Eloquent\CastsAttributes;
use Illuminate\Database\Eloquent\Model;

class LessonPlanStatusCast implements CastsAttributes
{
    public function get(Model $model, string $key, mixed $value, array $attributes): LessonPlanStatus
    {
        return LessonPlanStatus::tryFrom((string) $value) ?? LessonPlanStatus::Draft;
    }

    public function set(Model $model, string $key, mixed $value, array $attributes): string
    {
        if ($value instanceof LessonPlanStatus) {
            return $value->value;
        }

        return LessonPlanStatus::tryFrom((string) $value)?->value ?? LessonPlanStatus::Draft->value;
    }
}
