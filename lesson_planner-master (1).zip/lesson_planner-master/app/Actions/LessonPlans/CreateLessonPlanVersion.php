<?php

namespace App\Actions\LessonPlans;

use App\Models\LessonPlan;
use App\Models\LessonPlanVersion;
use App\Models\User;
use Illuminate\Support\Facades\DB;

class CreateLessonPlanVersion
{
    /**
     * @param  array<string, mixed>  $content
     */
    public function handle(LessonPlan $lessonPlan, array $content, User $creator): LessonPlanVersion
    {
        return DB::transaction(function () use ($lessonPlan, $content, $creator): LessonPlanVersion {
            $lockedPlan = LessonPlan::query()->lockForUpdate()->findOrFail($lessonPlan->id);
            $nextVersion = ((int) $lockedPlan->versions()->max('version_number')) + 1;

            $lockedPlan->update([
                'title' => $content['lesson'],
                'topic' => $content['topic'],
                'class_level' => $content['class'],
                'lesson_date' => $content['date'],
                'duration_minutes' => $content['duration'],
            ]);

            return $lockedPlan->versions()->create([
                'version_number' => $nextVersion,
                'content' => $content,
                'created_by' => $creator->id,
            ]);
        });
    }
}
