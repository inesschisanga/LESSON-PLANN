<?php

namespace App;

enum LessonPlanStatus: string
{
    case Draft = 'draft';

    public function label(): string
    {
        return match ($this) {
            self::Draft => 'Draft',
        };
    }

    public function isEditable(): bool
    {
        return $this === self::Draft;
    }
}
