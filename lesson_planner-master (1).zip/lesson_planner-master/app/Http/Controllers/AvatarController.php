<?php

namespace App\Http\Controllers;

use App\Support\DiceBearAvatar;
use Illuminate\Http\Request;
use Illuminate\Http\Response;

class AvatarController extends Controller
{
    public function __construct(private readonly DiceBearAvatar $avatars) {}

    public function __invoke(Request $request, string $seed): Response
    {
        $size = max(24, min($request->integer('size', 44), 96));

        return response($this->avatars->svg($seed, $size), 200, [
            'Content-Type' => 'image/svg+xml; charset=UTF-8',
            'Cache-Control' => 'public, max-age=86400',
        ]);
    }
}
