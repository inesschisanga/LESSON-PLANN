<?php

namespace App\Http\Controllers;

use App\Models\LessonPlan;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(Request $request): View
    {
        $user = $request->user();
        $counts = [
            'public' => LessonPlan::query()->whereBelongsTo($user)->where('visibility', 'public')->count(),
            'private' => LessonPlan::query()->whereBelongsTo($user)->where('visibility', 'private')->count(),
        ];

        $recentPlans = LessonPlan::query()
            ->whereBelongsTo($user)
            ->latest('updated_at')
            ->latest('id')
            ->limit(5)
            ->get();

        return view('dashboard', compact('counts', 'recentPlans'));
    }
}
