<?php

namespace App\Http\Controllers;

use App\Actions\LessonPlans\CreateLessonPlanVersion;
use App\Http\Requests\StoreLessonPlanRequest;
use App\Http\Requests\UpdateLessonPlanRequest;
use App\LessonPlanStatus;
use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use App\Support\LessonPlanSchema;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Illuminate\View\View;

class LessonPlanController extends Controller
{
    public function index(Request $request): View
    {
        $this->authorize('viewAny', LessonPlan::class);
        $visibility = LessonPlanVisibility::tryFrom($request->string('visibility')->toString());

        $plans = LessonPlan::query()
            ->whereBelongsTo($request->user())
            ->with('currentVersion')
            ->when($request->string('search')->trim()->isNotEmpty(), function ($query) use ($request): void {
                $search = '%'.$request->string('search')->trim().'%';
                $query->where(fn ($query) => $query
                    ->where('title', 'like', $search)
                    ->orWhere('topic', 'like', $search)
                    ->orWhere('class_level', 'like', $search));
            })
            ->when($visibility, fn ($query) => $query->where('visibility', $visibility->value))
            ->latest('updated_at')
            ->paginate(12)
            ->withQueryString();

        return view('lesson-plans.index', [
            'plans' => $plans,
        ]);
    }

    public function create(Request $request): View
    {
        $this->authorize('create', LessonPlan::class);

        $plan = LessonPlanSchema::blank();
        $plan['school'] = $request->user()->school ?? '';
        $plan['teacher'] = $request->user()->name;

        return view('lesson-plans.create', compact('plan'));
    }

    public function store(StoreLessonPlanRequest $request, CreateLessonPlanVersion $createVersion): RedirectResponse
    {
        $content = $request->validated();

        $lessonPlan = DB::transaction(function () use ($request, $content, $createVersion): LessonPlan {
            $lessonPlan = LessonPlan::create([
                'user_id' => $request->user()->id,
                'title' => $content['lesson'],
                'topic' => $content['topic'],
                'class_level' => $content['class'],
                'lesson_date' => $content['date'],
                'duration_minutes' => $content['duration'],
                'status' => LessonPlanStatus::Draft,
                'visibility' => $content['visibility'],
            ]);

            $createVersion->handle($lessonPlan, $content, $request->user());

            return $lessonPlan;
        });

        return to_route('lesson-plans.show', $lessonPlan)->with('status', 'Lesson plan saved.');
    }

    public function show(LessonPlan $lessonPlan): View
    {
        $this->authorize('view', $lessonPlan);
        $lessonPlan->load(['user:id,name,school,avatar_seed', 'currentVersion.creator:id,name']);

        return view('lesson-plans.show', compact('lessonPlan'));
    }

    public function edit(LessonPlan $lessonPlan): View
    {
        $this->authorize('update', $lessonPlan);
        $lessonPlan->load('currentVersion');
        $plan = $lessonPlan->currentVersion->content;
        $plan['visibility'] = $lessonPlan->visibility->value;

        return view('lesson-plans.edit', compact('lessonPlan', 'plan'));
    }

    public function update(UpdateLessonPlanRequest $request, LessonPlan $lessonPlan, CreateLessonPlanVersion $createVersion): RedirectResponse
    {
        $content = $request->validated();
        $createVersion->handle($lessonPlan, $content, $request->user());
        $lessonPlan->update(['visibility' => $content['visibility']]);

        return to_route('lesson-plans.show', $lessonPlan)->with('status', 'Lesson plan updated.');
    }

    public function destroy(LessonPlan $lessonPlan): RedirectResponse
    {
        $this->authorize('delete', $lessonPlan);

        $lessonPlan->delete();

        return to_route('lesson-plans.index')->with('status', 'Lesson plan deleted.');
    }
}
