<?php

namespace App\Http\Controllers;

use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class LessonPlanSocialController extends Controller
{
    public function toggleLike(Request $request, LessonPlan $lessonPlan): RedirectResponse|JsonResponse
    {
        abort_unless($lessonPlan->visibility === LessonPlanVisibility::Public, 404);

        $like = $lessonPlan->likes()->whereBelongsTo($request->user())->first();
        $like?->delete();
        $liked = ! $like;

        if ($liked) {
            $lessonPlan->likes()->create(['user_id' => $request->user()->id]);
        }

        if ($request->expectsJson()) {
            return response()->json([
                'liked' => $liked,
                'likes_count' => $lessonPlan->likes()->count(),
            ]);
        }

        return back();
    }

    public function comment(Request $request, LessonPlan $lessonPlan): RedirectResponse
    {
        abort_unless($lessonPlan->visibility === LessonPlanVisibility::Public, 404);

        $validated = $request->validate(['body' => ['required', 'string', 'max:2000']]);
        $lessonPlan->comments()->create([
            'user_id' => $request->user()->id,
            'body' => $validated['body'],
        ]);

        return back();
    }
}
