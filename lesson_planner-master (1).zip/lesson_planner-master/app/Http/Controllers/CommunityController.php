<?php

namespace App\Http\Controllers;

use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use Illuminate\Http\Request;
use Illuminate\View\View;

class CommunityController extends Controller
{
    public function index(Request $request): View
    {
        $posts = LessonPlan::query()
            ->where('visibility', LessonPlanVisibility::Public->value)
            ->when($request->filled('search'), function ($query) use ($request): void {
                $search = '%'.$request->string('search')->trim()->toString().'%';
                $query->where(fn ($query) => $query
                    ->where('title', 'like', $search)
                    ->orWhere('topic', 'like', $search)
                    ->orWhere('class_level', 'like', $search));
            })
            ->with([
                'user:id,name,school,avatar_seed',
                'currentVersion',
                'comments' => fn ($query) => $query->latest()->limit(3),
                'comments.user:id,name',
            ])
            ->withCount(['likes', 'comments'])
            ->latest('updated_at')
            ->paginate(10)
            ->withQueryString();

        $likedPlanIds = $request->user()->lessonPlanLikes()
            ->whereIn('lesson_plan_id', $posts->getCollection()->modelKeys())
            ->pluck('lesson_plan_id')
            ->all();

        return view('community.index', compact('posts', 'likedPlanIds'));
    }
}
