<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use App\Models\User;
use Illuminate\Http\Request;
use Illuminate\View\View;

class DashboardController extends Controller
{
    public function __invoke(Request $request): View
    {
        abort_unless($request->user()->isAdministrator(), 403);

        $posts = LessonPlan::query()
            ->where('visibility', LessonPlanVisibility::Public->value)
            ->with(['user:id,name,school,avatar_seed', 'currentVersion', 'comments.user:id,name'])
            ->withCount(['likes', 'comments'])
            ->latest('updated_at')
            ->limit(8)
            ->get();
        $likedPlanIds = $request->user()->lessonPlanLikes()->whereIn('lesson_plan_id', $posts->modelKeys())->pluck('lesson_plan_id')->all();
        $metrics = [
            'teachers' => User::query()->count(),
            'public_lessons' => LessonPlan::query()->where('visibility', LessonPlanVisibility::Public->value)->count(),
            'private_lessons' => LessonPlan::query()->where('visibility', LessonPlanVisibility::Private->value)->count(),
        ];

        return view('admin.dashboard', compact('posts', 'likedPlanIds', 'metrics'));
    }
}
