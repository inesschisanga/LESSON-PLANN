<?php

namespace App\Http\Controllers;

use App\Contracts\LessonPlanGenerator;
use App\Http\Requests\GenerateLessonPlanRequest;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\Support\Facades\Log;
use Illuminate\Validation\ValidationException;
use Illuminate\View\View;
use RuntimeException;

class GeneratedLessonPlanController extends Controller
{
    public function create(): RedirectResponse
    {
        return to_route('dashboard');
    }

    public function store(GenerateLessonPlanRequest $request, LessonPlanGenerator $generator): RedirectResponse|JsonResponse
    {
        try {
            $input = $request->validated();
            $input['date'] = now()->toDateString();
            $plan = $generator->generate($input);
        } catch (RuntimeException|ValidationException $exception) {
            report($exception);
            Log::error('Lesson plan generation failed', [
                'exception' => $exception,
                'input' => $request->all(),
            ]);

            $message = $exception instanceof RuntimeException && str_contains($exception->getMessage(), 'temporarily busy')
                ? $exception->getMessage()
                : 'The lesson could not be generated right now. Please retry or create it manually.';
            $errors = ['generation' => [$message]];

            if ($request->expectsJson()) {
                return response()->json(['message' => $message, 'errors' => $errors], 422);
            }

            return back()->withInput()->withErrors($errors);
        }

        $request->session()->put('generated_lesson_plan', $plan);

        if ($request->expectsJson()) {
            return response()->json(['redirect_url' => route('lesson-plans.generated.preview', [], false)]);
        }

        return to_route('lesson-plans.generated.preview');
    }

    public function preview(): View|RedirectResponse
    {
        $plan = session('generated_lesson_plan');

        if (! is_array($plan)) {
            return to_route('lesson-plans.generate')->withErrors(['generation' => 'Generate a lesson plan first.']);
        }

        return view('lesson-plans.generated-preview', compact('plan'));
    }
}
