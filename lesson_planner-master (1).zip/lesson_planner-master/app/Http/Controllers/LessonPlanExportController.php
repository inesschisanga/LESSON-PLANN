<?php

namespace App\Http\Controllers;

use App\Models\LessonPlan;
use App\Services\LessonPlanDocxService;
use Illuminate\Http\Response;
use Symfony\Component\HttpFoundation\BinaryFileResponse;

class LessonPlanExportController extends Controller
{
    public function __invoke(LessonPlan $lessonPlan, LessonPlanDocxService $exporter): BinaryFileResponse
    {
        $this->authorize('export', $lessonPlan);
        $lessonPlan->loadMissing('currentVersion');
        abort_if($lessonPlan->currentVersion === null, Response::HTTP_UNPROCESSABLE_ENTITY, 'This lesson has no saved version.');

        $path = $exporter->generate($lessonPlan->currentVersion->content);
        $filename = str($lessonPlan->title)->slug()->append('-v'.$lessonPlan->currentVersion->version_number.'.docx');

        return response()->download($path, $filename)->deleteFileAfterSend(true);
    }
}
