<?php

namespace App\Http\Requests;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class GenerateLessonPlanRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        return $this->user() !== null;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, array<int, mixed>>
     */
    public function rules(): array
    {
        return [
            'school' => ['nullable', 'string', 'max:255'],
            'teacher' => ['nullable', 'string', 'max:255'],
            'subject' => ['required', Rule::in(['ICT'])],
            'class' => ['required', 'string', 'max:100'],
            'topic' => ['required', 'string', 'max:255'],
            'lesson' => ['required', 'string', 'max:255'],
            'duration' => ['required', 'integer', 'min:10', 'max:240'],
            'references' => ['nullable', 'string', 'max:3000'],
            'prior_knowledge' => ['nullable', 'string', 'max:3000'],
            'teaching_materials' => ['nullable', 'string', 'max:3000'],
        ];
    }
}
