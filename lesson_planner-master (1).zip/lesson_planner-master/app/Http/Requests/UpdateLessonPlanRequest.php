<?php

namespace App\Http\Requests;

use App\Models\LessonPlan;
use App\Support\LessonPlanSchema;
use Illuminate\Contracts\Validation\ValidationRule;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class UpdateLessonPlanRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     */
    public function authorize(): bool
    {
        $lessonPlan = $this->route('lesson_plan');

        return $lessonPlan instanceof LessonPlan
            && ($this->user()?->can('update', $lessonPlan) ?? false);
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array<string, ValidationRule|array<mixed>|string>
     */
    public function rules(): array
    {
        return [
            ...LessonPlanSchema::rules(),
            'visibility' => ['required', Rule::in(['private', 'public'])],
        ];
    }
}
