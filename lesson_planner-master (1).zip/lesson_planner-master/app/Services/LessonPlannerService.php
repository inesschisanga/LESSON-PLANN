<?php

namespace App\Services;

use App\Contracts\LessonPlanGenerator;
use App\Support\LessonPlanSchema;
use Illuminate\Http\Client\ConnectionException;
use Illuminate\Http\Client\RequestException;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Http;
use Illuminate\Support\Facades\Log;

class LessonPlannerService implements LessonPlanGenerator
{
    protected string $googleBaseUrl = 'https://generativelanguage.googleapis.com/v1beta';

    public function __construct(private LessonPlanSchema $schema) {}

    /**
     * Generate a structured lesson plan JSON via Google AI Studio.
     *
     * @param  array  $input  Validated input from the request
     * @return array Decoded lesson plan
     *
     * @throws \RuntimeException
     */
    public function generate(array $input): array
    {
        $prompt = $this->buildPrompt($input);
        $googleKey = config('services.google_ai.api_key');
        $googleModel = config('services.google_ai.model');

        if (! $googleKey || ! $googleModel) {
            throw new \RuntimeException('Google AI Studio credentials are not configured.');
        }

        return $this->generateWithGoogle($prompt, $googleKey, $input);
    }

    private function generateWithGoogle(string $prompt, string $apiKey, array $input): array
    {
        $model = trim((string) config('services.google_ai.model'));
        $model = preg_replace('/^models\//', '', $model) ?: $model;

        try {
            $response = Http::connectTimeout((int) config('services.google_ai.connect_timeout', 15))
                ->timeout((int) config('services.google_ai.timeout', 120))
                ->retry(
                    [1000, 3000],
                    0,
                    function (\Throwable $exception): bool {
                        if ($exception instanceof ConnectionException) {
                            return true;
                        }

                        return $exception instanceof RequestException
                            && in_array($exception->response->status(), [429, 500, 502, 503, 504], true);
                    },
                    false,
                )
                ->withQueryParameters(['key' => $apiKey])
                ->post("{$this->googleBaseUrl}/models/{$model}:generateContent", [
                    'contents' => [
                        [
                            'role' => 'user',
                            'parts' => [['text' => $prompt]],
                        ],
                    ],
                    'generationConfig' => [
                        'temperature' => 0.6,
                        'topP' => 0.95,
                        'maxOutputTokens' => 4096,
                        'responseMimeType' => 'application/json',
                    ],
                ]);
        } catch (ConnectionException $e) {
            throw new \RuntimeException('Google AI Studio request timed out or could not connect.', 0, $e);
        }

        if (! $response->successful()) {
            Log::error('Google AI Studio API error', [
                'provider' => 'google',
                'model' => $model,
                'status' => $response->status(),
                'message' => $response->json('error.message'),
            ]);

            if (in_array($response->status(), [429, 500, 502, 503, 504], true)) {
                throw new \RuntimeException('Google AI Studio is temporarily busy. Please wait a moment and retry.');
            }

            throw new \RuntimeException('Google AI Studio API returned status '.$response->status());
        }

        $content = $response->json('candidates.0.content.parts.0.text') ?? '';

        return $this->decodePlan($content, $input);
    }

    private function decodePlan(string $content, array $input): array
    {

        // Strip any accidental markdown code fences the model may add
        $content = preg_replace('/^```(?:json)?\s*/m', '', $content);
        $content = preg_replace('/\s*```$/m', '', $content);
        $content = trim($content);

        $plan = json_decode($content, true);

        if (json_last_error() !== JSON_ERROR_NONE) {
            Log::error('Lesson plan JSON parse error', [
                'provider' => 'google',
                'response_length' => mb_strlen($content),
                'response_hash' => hash('sha256', $content),
            ]);
            throw new \RuntimeException('Could not parse lesson plan from model response.');
        }

        if (! is_array($plan)) {
            throw new \RuntimeException('The model response was not a lesson plan object.');
        }

        $plan['date'] = $this->normalizeDate($plan['date'] ?? null, $input['date'] ?? null);
        $plan['duration'] = $this->normalizeDuration($plan['duration'] ?? null, $input['duration'] ?? 40);

        return $this->schema->validate($plan);
    }

    private function normalizeDate(mixed $value, mixed $fallback): string
    {
        foreach ([$value, $fallback] as $candidate) {
            $candidate = trim((string) $candidate);

            if ($candidate === '') {
                continue;
            }

            try {
                return Carbon::parse($candidate)->toDateString();
            } catch (\Throwable) {
                continue;
            }
        }

        return now()->toDateString();
    }

    private function normalizeDuration(mixed $value, mixed $fallback): int
    {
        foreach ([$value, $fallback] as $candidate) {
            if (is_int($candidate) || is_float($candidate) || (is_string($candidate) && is_numeric(trim($candidate)))) {
                $duration = (int) $candidate;
            } elseif (preg_match('/\d{1,3}/', (string) $candidate, $matches) === 1) {
                $duration = (int) $matches[0];
            } else {
                continue;
            }

            if ($duration >= 10 && $duration <= 240) {
                return $duration;
            }
        }

        return 40;
    }

    /**
     * Fold per-stage durations into the stage label and drop the duration field (preview / export).
     *
     * @param  array<string, mixed>  $plan
     */
    public function mergeStageDurationsIntoLabels(array &$plan): void
    {
        $activities = $plan['teaching_learning_activities'] ?? null;
        if (! is_array($activities)) {
            return;
        }
        foreach ($activities as $i => $activity) {
            if (! is_array($activity)) {
                continue;
            }
            $stage = trim((string) ($activity['stage'] ?? ''));
            $dur = trim((string) ($activity['duration'] ?? ''));
            if ($dur !== '' && ! str_contains(strtolower($stage), strtolower($dur))) {
                $stage = ($stage !== '' ? $stage : 'Stage').' ('.$dur.')';
            }
            $plan['teaching_learning_activities'][$i]['stage'] = $stage;
            unset($plan['teaching_learning_activities'][$i]['duration']);
        }
    }

    // -------------------------------------------------------------------------
    // Private helpers
    // -------------------------------------------------------------------------

    private function buildPrompt(array $d): string
    {
        $refs = $d['references'] ?? 'Zambian Secondary School Syllabus';
        $prior = $d['prior_knowledge'] ?? '';
        $materials = $d['teaching_materials'] ?? '';
        $school = $d['school'] ?? '';
        $teacher = $d['teacher'] ?? '';

        return <<<PROMPT
You are an expert Zambian secondary school lesson plan generator specialized in the Competence-Based Curriculum (CBC).
Your task is to generate a complete professional lesson plan for Zambian schools using the provided information.

IMPORTANT RULES:
- Return ONLY valid JSON.
- Do NOT return markdown.
- Do NOT include explanations.
- Do NOT include notes outside JSON.
- Do NOT wrap the JSON in triple backticks.
- Ensure the JSON is syntactically valid.
- Follow the exact structure provided.
- Generate professional educational content suitable for Zambian schools.
- Ensure all sections are completed.
- Activities must be learner-centered and competence-based.
- Assessment criteria must align with the learner activities.
- References must remain an array.
- Teaching materials must remain an array.
- Expected standards must remain an array.
- Lesson evaluation must remain an array.
- teaching_learning_activities must contain exactly:
  - Introduction
  - Lesson Development
  - Class Exercise
  - Conclusion
  - Homework

INPUT DATA:
Subject: {$d['subject']}
Class: {$d['class']}
Topic: {$d['topic']}
Lesson: {$d['lesson']}
Duration: {$d['duration']}
Date: {$d['date']}
References: {$refs}
Prior Knowledge: {$prior}
Teaching Materials: {$materials}
School Name: {$school}
Teacher Name: {$teacher}

Generate the lesson plan using the following JSON structure EXACTLY:

{
  "school": "",
  "teacher": "",
  "date": "",
  "class": "",
  "subject": "",
  "duration": 40,
  "topic": "",
  "lesson": "",
  "enrollment": { "boys": 0, "girls": 0 },
  "lesson_components": {
    "general_competence": "",
    "specific_competence": "",
    "lesson_goal": "",
    "rationale": "",
    "prior_knowledge": "",
    "references": [],
    "learning_environment_setup": {
      "natural_environment": "",
      "artificial_environment": ""
    },
    "teaching_materials": [],
    "expected_standards": []
  },
  "teaching_learning_activities": [
    { "stage": "Introduction",       "duration": "", "teacher_activity": "", "learner_activity": "", "assessment_criteria": "" },
    { "stage": "Lesson Development", "duration": "", "teacher_activity": "", "learner_activity": "", "assessment_criteria": "" },
    { "stage": "Class Exercise",     "duration": "", "teacher_activity": "", "learner_activity": "", "assessment_criteria": "" },
    { "stage": "Conclusion",         "duration": "", "teacher_activity": "", "learner_activity": "", "assessment_criteria": "" },
    { "stage": "Homework",           "duration": "", "teacher_activity": "", "learner_activity": "", "assessment_criteria": "" }
  ],
  "lesson_evaluation": []
}

ADDITIONAL REQUIREMENTS:
- Use formal teacher language.
- Ensure activities are realistic for classroom teaching.
- Ensure lesson activities match the topic.
- Ensure lesson evaluation reflects possible classroom outcomes.
- Generate meaningful competencies.
- Homework should reinforce the lesson.
- Use clear educational terminology.
- Avoid repetition.
- Ensure all arrays contain realistic values.
- Ensure durations are realistic and total approximately the lesson duration.
- Return date as YYYY-MM-DD and duration as a whole number of minutes.
- Generate content appropriate for the specified class level.
PROMPT;
    }
}
