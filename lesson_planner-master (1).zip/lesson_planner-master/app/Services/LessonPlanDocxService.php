<?php

namespace App\Services;

use PhpOffice\PhpWord\Element\Cell;
use PhpOffice\PhpWord\Element\Table;
use PhpOffice\PhpWord\IOFactory;
use PhpOffice\PhpWord\PhpWord;
use PhpOffice\PhpWord\SimpleType\Jc;
use PhpOffice\PhpWord\SimpleType\TblWidth;

class LessonPlanDocxService
{
    /** Content width in twips (A4 minus typical margins). */
    private const TW = 9072;

    /**
     * Generate a .docx from the lesson plan array and return the temp file path.
     */
    public function generate(array $plan): string
    {
        $phpWord = new PhpWord;
        $phpWord->setDefaultFontName('Arial');
        $phpWord->setDefaultFontSize(11);

        $section = $phpWord->addSection([
            'pageSizeW' => 11906,
            'pageSizeH' => 16838,
            'marginTop' => 1080,
            'marginBottom' => 1080,
            'marginLeft' => 1080,
            'marginRight' => 1080,
        ]);

        $lc = $plan['lesson_components'] ?? [];
        $subject = $plan['subject'] ?? ($plan['topic'] ?? 'Lesson Plan');

        $section->addText(
            strtoupper((string) $subject).' LESSON PLAN',
            ['bold' => true, 'size' => 14],
            ['alignment' => Jc::CENTER, 'spaceAfter' => 160]
        );

        $this->addPlanHeader($section, $plan);

        $section->addTextBreak(1);

        $this->addSectionHeading($section, 'LESSON COMPONENTS');

        $components = [
            'General Competence' => $lc['general_competence'] ?? '',
            'Specific Competence' => $lc['specific_competence'] ?? '',
            'Lesson Goal' => $lc['lesson_goal'] ?? '',
            'Rationale' => $lc['rationale'] ?? '',
            'Prior Knowledge' => $lc['prior_knowledge'] ?? '',
        ];

        foreach ($components as $label => $value) {
            $this->addLabeledItem($section, $label, $value);
        }

        $this->addLabeledList($section, 'References', $this->normalizeListItems($lc['references'] ?? []));

        $env = $lc['learning_environment_setup'] ?? [];
        $this->addLabeledItem($section, 'Natural Environment', $env['natural_environment'] ?? '');
        $this->addLabeledItem($section, 'Artificial Environment', $env['artificial_environment'] ?? '');

        $this->addLabeledList($section, 'Teaching Materials', $this->normalizeListItems($lc['teaching_materials'] ?? []));

        $this->addLabeledList($section, 'Expected Standards', $this->normalizeListItems($lc['expected_standards'] ?? []));

        $section->addTextBreak(1);

        $this->addSectionHeading($section, 'TEACHING AND LEARNING ACTIVITIES');
        $this->addActivitiesTable($section, $plan['teaching_learning_activities'] ?? []);

        $section->addTextBreak(1);

        $this->addSectionHeading($section, 'LESSON EVALUATION');
        $this->addLabeledList($section, 'Evaluation prompts', $this->normalizeListItems($plan['lesson_evaluation'] ?? []));

        $tmpPath = tempnam(sys_get_temp_dir(), 'lesson_');
        if ($tmpPath === false) {
            throw new \RuntimeException('Could not create a temporary lesson-plan file.');
        }
        $writer = IOFactory::createWriter($phpWord, 'Word2007');
        $writer->save($tmpPath);

        return $tmpPath;
    }

    /**
     * Plain header (no visible borders): matches lesson plan form layout.
     */
    private function addPlanHeader($section, array $plan): void
    {
        $half = (int) (self::TW / 2);

        $table = $section->addTable([
            'borderSize' => 0,
            'cellMargin' => 80,
            'width' => self::TW,
            'unit' => TblWidth::TWIP,
        ]);

        $school = (string) ($plan['school'] ?? '');
        $teacher = (string) ($plan['teacher'] ?? '');
        $date = (string) ($plan['date'] ?? now()->format('d/m/Y'));
        $class = (string) ($plan['class'] ?? '');
        $duration = $this->formatDurationForHeader($plan['duration'] ?? '');
        $topic = (string) ($plan['topic'] ?? '');
        $lesson = (string) ($plan['lesson'] ?? '');
        $enr = $plan['enrollment'] ?? ['boys' => 0, 'girls' => 0];
        $boys = (string) ($enr['boys'] ?? 0);
        $girls = (string) ($enr['girls'] ?? 0);

        $row = $table->addRow();
        $cell = $row->addCell(self::TW, ['gridSpan' => 2]);
        $this->addHeaderLabelValue($cell, 'School', $school);

        $this->addHeaderTwoColumns($table, $half, 'Teacher', $teacher, 'Date', $date);
        $this->addHeaderTwoColumns($table, $half, 'Class', $class, 'Duration', $duration);

        $row = $table->addRow();
        $cell = $row->addCell(self::TW, ['gridSpan' => 2]);
        $this->addHeaderLabelValue($cell, 'Topic', $topic);

        $row = $table->addRow();
        $cell = $row->addCell(self::TW, ['gridSpan' => 2]);
        $this->addHeaderLabelValue($cell, 'Lesson', $lesson);

        $row = $table->addRow();
        $cell = $row->addCell(self::TW, ['gridSpan' => 2]);
        $run = $cell->addTextRun(['spaceAfter' => 0]);
        $run->addText('Enrollment: ', ['bold' => true, 'size' => 11]);
        $run->addText('Boys: ', ['size' => 11]);
        $run->addText($boys, ['size' => 11]);
        $run->addText('  Girls: ', ['size' => 11]);
        $run->addText($girls, ['size' => 11]);
    }

    private function addHeaderLabelValue(Cell $cell, string $label, string $value): void
    {
        $run = $cell->addTextRun(['spaceAfter' => 120]);
        $run->addText($label.': ', ['bold' => true, 'size' => 11]);
        $run->addText($value, ['size' => 11]);
    }

    /**
     * @param  Table  $table
     */
    private function addHeaderTwoColumns($table, int $halfWidth, string $l1, string $v1, string $l2, string $v2): void
    {
        $row = $table->addRow();
        $c1 = $row->addCell($halfWidth);
        $this->addHeaderLabelValue($c1, $l1, $v1);
        $c2 = $row->addCell($halfWidth);
        $this->addHeaderLabelValue($c2, $l2, $v2);
    }

    private function formatDurationForHeader(mixed $raw): string
    {
        $s = trim((string) $raw);
        if ($s === '') {
            return '';
        }
        if (preg_match('/minute(s)?/i', $s) === 1) {
            return $s;
        }
        if (preg_match('/^\d+$/', $s) === 1) {
            return $s.' minutes';
        }

        return $s;
    }

    private function addSectionHeading($section, string $text): void
    {
        $section->addText(
            $text,
            ['bold' => true, 'size' => 11],
            ['spaceBefore' => 120, 'spaceAfter' => 80]
        );
    }

    private function addLabeledItem($section, string $label, string $value): void
    {
        $textRun = $section->addTextRun(['spaceAfter' => 60]);
        $textRun->addText($label.': ', ['bold' => true, 'size' => 10]);
        $textRun->addText($value, ['size' => 10]);
    }

    private function addLabeledList($section, string $label, array $items): void
    {
        $section->addText($label.':', ['bold' => true, 'size' => 10], ['spaceAfter' => 40]);
        foreach ($items as $item) {
            $this->addBulletItem($section, (string) $item);
        }
    }

    /**
     * Visible round bullets in Word (list markup is inconsistent across PhpWord versions).
     */
    private function addBulletItem($section, string $text): void
    {
        $section->addText(
            '• '.$text,
            ['size' => 10],
            ['spaceAfter' => 40, 'indentation' => ['left' => 720, 'hanging' => 360]]
        );
    }

    /**
     * @return list<string>
     */
    private function normalizeListItems(mixed $value): array
    {
        if (is_string($value)) {
            $value = trim($value);
            if ($value === '') {
                return [];
            }
            $parts = preg_split('/\r\n|\n|,/u', $value) ?: [];

            return array_values(array_filter(array_map(
                static fn ($part) => trim((string) $part),
                $parts
            )));
        }

        if (! is_array($value)) {
            return [];
        }

        $out = [];
        foreach ($value as $item) {
            if (is_string($item)) {
                $t = trim($item);
                if ($t !== '') {
                    $out[] = $t;
                }
            } elseif (is_scalar($item)) {
                $t = trim((string) $item);
                if ($t !== '') {
                    $out[] = $t;
                }
            }
        }

        return $out;
    }

    /**
     * @param  array<int, mixed>  $activities
     */
    private function addActivitiesTable($section, array $activities): void
    {
        $colStage = (int) (self::TW * 0.22);
        $colRest = (int) ((self::TW - $colStage) / 3);

        $table = $section->addTable([
            'borderSize' => 6,
            'borderColor' => '000000',
            'cellMargin' => 100,
            'width' => self::TW,
            'unit' => TblWidth::TWIP,
        ]);

        $headers = ['Stage', 'Teacher Activity', 'Learner Activity', 'Assessment Criteria'];
        $widths = [$colStage, $colRest, $colRest, $colRest];
        $hr = $table->addRow(500);
        foreach ($headers as $i => $header) {
            $cell = $hr->addCell($widths[$i], ['valign' => 'center']);
            $cell->addText($header, ['bold' => true, 'size' => 9], ['alignment' => Jc::CENTER, 'spaceAfter' => 0]);
        }

        foreach ($activities as $activity) {
            if (! is_array($activity)) {
                continue;
            }
            $tr = $table->addRow();
            $stageText = $this->formatActivityStageLabel($activity);

            $stageCell = $tr->addCell($widths[0], ['valign' => 'top']);
            $stageCell->addText($stageText, ['bold' => true, 'size' => 9], ['spaceAfter' => 0]);

            $teachCell = $tr->addCell($widths[1], ['valign' => 'top']);
            $teachCell->addText((string) ($activity['teacher_activity'] ?? ''), ['size' => 9], ['spaceAfter' => 0]);

            $learnCell = $tr->addCell($widths[2], ['valign' => 'top']);
            $learnCell->addText((string) ($activity['learner_activity'] ?? ''), ['size' => 9], ['spaceAfter' => 0]);

            $assessCell = $tr->addCell($widths[3], ['valign' => 'top']);
            $assessCell->addText((string) ($activity['assessment_criteria'] ?? ''), ['size' => 9], ['spaceAfter' => 0]);
        }
    }

    /**
     * @param  array<string, mixed>  $activity
     */
    private function formatActivityStageLabel(array $activity): string
    {
        $stage = trim((string) ($activity['stage'] ?? ''));
        $dur = trim((string) ($activity['duration'] ?? ''));
        if ($dur === '') {
            return $stage;
        }
        if ($stage === '') {
            return '('.$dur.')';
        }
        if (str_contains(strtolower($stage), strtolower($dur))) {
            return $stage;
        }

        return $stage.' ('.$dur.')';
    }
}
