<?php

namespace App\Providers;

use App\Contracts\LessonPlanGenerator;
use App\Services\LessonPlannerService;
use App\Support\DiceBearAvatar;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;
use Illuminate\Support\Str;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        $this->app->bind(LessonPlanGenerator::class, LessonPlannerService::class);
        $this->app->singleton(DiceBearAvatar::class);
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        Model::preventLazyLoading(! $this->app->isProduction());

        RateLimiter::for('login', function (Request $request): Limit {
            return Limit::perMinute(5)->by(
                Str::lower($request->string('email')->toString()).'|'.$request->ip(),
            );
        });

        RateLimiter::for('lesson-generation', function (Request $request): Limit {
            return Limit::perMinute(5)->by((string) $request->user()?->id);
        });
    }
}
