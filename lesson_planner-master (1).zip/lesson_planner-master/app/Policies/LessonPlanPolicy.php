<?php

namespace App\Policies;

use App\LessonPlanStatus;
use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use App\Models\User;

class LessonPlanPolicy
{
    public function before(User $user): ?bool
    {
        return $user->isAdministrator() ? true : null;
    }

    public function viewAny(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can view the model.
     */
    public function view(User $user, LessonPlan $lessonPlan): bool
    {
        return $lessonPlan->visibility === LessonPlanVisibility::Public
            || $lessonPlan->user_id === $user->id;
    }

    /**
     * Determine whether the user can create models.
     */
    public function create(User $user): bool
    {
        return true;
    }

    /**
     * Determine whether the user can update the model.
     */
    public function update(User $user, LessonPlan $lessonPlan): bool
    {
        return $lessonPlan->user_id === $user->id && $lessonPlan->status->isEditable();
    }

    /**
     * Determine whether the user can delete the model.
     */
    public function delete(User $user, LessonPlan $lessonPlan): bool
    {
        return $lessonPlan->user_id === $user->id
            && $lessonPlan->status === LessonPlanStatus::Draft;
    }

    /**
     * Determine whether the user can restore the model.
     */
    public function restore(User $user, LessonPlan $lessonPlan): bool
    {
        return false;
    }

    public function export(User $user, LessonPlan $lessonPlan): bool
    {
        return $this->view($user, $lessonPlan);
    }

    /**
     * Determine whether the user can permanently delete the model.
     */
    public function forceDelete(User $user, LessonPlan $lessonPlan): bool
    {
        return false;
    }
}
