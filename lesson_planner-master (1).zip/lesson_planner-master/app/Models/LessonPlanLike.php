<?php

namespace App\Models;

use Database\Factories\LessonPlanLikeFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['lesson_plan_id', 'user_id'])]
class LessonPlanLike extends Model
{
    /** @use HasFactory<LessonPlanLikeFactory> */
    use HasFactory;

    public function lessonPlan(): BelongsTo
    {
        return $this->belongsTo(LessonPlan::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
