<?php

namespace App\Models;

use Database\Factories\LessonPlanCommentFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['lesson_plan_id', 'user_id', 'body'])]
class LessonPlanComment extends Model
{
    /** @use HasFactory<LessonPlanCommentFactory> */
    use HasFactory;

    public function lessonPlan(): BelongsTo
    {
        return $this->belongsTo(LessonPlan::class);
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }
}
