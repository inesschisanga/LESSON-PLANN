<?php

namespace App\Models;

use App\Casts\LessonPlanStatusCast;
use App\LessonPlanVisibility;
use Database\Factories\LessonPlanFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;

#[Fillable(['user_id', 'title', 'topic', 'class_level', 'lesson_date', 'duration_minutes', 'status', 'visibility'])]
class LessonPlan extends Model
{
    /** @use HasFactory<LessonPlanFactory> */
    use HasFactory;

    protected function casts(): array
    {
        return [
            'lesson_date' => 'date',
            'status' => LessonPlanStatusCast::class,
            'visibility' => LessonPlanVisibility::class,
        ];
    }

    public function user(): BelongsTo
    {
        return $this->belongsTo(User::class);
    }

    public function versions(): HasMany
    {
        return $this->hasMany(LessonPlanVersion::class);
    }

    public function currentVersion(): HasOne
    {
        return $this->hasOne(LessonPlanVersion::class)->ofMany('version_number', 'max');
    }

    public function likes(): HasMany
    {
        return $this->hasMany(LessonPlanLike::class);
    }

    public function comments(): HasMany
    {
        return $this->hasMany(LessonPlanComment::class);
    }
}
