<?php

namespace App\Models;

use Database\Factories\LessonPlanVersionFactory;
use Illuminate\Database\Eloquent\Attributes\Fillable;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

#[Fillable(['lesson_plan_id', 'version_number', 'content', 'created_by'])]
class LessonPlanVersion extends Model
{
    /** @use HasFactory<LessonPlanVersionFactory> */
    use HasFactory;

    protected function casts(): array
    {
        return ['content' => 'array'];
    }

    public function lessonPlan(): BelongsTo
    {
        return $this->belongsTo(LessonPlan::class);
    }

    public function creator(): BelongsTo
    {
        return $this->belongsTo(User::class, 'created_by');
    }
}
