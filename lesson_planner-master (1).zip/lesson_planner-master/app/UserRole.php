<?php

namespace App;

enum UserRole: string
{
    case Teacher = 'teacher';
    case Administrator = 'administrator';
}
