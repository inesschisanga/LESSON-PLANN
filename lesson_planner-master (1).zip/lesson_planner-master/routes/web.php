<?php

use App\Http\Controllers\Admin\DashboardController as AdminDashboardController;
use App\Http\Controllers\Admin\UserController;
use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\Auth\RegisteredUserController;
use App\Http\Controllers\AvatarController;
use App\Http\Controllers\CommunityController;
use App\Http\Controllers\DashboardController;
use App\Http\Controllers\GeneratedLessonPlanController;
use App\Http\Controllers\LessonPlanController;
use App\Http\Controllers\LessonPlanExportController;
use App\Http\Controllers\LessonPlanSocialController;
use App\Http\Controllers\ProfileController;
use Illuminate\Support\Facades\Route;

Route::view('/', 'welcome')->name('home');
Route::get('/avatars/{seed}', AvatarController::class)->where('seed', '.*')->name('avatars.show');

Route::middleware('guest')->group(function (): void {
    Route::get('/register', [RegisteredUserController::class, 'create'])->name('register');
    Route::post('/register', [RegisteredUserController::class, 'store']);
    Route::get('/login', [AuthenticatedSessionController::class, 'create'])->name('login');
    Route::post('/login', [AuthenticatedSessionController::class, 'store'])->middleware('throttle:login');
    Route::get('/forgot-password', [PasswordResetLinkController::class, 'create'])->name('password.request');
    Route::post('/forgot-password', [PasswordResetLinkController::class, 'store'])->name('password.email');
    Route::get('/reset-password/{token}', [NewPasswordController::class, 'create'])->name('password.reset');
    Route::post('/reset-password', [NewPasswordController::class, 'store'])->name('password.update');
});

Route::middleware('auth')->group(function (): void {
    Route::post('/logout', [AuthenticatedSessionController::class, 'destroy'])->name('logout');
    Route::get('/dashboard', DashboardController::class)->name('dashboard');
    Route::get('/community', [CommunityController::class, 'index'])->name('community.index');
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::put('/profile/password', [ProfileController::class, 'updatePassword'])->name('profile.password.update');

    Route::get('/lesson-plans/generate', [GeneratedLessonPlanController::class, 'create'])->name('lesson-plans.generate');
    Route::post('/lesson-plans/generate', [GeneratedLessonPlanController::class, 'store'])
        ->middleware('throttle:lesson-generation')
        ->name('lesson-plans.generate.store');
    Route::get('/lesson-plans/generated/preview', [GeneratedLessonPlanController::class, 'preview'])->name('lesson-plans.generated.preview');
    Route::resource('lesson-plans', LessonPlanController::class);
    Route::get('/lesson-plans/{lesson_plan}/export', LessonPlanExportController::class)->name('lesson-plans.export');
    Route::post('/lesson-plans/{lesson_plan}/like', [LessonPlanSocialController::class, 'toggleLike'])->name('lesson-plans.like');
    Route::post('/lesson-plans/{lesson_plan}/comments', [LessonPlanSocialController::class, 'comment'])->name('lesson-plans.comments.store');

    Route::prefix('admin')->name('admin.')->group(function (): void {
        Route::get('/', AdminDashboardController::class)->name('dashboard');
        Route::get('/users', [UserController::class, 'index'])->name('users.index');
        Route::patch('/users/{user}', [UserController::class, 'update'])->name('users.update');
    });
});
