<x-layouts.app>
    <x-slot:title>Good {{ now()->hour < 12 ? 'morning' : (now()->hour < 18 ? 'afternoon' : 'evening') }}, {{ str(auth()->user()->name)->before(' ') }}.</x-slot:title>
    <x-slot:eyebrow>Teaching workspace</x-slot:eyebrow>
    <x-slot:actions><button type="button" data-open-new-lesson class="primary-button gap-2"><i data-lucide="plus" class="size-4" aria-hidden="true"></i>Start a lesson</button></x-slot:actions>

    @if (! auth()->user()->school)
        <section class="mb-6 flex flex-col gap-3 rounded-2xl border border-amber-200 bg-amber-50 px-4 py-3 text-amber-950 sm:flex-row sm:items-center sm:justify-between">
            <div class="flex min-w-0 items-start gap-3"><span class="grid size-9 shrink-0 place-items-center rounded-full bg-amber-100 text-amber-700"><i data-lucide="circle-alert" class="size-4" aria-hidden="true"></i></span><div class="min-w-0"><p class="text-sm font-semibold">Complete your profile</p><p class="mt-0.5 truncate text-xs text-amber-800">Add your school so lesson plans have the right context.</p></div></div>
            <a class="inline-flex shrink-0 items-center gap-1.5 text-sm font-semibold text-amber-800 underline decoration-amber-300 underline-offset-4 hover:text-amber-950" href="{{ route('profile.edit') }}">Add school <i data-lucide="arrow-up-right" class="size-3.5" aria-hidden="true"></i></a>
        </section>
    @endif

    <section class="grid gap-4 border-y border-ash bg-white sm:grid-cols-2 xl:grid-cols-3">
        @foreach ([['Public lessons', $counts['public']], ['Private lessons', $counts['private']]] as [$label, $count])
            <div class="border-b border-ash p-5 sm:border-b-0 sm:border-r last:border-r-0 sm:p-6"><p class="text-xs font-medium uppercase tracking-[.12em] text-graphite">{{ $label }}</p><p class="mt-5 text-5xl font-medium tracking-[-.05em]">{{ $count }}</p></div>
        @endforeach
    </section>

    <section class="mt-10 grid gap-6 xl:grid-cols-[1.2fr_.8fr]">
        <div class="panel">
            <div class="flex items-center justify-between"><div><p class="section-kicker">Your desk</p><h2 class="mt-2 text-2xl font-medium">Recent lessons</h2></div><a href="{{ route('lesson-plans.index') }}" class="text-sm underline">View all</a></div>
            <div class="mt-6 divide-y divide-ash">
                @forelse ($recentPlans as $plan)<a href="{{ route('lesson-plans.show', $plan) }}" class="group flex items-center justify-between gap-4 py-5 first:pt-0"><div><p class="font-medium group-hover:underline">{{ $plan->title }}</p><p class="mt-1 text-sm text-graphite">{{ $plan->class_level }} · {{ $plan->topic }}</p></div><div class="flex items-center gap-3"><span class="hidden text-xs text-graphite sm:inline">#{{ $loop->iteration }} · {{ $plan->updated_at->diffForHumans() }}</span><span class="rounded-full bg-mint px-3 py-1 text-xs font-medium text-primary">{{ $plan->visibility->label() }}</span></div></a>@empty
                    <x-empty-state title="Your next lesson starts with a topic." description="Build one section at a time or let the planner sketch a first draft for you."><a class="primary-button gap-2" href="{{ route('lesson-plans.create') }}"><i data-lucide="plus" class="size-4" aria-hidden="true"></i>Plan manually</a><button type="button" data-open-generator class="secondary-button gap-2"><i data-lucide="sparkles" class="size-4" aria-hidden="true"></i>Use AI</button></x-empty-state>
                @endforelse
            </div>
        </div>
        <div class="grid gap-6">
            <div class="panel bg-primary text-white"><p class="section-kicker text-white/70">A clear next move</p><h2 class="mt-4 text-3xl font-medium leading-tight tracking-[-.04em]">Turn a topic into a classroom-ready lesson.</h2><p class="mt-4 text-sm leading-6 text-white/75">Start with a blank structure or ask for a considered first draft.</p><div class="mt-7 flex flex-wrap gap-3"><button type="button" data-open-generator class="secondary-button gap-2 border-white bg-white text-primary"><i data-lucide="sparkles" class="size-4" aria-hidden="true"></i>Use AI</button><a class="secondary-button gap-2 border-white text-white" href="{{ route('lesson-plans.create') }}"><i data-lucide="plus" class="size-4" aria-hidden="true"></i>Plan manually</a></div></div>
            <div class="panel"><div class="flex items-center justify-between"><div><p class="section-kicker">Teaching network</p><h2 class="mt-2 text-xl font-medium">Share a lesson</h2></div><a class="text-sm underline" href="{{ route('community.index') }}">Open community</a></div><div class="mt-5 rounded-xl bg-parchment p-4"><p class="text-sm leading-6 text-graphite">Publish a lesson plan when you want other teachers to read, like, and comment on it.</p><a class="mt-4 inline-flex text-sm font-medium text-primary underline" href="{{ route('lesson-plans.create') }}">Create a lesson</a></div></div>
        </div>
    </section>
</x-layouts.app>
