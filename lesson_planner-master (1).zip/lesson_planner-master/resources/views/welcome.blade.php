@extends('layouts.app')

@section('title', 'Better ICT lessons, built together')
@section('description', 'Lesson Studio helps secondary-school ICT teachers plan, improve, and share lessons in one focused workspace.')
@section('content')
        <a href="#main-content" class="sr-only fixed left-4 top-4 z-50 rounded-full bg-primary px-5 py-3 text-sm font-medium text-white focus:not-sr-only">
            Skip to content
        </a>

        <main id="main-content">
            <section class="px-3 pb-3 sm:px-5 sm:pb-5">
                <div class="mx-auto flex min-h-[620px] max-w-[1440px] items-center justify-center px-6 py-16 text-center sm:px-10 lg:min-h-[680px] lg:px-16">
                    <div class="flex w-full max-w-4xl flex-col items-center justify-center gap-12">
                        <div class="max-w-3xl">
                            <h1 class="text-[clamp(3.5rem,8vw,7.5rem)] font-medium leading-[0.86] tracking-[-0.055em]">
                                Better lessons.<br>Built together.
                            </h1>
                        </div>

                        <div class="max-w-2xl">
                            <p class="mx-auto max-w-xl text-lg leading-7 text-graphite sm:text-xl sm:leading-8">
                                Plan with structure, improve with optional AI guidance, and share the lessons you want the teaching community to build on.
                            </p>
                            <div class="mt-8 flex flex-wrap items-center justify-center gap-5">
                                <a href="{{ auth()->check() ? route('dashboard') : route('register') }}" class="inline-flex min-h-14 items-center justify-center rounded-full bg-primary px-7 text-base font-medium text-white transition-colors hover:bg-primary-dark focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-primary">
                                    Create your first plan
                                </a>
                                <a href="#workflow" class="border-b border-ink pb-1 text-sm font-medium focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ink">
                                    See the workflow
                                </a>
                            </div>
                        </div>
                    </div>

                    <div class="hidden" aria-hidden="true">
                        <div class="pointer-events-none absolute -right-24 -top-24 size-80 rounded-full border border-primary/15" aria-hidden="true"></div>
                        <div class="pointer-events-none absolute -right-6 -top-6 size-48 rounded-full border border-primary/15" aria-hidden="true"></div>

                        <div class="hero-window relative mx-auto max-w-3xl overflow-hidden rounded-t-[24px] bg-white">
                            <div class="flex items-center justify-between border-b border-ash px-4 py-4 sm:px-6">
                                <div class="flex items-center gap-3">
                                    <img src="{{ asset('lesson-planner-logo.svg') }}" alt="" class="size-8 object-contain">
                                    <div>
                                        <p class="text-sm font-medium">Introduction to networks</p>
                                        <p class="text-xs text-graphite">Form 3 · 40 minutes</p>
                                    </div>
                                </div>
                                <span class="rounded-full bg-mint px-3 py-1.5 text-xs font-medium text-primary">Draft saved</span>
                            </div>

                            <div class="grid sm:grid-cols-[140px_1fr]">
                                <div class="hidden border-r border-ash bg-parchment p-4 sm:block">
                                    <p class="mb-4 text-[10px] font-medium uppercase tracking-[0.12em] text-graphite">Lesson sections</p>
                                    <ol class="grid gap-2 text-xs">
                                        <li class="rounded-lg bg-white px-3 py-2.5 font-medium">Lesson details</li>
                                        <li class="px-3 py-2.5 text-graphite">Objectives</li>
                                        <li class="px-3 py-2.5 text-graphite">Activities</li>
                                        <li class="px-3 py-2.5 text-graphite">Assessment</li>
                                        <li class="px-3 py-2.5 text-graphite">Reflection</li>
                                    </ol>
                                </div>

                                <div class="p-5 sm:p-7">
                                    <div class="flex items-start justify-between gap-4 border-b border-ash pb-5">
                                        <div>
                                            <p class="text-[10px] font-medium uppercase tracking-[0.12em] text-graphite">Learning objective</p>
                                            <p class="mt-2 text-base font-medium leading-6">By the end of the lesson, learners will explain how devices share data across a local network.</p>
                                        </div>
                                        <svg class="mt-1 size-5 shrink-0 text-graphite" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.7" aria-hidden="true">
                                            <path d="M12 20h9" /><path d="M16.5 3.5a2.12 2.12 0 0 1 3 3L8 18l-4 1 1-4Z" />
                                        </svg>
                                    </div>

                                    <div class="py-5">
                                        <div class="mb-3 flex items-center justify-between gap-4">
                                            <p class="text-[10px] font-medium uppercase tracking-[0.12em] text-graphite">Teaching activity</p>
                                            <span class="text-xs text-graphite">15 min</span>
                                        </div>
                                        <p class="text-sm leading-6 text-graphite">Learners map the classroom devices, then work in pairs to trace how a file moves from one computer to another.</p>
                                    </div>

                                    <div class="rounded-[18px] bg-parchment p-4 sm:p-5">
                                        <div class="flex items-center gap-2">
                                            <span class="grid size-6 place-items-center rounded-full bg-mint text-primary" aria-hidden="true">
                                                <svg class="size-3.5" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="m12 3-1.4 4.1a2 2 0 0 1-1.3 1.3L5.2 10l4.1 1.4a2 2 0 0 1 1.3 1.3L12 17l1.4-4.3a2 2 0 0 1 1.3-1.3l4.1-1.4-4.1-1.6a2 2 0 0 1-1.3-1.3Z" /></svg>
                                            </span>
                                            <p class="text-xs font-medium">AI suggestion</p>
                                        </div>
                                        <p class="mt-3 text-sm leading-5">Add one check-for-understanding before pair work.</p>
                                        <div class="mt-4 flex gap-4 text-xs font-medium">
                                            <span class="border-b border-ink pb-0.5">Use suggestion</span>
                                            <span class="text-graphite">Dismiss</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section class="border-b border-ash bg-white" aria-label="Product principles">
                <div class="mx-auto grid max-w-site divide-y divide-ash px-5 sm:px-8 md:grid-cols-3 md:divide-x md:divide-y-0 lg:px-10">
                    <div class="flex items-center gap-4 py-7 md:pr-8">
                        <span class="text-2xl" aria-hidden="true">◎</span>
                        <p class="text-sm leading-5">Designed around real ICT lesson sections</p>
                    </div>
                    <div class="flex items-center gap-4 py-7 md:px-8">
                        <span class="text-2xl" aria-hidden="true">✦</span>
                        <p class="text-sm leading-5">AI suggests; the teacher always decides</p>
                    </div>
                    <div class="flex items-center gap-4 py-7 md:pl-8">
                        <span class="text-2xl" aria-hidden="true">↻</span>
                        <p class="text-sm leading-5">You choose what stays private or goes public</p>
                    </div>
                </div>
            </section>

            <section id="workflow" class="bg-white px-5 py-24 sm:px-8 sm:py-32 lg:px-10">
                <div class="mx-auto max-w-site">
                    <div class="grid gap-10 lg:grid-cols-[1fr_0.9fr] lg:items-end">
                        <h2 class="max-w-4xl text-[clamp(2.8rem,6vw,5.8rem)] font-medium leading-[0.92] tracking-[-0.045em]">
                            One clear path from first idea to a lesson worth sharing.
                        </h2>
                        <p class="max-w-md text-lg leading-7 text-graphite lg:justify-self-end">
                            Keep planning, publishing, and conversation together—without turning the work into paperwork.
                        </p>
                    </div>

                    <ol class="mt-16 grid border-y border-ash md:grid-cols-4 md:divide-x md:divide-ash">
                        <li class="border-b border-ash py-8 md:border-b-0 md:px-7 md:first:pl-0">
                            <span class="text-sm font-medium text-graphite">01</span>
                            <svg class="mt-10 size-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M4 19.5V6a2 2 0 0 1 2-2h8l4 4v11.5a.5.5 0 0 1-.5.5h-13a.5.5 0 0 1-.5-.5Z" /><path d="M14 4v4h4M8 12h6M8 16h6" /></svg>
                            <h3 class="mt-7 text-2xl font-medium tracking-tight">Plan</h3>
                            <p class="mt-3 text-sm leading-6 text-graphite">Work through a focused ICT lesson structure and save at any point.</p>
                        </li>
                        <li class="border-b border-ash py-8 md:border-b-0 md:px-7">
                            <span class="text-sm font-medium text-graphite">02</span>
                            <svg class="mt-10 size-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="m12 3-1.5 4.2a2 2 0 0 1-1.3 1.3L5 10l4.2 1.5a2 2 0 0 1 1.3 1.3L12 17l1.5-4.2a2 2 0 0 1 1.3-1.3L19 10l-4.2-1.5a2 2 0 0 1-1.3-1.3Z" /><path d="m5 16-.7 2-2 .7 2 .7.7 2 .7-2 2-.7-2-.7Z" /></svg>
                            <h3 class="mt-7 text-2xl font-medium tracking-tight">Improve</h3>
                            <p class="mt-3 text-sm leading-6 text-graphite">Ask for bounded suggestions on objectives, activities, and alignment.</p>
                        </li>
                        <li class="border-b border-ash py-8 md:border-b-0 md:px-7">
                            <span class="text-sm font-medium text-graphite">03</span>
                            <svg class="mt-10 size-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M8 7V5a3 3 0 0 1 6 0v2M5 7h12a2 2 0 0 1 2 2v9a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2V9a2 2 0 0 1 2-2Z" /><path d="m8 14 2 2 5-5" /></svg>
                            <h3 class="mt-7 text-2xl font-medium tracking-tight">Share</h3>
                            <p class="mt-3 text-sm leading-6 text-graphite">Publish the lessons you want other teachers to discover.</p>
                        </li>
                        <li class="py-8 md:px-7 md:last:pr-0">
                            <span class="text-sm font-medium text-graphite">04</span>
                            <svg class="mt-10 size-8" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" aria-hidden="true"><path d="M20 7h-9a7 7 0 1 0 7 7" /><path d="m16 3 4 4-4 4" /></svg>
                            <h3 class="mt-7 text-2xl font-medium tracking-tight">Discuss</h3>
                            <p class="mt-3 text-sm leading-6 text-graphite">Collect likes and comments around practical classroom ideas.</p>
                        </li>
                    </ol>
                </div>
            </section>

            <section id="ai-assistance" class="bg-parchment px-5 py-24 sm:px-8 sm:py-32 lg:px-10">
                <div class="mx-auto grid max-w-site gap-16 lg:grid-cols-[0.82fr_1.18fr] lg:items-center">
                    <div class="max-w-lg">
                        <p class="text-xs font-medium uppercase tracking-[0.12em] text-graphite">AI that knows its place</p>
                        <h2 class="mt-6 text-[clamp(2.7rem,5vw,4.8rem)] font-medium leading-[0.94] tracking-[-0.045em]">
                            A second look, never the final word.
                        </h2>
                        <p class="mt-7 text-lg leading-7 text-graphite">
                            Request a concise suggestion when you need it. Nothing is inserted into your lesson until you choose to use or edit it.
                        </p>
                        <ul class="mt-9 grid gap-4 text-sm">
                            <li class="flex items-center gap-3"><span class="grid size-6 place-items-center rounded-full bg-mint text-xs text-primary">✓</span> Sharpen a learning objective</li>
                            <li class="flex items-center gap-3"><span class="grid size-6 place-items-center rounded-full bg-mint text-xs text-primary">✓</span> Check activity and assessment alignment</li>
                            <li class="flex items-center gap-3"><span class="grid size-6 place-items-center rounded-full bg-mint text-xs text-primary">✓</span> Spot a missing lesson section</li>
                        </ul>
                    </div>

                    <div class="overflow-hidden rounded-[28px] bg-white">
                        <div class="flex items-center justify-between border-b border-ash px-6 py-5 sm:px-8">
                            <div>
                                <p class="text-sm font-medium">Assessment</p>
                                <p class="mt-1 text-xs text-graphite">Introduction to networks</p>
                            </div>
                            <span class="rounded-full bg-parchment px-3 py-1.5 text-xs text-graphite">Teacher draft</span>
                        </div>
                        <div class="p-6 sm:p-8">
                            <div class="rounded-[18px] border border-ash p-5">
                                <p class="text-sm leading-6">Learners will answer five written questions about computer networks.</p>
                            </div>

                            <div class="mt-5 rounded-[18px] bg-mint p-5 sm:p-6">
                                <div class="flex items-center justify-between gap-4">
                                    <div class="flex items-center gap-2">
                                        <span class="grid size-7 place-items-center rounded-full bg-white" aria-hidden="true">✦</span>
                                        <p class="text-xs font-medium uppercase tracking-[0.12em]">AI suggestion</p>
                                    </div>
                                    <span class="text-xs">Optional</span>
                                </div>
                                <p class="mt-6 text-xl font-medium leading-7 tracking-tight">Add a short network-mapping task so learners demonstrate the objective, not only recall terms.</p>
                                <p class="mt-3 text-sm leading-6 text-ink/65">Reason: the objective asks learners to explain how devices share data.</p>
                                <div class="mt-7 flex flex-wrap gap-3">
                                    <button type="button" class="min-h-11 rounded-full bg-ink px-5 text-sm font-medium text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ink">Use suggestion</button>
                                    <button type="button" class="min-h-11 rounded-full border border-ink px-5 text-sm font-medium focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ink">Edit first</button>
                                    <button type="button" class="min-h-11 px-3 text-sm font-medium text-ink/65 underline-offset-4 hover:underline focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-ink">Dismiss</button>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </section>

            <section id="community" class="bg-white px-5 py-24 sm:px-8 sm:py-32 lg:px-10">
                <div class="mx-auto max-w-site">
                    <div class="grid gap-10 lg:grid-cols-2 lg:items-end">
                        <div>
                            <p class="text-xs font-medium uppercase tracking-[0.12em] text-graphite">Community lessons, with context</p>
                            <h2 class="mt-6 max-w-3xl text-[clamp(2.8rem,5.5vw,5.4rem)] font-medium leading-[0.92] tracking-[-0.045em]">
                                Share ideas that travel.
                            </h2>
                        </div>
                        <p class="max-w-md text-lg leading-7 text-graphite lg:justify-self-end">
                            Publish a lesson when it is ready. Other teachers can open it, like it, and add a useful comment.
                        </p>
                    </div>

                    <div class="mt-16 grid gap-5 lg:grid-cols-[1.2fr_0.8fr]">
                        <article class="rounded-[28px] bg-parchment p-6 sm:p-10">
                            <div class="flex flex-wrap items-center justify-between gap-4 border-b border-ash pb-6">
                                <div>
                                    <p class="text-xs text-graphite">Public lesson</p>
                                    <h3 class="mt-1 text-2xl font-medium tracking-tight">Data security and strong passwords</h3>
                                </div>
                                <span class="rounded-full bg-white px-4 py-2 text-xs font-medium">12 likes</span>
                            </div>
                            <div class="mt-7 grid gap-4 sm:grid-cols-2">
                                <div class="rounded-[18px] bg-white p-5">
                                    <div class="flex items-center justify-between gap-4">
                                        <p class="text-sm font-medium">Learning objectives</p>
                                        <span class="text-sm" aria-label="Four out of five">●●●●○</span>
                                    </div>
                                    <p class="mt-5 text-sm leading-6 text-graphite">A clear, practical lesson that another teacher can open and adapt.</p>
                                </div>
                                <div class="rounded-[18px] bg-white p-5">
                                    <div class="flex items-center justify-between gap-4">
                                        <p class="text-sm font-medium">Activity alignment</p>
                                        <span class="text-sm" aria-label="Five out of five">●●●●●</span>
                                    </div>
                                    <p class="mt-5 text-sm leading-6 text-graphite">Comments keep the best classroom context close to the plan.</p>
                                </div>
                            </div>
                            <div class="mt-4 flex items-center gap-3 rounded-[18px] border border-ash px-5 py-4 text-sm">
                                <span class="grid size-7 shrink-0 place-items-center rounded-full bg-mint text-primary">✓</span>
                                Public posts are shared by choice; private plans stay in your workspace.
                            </div>
                        </article>

                        <aside class="flex flex-col justify-between rounded-[28px] bg-charcoal p-7 text-white sm:p-10">
                            <div>
                                <p class="text-xs font-medium uppercase tracking-[0.12em] text-white/55">A visible history</p>
                                <div class="mt-10 border-l border-white/20 pl-7">
                                    <div class="relative pb-10">
                                        <span class="absolute -left-[33px] top-1 size-3 rounded-full bg-mint"></span>
                                    <p class="text-sm font-medium">Conversation started</p>
                                    <p class="mt-2 text-sm leading-6 text-white/55">Another teacher added a practical suggestion.</p>
                                    </div>
                                    <div class="relative pb-10">
                                        <span class="absolute -left-[33px] top-1 size-3 rounded-full bg-white"></span>
                                        <p class="text-sm font-medium">Lesson liked</p>
                                        <p class="mt-2 text-sm leading-6 text-white/55">The community found the activity useful.</p>
                                    </div>
                                    <div class="relative">
                                        <span class="absolute -left-[33px] top-1 size-3 rounded-full border border-white/50 bg-charcoal"></span>
                                        <p class="text-sm font-medium">Published</p>
                                        <p class="mt-2 text-sm leading-6 text-white/55">The teacher chose to make this lesson public.</p>
                                    </div>
                                </div>
                            </div>
                            <p class="mt-14 text-3xl font-medium leading-9 tracking-tight">Nothing useful gets lost between versions.</p>
                        </aside>
                    </div>
                </div>
            </section>

            <section id="join" class="px-3 pb-3 sm:px-5 sm:pb-5">
                <div class="mx-auto flex max-w-[1440px] flex-col items-center rounded-[28px] bg-primary px-6 py-24 text-center text-white sm:px-10 sm:py-32">
                    <p class="text-xs font-medium uppercase tracking-[0.12em] text-white/70">Your next lesson starts here</p>
                    <h2 class="mt-7 max-w-5xl text-[clamp(3.2rem,7.5vw,7rem)] font-medium leading-[0.88] tracking-[-0.055em]">
                        Give good ideas a better structure.
                    </h2>
                    <p class="mt-8 max-w-xl text-lg leading-7 text-white/75">Create, improve, share, and revisit ICT lesson plans in one teacher-first workspace.</p>
                    <a href="mailto:hello@lessonplanner.example" class="mt-10 inline-flex min-h-14 items-center justify-center rounded-full bg-white px-7 text-base font-medium text-primary transition-colors hover:bg-mint focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-white">
                        Join the early access list
                    </a>
                </div>
            </section>
        </main>

@endsection
