<div class="grid gap-6">
@forelse ($posts as $post)
    @php($content = $post->currentVersion?->content ?? [])
    @php($isLiked = in_array($post->id, $likedPlanIds, true))
    <article class="overflow-hidden rounded-3xl border border-[#dfe3e6] bg-white shadow-[0_3px_12px_rgba(20,20,15,0.035)]" id="lesson-post-{{ $post->id }}">
        <div class="flex items-center gap-4 px-6 py-5 sm:px-7">
            <div class="flex min-w-0 items-center gap-3">
                <img src="{{ route('avatars.show', ['seed' => $post->user->avatarSeed(), 'size' => 44, 'v' => 'moods']) }}" alt="" class="size-11 shrink-0 rounded-full object-cover ring-4 ring-mint/60">
                <div class="min-w-0"><p class="truncate text-sm font-semibold">{{ $post->user->name }}</p><p class="mt-0.5 truncate text-xs text-graphite">{{ $post->user->school ?: 'Lesson Studio community' }} · {{ $post->updated_at->diffForHumans() }}</p></div>
            </div>
        </div>
        <button type="button" data-open-lesson="{{ $post->id }}" class="block w-full border-y border-[#e7ebed] bg-[#fbfcfc] px-6 py-7 text-left hover:bg-canvas sm:px-7">
            <h2 class="text-xl font-semibold tracking-tight">{{ $post->title }}</h2>
            <div class="mt-2 flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-graphite"><span>{{ $post->class_level }}</span><span aria-hidden="true">·</span><span>{{ $post->topic }}</span><span aria-hidden="true">·</span><span>{{ $post->duration_minutes }} minutes</span></div>
            <p class="mt-6 line-clamp-3 text-sm leading-6 text-graphite">{{ strip_tags((string) data_get($content, 'lesson_components.lesson_goal', 'A classroom-ready lesson shared with the community.')) }}</p>
            <span class="mt-6 inline-flex items-center gap-2 text-sm font-semibold text-primary">Open lesson plan <i data-lucide="arrow-up-right" class="size-4" aria-hidden="true"></i></span>
        </button>
        <div class="flex items-center justify-between gap-4 px-6 py-4 text-xs text-graphite sm:px-7"><span class="inline-flex items-center gap-1.5"><i data-lucide="heart" class="size-3.5" aria-hidden="true"></i><span data-like-count="{{ $post->id }}">{{ $post->likes_count }}</span> {{ str('like')->plural($post->likes_count) }}</span><span class="inline-flex items-center gap-1.5"><i data-lucide="message-circle" class="size-3.5" aria-hidden="true"></i>{{ $post->comments_count }} {{ str('comment')->plural($post->comments_count) }}</span></div>
        <div class="grid grid-cols-2 border-t border-ash px-4 py-3 sm:px-5">
            <form method="POST" action="{{ route('lesson-plans.like', $post) }}" data-like-form="{{ $post->id }}">@csrf<button type="submit" data-like-button data-no-loading aria-pressed="{{ $isLiked ? 'true' : 'false' }}" class="flex w-full items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium {{ $isLiked ? 'text-primary' : 'text-graphite hover:text-primary' }}"><i data-lucide="heart" data-like-icon class="size-4 {{ $isLiked ? 'fill-current' : '' }}" aria-hidden="true"></i><span data-like-label>{{ $isLiked ? 'Liked' : 'Like' }}</span></button></form>
            <button type="button" data-open-lesson="{{ $post->id }}" class="flex items-center justify-center gap-2 rounded-xl px-3 py-2.5 text-sm font-medium text-graphite hover:text-primary"><i data-lucide="message-circle" class="size-4" aria-hidden="true"></i>Comment</button>
        </div>
    </article>

    <div data-lesson-modal="{{ $post->id }}" class="fixed inset-0 z-[70] hidden items-center justify-center bg-ink/45 p-4" role="dialog" aria-modal="true" aria-labelledby="lesson-modal-title-{{ $post->id }}">
        <div class="max-h-[90vh] w-full max-w-2xl overflow-y-auto rounded-2xl border border-ash bg-white">
            <div class="sticky top-0 flex items-start justify-between gap-5 border-b border-ash bg-white px-5 py-4 sm:px-7"><div><p class="text-xs font-medium uppercase tracking-[.1em] text-primary">Community lesson</p><h2 id="lesson-modal-title-{{ $post->id }}" class="mt-1 text-xl font-semibold tracking-tight">{{ $post->title }}</h2><p class="mt-1 text-sm text-graphite">{{ $post->class_level }} · {{ $post->topic }} · {{ $post->duration_minutes }} minutes</p></div><button type="button" data-close-lesson="{{ $post->id }}" class="grid size-9 shrink-0 place-items-center rounded-full border border-ash text-graphite hover:bg-canvas" aria-label="Close lesson"><i data-lucide="x" class="size-4" aria-hidden="true"></i></button></div>
            <div class="grid gap-6 px-5 py-6 sm:px-7"><div><p class="text-xs font-medium uppercase tracking-[.1em] text-graphite">Lesson goal</p><p class="mt-2 text-sm leading-6">{{ strip_tags((string) data_get($content, 'lesson_components.lesson_goal', 'No lesson goal added.')) }}</p></div><div><p class="text-xs font-medium uppercase tracking-[.1em] text-graphite">Prior knowledge</p><p class="mt-2 text-sm leading-6 text-graphite">{{ strip_tags((string) data_get($content, 'lesson_components.prior_knowledge', 'No prior knowledge note added.')) }}</p></div><div><p class="text-xs font-medium uppercase tracking-[.1em] text-graphite">Teaching sequence</p><div class="mt-3 divide-y divide-ash rounded-xl border border-ash">@foreach (data_get($content, 'teaching_learning_activities', []) as $activity)<div class="grid gap-2 p-4 sm:grid-cols-[150px_1fr]"><div><p class="text-sm font-medium">{{ data_get($activity, 'stage') }}</p><p class="mt-1 text-xs text-graphite">{{ data_get($activity, 'duration') }}</p></div><p class="text-sm leading-6 text-graphite">{{ strip_tags((string) data_get($activity, 'teacher_activity')) }}</p></div>@endforeach</div></div><div><p class="text-xs font-medium uppercase tracking-[.1em] text-graphite">Conversation</p><div class="mt-3 grid gap-3">@forelse ($post->comments as $comment)<div class="rounded-xl bg-canvas px-4 py-3"><p class="text-xs font-semibold">{{ $comment->user->name }}</p><p class="mt-1 text-sm leading-6 text-graphite">{{ $comment->body }}</p></div>@empty<p class="rounded-xl border border-dashed border-ash px-4 py-5 text-sm text-graphite">No comments yet. Start the conversation.</p>@endforelse</div><form method="POST" action="{{ route('lesson-plans.comments.store', $post) }}" class="mt-4 flex gap-2">@csrf<input class="form-control mt-0 min-w-0 flex-1" name="body" placeholder="Add a thoughtful comment…" required maxlength="2000"><button class="primary-button shrink-0 px-4">Post</button></form></div></div>
        </div>
    </div>
@empty
    <x-empty-state type="{{ request('search') ? 'search' : 'inbox' }}" title="{{ request('search') ? 'No lessons match your search' : 'No public lessons yet' }}" description="{{ request('search') ? 'Try a different topic, class, or lesson title.' : 'When teachers publish a lesson plan, it will appear here for the community.' }}"><a class="primary-button gap-2" href="{{ route('lesson-plans.create') }}"><i data-lucide="plus" class="size-4" aria-hidden="true"></i>Create lesson</a></x-empty-state>
@endforelse
</div>

@if (method_exists($posts, 'links'))
    <div>{{ $posts->links() }}</div>
@endif
