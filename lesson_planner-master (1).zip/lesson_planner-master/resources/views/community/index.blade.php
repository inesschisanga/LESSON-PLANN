<x-layouts.app>
    <x-slot:title>Community</x-slot:title>
    <x-slot:header>
        <div class="sticky top-16 z-30 -mx-4 mb-5 border-b border-[#dfe3e6] bg-[#eef1f3]/95 px-4 pb-4 pt-1 backdrop-blur sm:-mx-6 sm:px-6">
            <div class="mx-auto w-full max-w-2xl">
                <div class="flex items-center justify-between gap-4"><h1 class="text-2xl font-semibold tracking-tight sm:text-3xl">Community</h1><a class="primary-button min-h-10 shrink-0 gap-2 px-4" href="{{ route('lesson-plans.create') }}"><i data-lucide="plus" class="size-4" aria-hidden="true"></i><span class="hidden sm:inline">Create lesson</span><span class="sm:hidden">Create</span></a></div>
                <form method="GET" action="{{ route('community.index') }}" class="mt-4" data-live-search="community">
                    <label class="flex min-h-11 w-full items-center gap-2 rounded-full border border-[#dfe3e6] bg-white px-4 text-graphite"><i data-lucide="search" class="size-4 shrink-0" aria-hidden="true"></i><span class="sr-only">Search public lesson plans</span><input class="w-full border-0 bg-transparent p-0 text-sm outline-none placeholder:text-graphite" type="search" name="search" value="{{ request('search') }}" placeholder="Search public lessons, topics, or classes"></label>
                </form>
            </div>
        </div>
    </x-slot:header>

    <div class="mx-auto grid w-full max-w-2xl gap-4">
        <div data-live-search-results="community" class="w-full">
            @include('community._feed', ['posts' => $posts, 'likedPlanIds' => $likedPlanIds])
        </div>
    </div>
</x-layouts.app>
