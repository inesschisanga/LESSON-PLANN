@php($input = 'mt-2 w-full rounded-xl border border-ash bg-white px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-primary/20')
<div class="grid gap-8">
    <section class="panel">
        <div class="mb-6"><p class="section-kicker">01 · Context</p><h2 class="section-title">Lesson details</h2></div>
        <div class="grid gap-5 sm:grid-cols-2 lg:grid-cols-3">
            <x-field label="School" name="school"><input class="{{ $input }}" name="school" value="{{ old('school', data_get($plan, 'school')) }}"></x-field>
            <x-field label="Teacher" name="teacher"><input class="{{ $input }}" name="teacher" value="{{ old('teacher', data_get($plan, 'teacher')) }}"></x-field>
            <x-field label="Date" name="date"><input class="{{ $input }}" type="date" name="date" value="{{ old('date', data_get($plan, 'date')) }}" required></x-field>
            <x-field label="Class" name="class"><input class="{{ $input }}" name="class" value="{{ old('class', data_get($plan, 'class')) }}" placeholder="Form 2" required></x-field>
            <x-field label="Subject" name="subject"><input class="{{ $input }} bg-parchment" name="subject" value="ICT" readonly></x-field>
            <x-field label="Duration (minutes)" name="duration"><input class="{{ $input }}" type="number" min="10" max="240" name="duration" value="{{ old('duration', data_get($plan, 'duration', 40)) }}" required></x-field>
            <x-field label="Topic" name="topic"><input class="{{ $input }}" name="topic" value="{{ old('topic', data_get($plan, 'topic')) }}" required></x-field>
            <div class="sm:col-span-2"><x-field label="Lesson title" name="lesson"><input class="{{ $input }}" name="lesson" value="{{ old('lesson', data_get($plan, 'lesson')) }}" required></x-field></div>
            <x-field label="Sharing" name="visibility" hint="Public lessons appear in the community feed. Private lessons stay in your workspace."><select class="{{ $input }}" name="visibility" required><option value="private" @selected(old('visibility', data_get($plan, 'visibility', 'private')) === 'private')>Private · only me</option><option value="public" @selected(old('visibility', data_get($plan, 'visibility')) === 'public')>Public · share with the community</option></select></x-field>
            <x-field label="Boys enrolled" name="enrollment.boys"><input class="{{ $input }}" type="number" min="0" name="enrollment[boys]" value="{{ old('enrollment.boys', data_get($plan, 'enrollment.boys', 0)) }}" required></x-field>
            <x-field label="Girls enrolled" name="enrollment.girls"><input class="{{ $input }}" type="number" min="0" name="enrollment[girls]" value="{{ old('enrollment.girls', data_get($plan, 'enrollment.girls', 0)) }}" required></x-field>
        </div>
    </section>

    <section class="panel">
        <div class="mb-6"><p class="section-kicker">02 · Intent</p><h2 class="section-title">Lesson components</h2></div>
        <div class="grid gap-5">
            @foreach ([
                'general_competence' => 'General competence', 'specific_competence' => 'Specific competence', 'lesson_goal' => 'Lesson goal',
                'rationale' => 'Rationale', 'prior_knowledge' => 'Prior knowledge',
            ] as $key => $label)
                <x-field :label="$label" :name="'lesson_components.'.$key"><textarea class="{{ $input }} min-h-24" name="lesson_components[{{ $key }}]" required>{{ old('lesson_components.'.$key, data_get($plan, 'lesson_components.'.$key)) }}</textarea></x-field>
            @endforeach
            <div class="grid gap-5 sm:grid-cols-2">
                <x-field label="Natural environment" name="lesson_components.learning_environment_setup.natural_environment"><textarea class="{{ $input }} min-h-24" name="lesson_components[learning_environment_setup][natural_environment]">{{ old('lesson_components.learning_environment_setup.natural_environment', data_get($plan, 'lesson_components.learning_environment_setup.natural_environment')) }}</textarea></x-field>
                <x-field label="Artificial environment" name="lesson_components.learning_environment_setup.artificial_environment"><textarea class="{{ $input }} min-h-24" name="lesson_components[learning_environment_setup][artificial_environment]">{{ old('lesson_components.learning_environment_setup.artificial_environment', data_get($plan, 'lesson_components.learning_environment_setup.artificial_environment')) }}</textarea></x-field>
            </div>
            @foreach (['references' => 'References', 'teaching_materials' => 'Teaching materials', 'expected_standards' => 'Expected standards'] as $key => $label)
                @php($items = old('lesson_components.'.$key, data_get($plan, 'lesson_components.'.$key, [])))
                @php($items = empty($items) ? [''] : $items)
                <div><p class="text-sm font-medium">{{ $label }}<span class="ml-1 text-red-600" aria-hidden="true">*</span><span class="sr-only"> required</span></p><div class="mt-2 grid gap-2">@foreach ($items as $index => $value)<input class="{{ $input }} mt-0" name="lesson_components[{{ $key }}][{{ $index }}]" value="{{ $value }}" required>@endforeach</div><p class="mt-1 text-xs text-graphite">Add one item per field. Additional generated items are preserved.</p></div>
            @endforeach
        </div>
    </section>

    <section class="panel">
        <div class="mb-6"><p class="section-kicker">03 · Sequence</p><h2 class="section-title">Teaching and learning activities</h2></div>
        <div class="grid gap-5">
            @foreach (old('teaching_learning_activities', data_get($plan, 'teaching_learning_activities', [])) as $index => $activity)
                <div class="rounded-2xl border border-ash bg-parchment p-5">
                    <div class="grid gap-4 sm:grid-cols-[1fr_180px]"><x-field label="Stage" :name="'teaching_learning_activities.'.$index.'.stage'"><input class="{{ $input }} bg-white font-medium" name="teaching_learning_activities[{{ $index }}][stage]" value="{{ data_get($activity, 'stage') }}" readonly></x-field><x-field label="Time" :name="'teaching_learning_activities.'.$index.'.duration'"><input class="{{ $input }}" name="teaching_learning_activities[{{ $index }}][duration]" value="{{ data_get($activity, 'duration') }}" placeholder="10 minutes" required></x-field></div>
                    <div class="mt-4 grid gap-4 lg:grid-cols-3"><x-field label="Teacher activity" :name="'teaching_learning_activities.'.$index.'.teacher_activity'"><textarea class="{{ $input }} min-h-28" name="teaching_learning_activities[{{ $index }}][teacher_activity]" required>{{ data_get($activity, 'teacher_activity') }}</textarea></x-field><x-field label="Learner activity" :name="'teaching_learning_activities.'.$index.'.learner_activity'"><textarea class="{{ $input }} min-h-28" name="teaching_learning_activities[{{ $index }}][learner_activity]" required>{{ data_get($activity, 'learner_activity') }}</textarea></x-field><x-field label="Assessment criteria" :name="'teaching_learning_activities.'.$index.'.assessment_criteria'"><textarea class="{{ $input }} min-h-28" name="teaching_learning_activities[{{ $index }}][assessment_criteria]" required>{{ data_get($activity, 'assessment_criteria') }}</textarea></x-field></div>
                </div>
            @endforeach
        </div>
    </section>

    <section class="panel">
        <div class="mb-6"><p class="section-kicker">04 · Reflection</p><h2 class="section-title">Lesson evaluation prompts</h2></div>
        @php($evaluations = old('lesson_evaluation', data_get($plan, 'lesson_evaluation', [])))
        @php($evaluations = empty($evaluations) ? [''] : $evaluations)
        <p class="text-sm font-medium">Evaluation evidence<span class="ml-1 text-red-600" aria-hidden="true">*</span><span class="sr-only"> required</span></p><div class="mt-2 grid gap-3">@foreach ($evaluations as $index => $value)<textarea class="{{ $input }} mt-0 min-h-24" name="lesson_evaluation[{{ $index }}]" placeholder="What evidence will show that learners met the lesson goal?" required>{{ $value }}</textarea>@endforeach</div>
    </section>
</div>
