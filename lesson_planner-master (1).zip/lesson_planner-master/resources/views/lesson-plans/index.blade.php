<x-layouts.app>
    <x-slot:title>My lessons</x-slot:title><x-slot:eyebrow>Plan library</x-slot:eyebrow>
    <x-slot:actions><div class="flex gap-2"><a class="secondary-button hidden sm:inline-flex" href="{{ route('lesson-plans.create') }}">Plan manually</a><button type="button" data-open-new-lesson class="primary-button">New lesson</button></div></x-slot:actions>
    @php($activeVisibility = in_array(request('visibility'), ['public', 'private'], true) ? request('visibility') : null)
    <form method="GET" action="{{ route('lesson-plans.index') }}" class="mb-5" data-live-search="lesson-plans">
        <div class="flex w-full max-w-xl items-center">
            <label class="flex min-h-11 min-w-0 flex-1 items-center gap-2 rounded-full border border-[#dfe3e6] bg-white px-4 text-graphite"><i data-lucide="search" class="size-4 shrink-0" aria-hidden="true"></i><span class="sr-only">Search your lesson plans</span><input class="w-full border-0 bg-transparent p-0 text-sm outline-none placeholder:text-graphite" type="search" name="search" value="{{ request('search') }}" placeholder="Search your lessons, topics, or classes"></label>
            @if ($activeVisibility)<input type="hidden" name="visibility" value="{{ $activeVisibility }}">@endif
        </div>
        <div class="mt-4 flex flex-wrap items-center gap-2" aria-label="Filter lesson plans by visibility">
            <a href="{{ route('lesson-plans.index', array_filter(['search' => request('search')])) }}" @class(['rounded-full px-4 py-2 text-xs font-medium', 'bg-primary text-white' => ! in_array($activeVisibility, ['public', 'private'], true), 'bg-white text-graphite ring-1 ring-ash hover:bg-mint hover:text-primary' => in_array($activeVisibility, ['public', 'private'], true)])>All plans</a>
            <a href="{{ route('lesson-plans.index', array_filter(['search' => request('search'), 'visibility' => 'public'])) }}" @class(['rounded-full px-4 py-2 text-xs font-medium', 'bg-primary text-white' => $activeVisibility === 'public', 'bg-white text-graphite ring-1 ring-ash hover:bg-mint hover:text-primary' => $activeVisibility !== 'public'])>Public</a>
            <a href="{{ route('lesson-plans.index', array_filter(['search' => request('search'), 'visibility' => 'private'])) }}" @class(['rounded-full px-4 py-2 text-xs font-medium', 'bg-primary text-white' => $activeVisibility === 'private', 'bg-white text-graphite ring-1 ring-ash hover:bg-mint hover:text-primary' => $activeVisibility !== 'private'])>Private</a>
        </div>
    </form>
    <hr class="mb-6 border-ash">
    <div data-live-search-results="lesson-plans">
        <div class="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            @forelse ($plans as $plan)
                <a href="{{ route('lesson-plans.show', $plan) }}" class="panel group transition-colors hover:border-primary/30">
                    <div class="flex items-start justify-between gap-4"><span class="rounded-full bg-mint px-3 py-1 text-xs font-medium text-primary">{{ $plan->visibility->label() }}</span><span class="text-xs text-graphite">#{{ $plans->firstItem() + $loop->index }}</span></div>
                    <h2 class="mt-8 text-2xl font-medium leading-tight tracking-[-.03em] group-hover:underline">{{ $plan->title }}</h2><p class="mt-3 text-sm text-graphite">{{ $plan->class_level }} · {{ $plan->duration_minutes }} min</p><p class="mt-8 border-t border-ash pt-4 text-xs text-graphite">Updated {{ $plan->updated_at->diffForHumans() }}</p>
                </a>
            @empty
                <div class="panel md:col-span-2 xl:col-span-3"><x-empty-state type="{{ request('search') ? 'search' : 'lesson' }}" title="{{ request('search') ? 'No lessons match your search' : 'Your lesson library is ready' }}" description="{{ request('search') ? 'Try a different search or clear the filter to see more of your work.' : 'Start from a topic or build a lesson section by section.' }}">@if (request('search'))<a class="secondary-button" href="{{ route('lesson-plans.index') }}">Clear search</a>@endif<button type="button" data-open-new-lesson class="primary-button gap-2"><i data-lucide="plus" class="size-4" aria-hidden="true"></i>Create a lesson</button></x-empty-state></div>
            @endforelse
        </div>
        <div class="mt-8">{{ $plans->links() }}</div>
    </div>
</x-layouts.app>
