<x-layouts.guest>
    <x-slot:title>Reset password</x-slot:title><h2 class="text-4xl font-medium tracking-[-.04em]">Reset your password.</h2><p class="mt-3 text-sm leading-6 text-graphite">Enter your email and we’ll send a secure reset link.</p>
    @if (session('status'))<p class="mt-5 rounded-xl bg-mint p-4 text-sm text-primary">{{ session('status') }}</p>@endif
    <form action="{{ route('password.email') }}" method="POST" class="mt-8 grid gap-5">@csrf<x-field label="Email address" name="email"><input class="form-control" type="email" name="email" value="{{ old('email') }}" required autofocus></x-field><button class="primary-button">Email reset link</button></form>
    <a class="mt-6 inline-block text-sm underline" href="{{ route('login') }}">Back to sign in</a>
</x-layouts.guest>
