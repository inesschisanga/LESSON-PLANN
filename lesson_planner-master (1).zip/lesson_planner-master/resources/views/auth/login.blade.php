@extends('layouts.app')

@section('title', 'Sign in')
@section('content')
    <section class="mx-auto grid min-h-[calc(100vh-180px)] max-w-5xl place-items-center px-5 py-12 sm:px-8">
        <div class="w-full max-w-md">
            <p class="text-xs font-medium uppercase tracking-[.12em] text-graphite">Welcome back</p>
            <h2 class="mt-3 text-4xl font-medium tracking-[-.04em]">Sign in to plan.</h2>
            <div class="mt-7 rounded-[24px] border border-black/5 bg-white p-6 sm:p-9">
                @if (session('status'))<p class="rounded-xl bg-mint p-4 text-sm text-primary">{{ session('status') }}</p>@endif
                <form action="{{ route('login') }}" method="POST" class="grid gap-5">@csrf
                    <x-field label="Email address" name="email"><input class="form-control" type="email" name="email" value="{{ old('email') }}" autocomplete="email" required autofocus></x-field>
                    <x-field label="Password" name="password"><input class="form-control" type="password" name="password" autocomplete="current-password" required></x-field>
                    <div class="flex items-center justify-between gap-4 text-sm"><label class="flex items-center gap-2"><input type="checkbox" name="remember" class="size-4 accent-primary"> Remember me</label><a class="underline" href="{{ route('password.request') }}">Forgot password?</a></div>
                    <button class="primary-button w-full">Sign in</button>
                </form>
                <p class="mt-7 text-sm text-graphite">New to Lesson Studio? <a class="font-medium text-ink underline" href="{{ route('register') }}">Create an account</a></p>
            </div>
        </div>
    </section>
@endsection
