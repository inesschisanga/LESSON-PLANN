@extends('layouts.app')

@section('title', 'Create account')
@section('content')
    <section class="mx-auto grid min-h-[calc(100vh-180px)] max-w-5xl place-items-center px-5 py-12 sm:px-8">
        <div class="w-full max-w-md">
            <p class="text-xs font-medium uppercase tracking-[.12em] text-graphite">Join Lesson Studio</p>
            <h2 class="mt-3 text-4xl font-medium tracking-[-.04em]">Start your workspace.</h2>
            <div class="mt-7 rounded-[24px] border border-black/5 bg-white p-6 sm:p-9">
                <form action="{{ route('register') }}" method="POST" class="grid gap-5">@csrf
                    <x-field label="Full name" name="name"><input class="form-control" name="name" value="{{ old('name') }}" autocomplete="name" required autofocus></x-field>
                    <x-field label="Email address" name="email"><input class="form-control" type="email" name="email" value="{{ old('email') }}" autocomplete="email" required></x-field>
                    <x-field label="Password" name="password"><input class="form-control" type="password" name="password" autocomplete="new-password" required></x-field>
                    <x-field label="Confirm password" name="password_confirmation"><input class="form-control" type="password" name="password_confirmation" autocomplete="new-password" required></x-field>
                    <button class="primary-button w-full">Create account</button>
                </form>
                <p class="mt-7 text-sm text-graphite">Already registered? <a class="font-medium text-ink underline" href="{{ route('login') }}">Sign in</a></p>
            </div>
        </div>
    </section>
@endsection
