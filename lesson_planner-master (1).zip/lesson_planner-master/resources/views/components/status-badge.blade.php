@props(['status'])
@php
    $value = $status instanceof \BackedEnum ? $status->value : (string) $status;
    $label = method_exists($status, 'label') ? $status->label() : str($value)->replace('_', ' ')->title();
    $tone = match ($value) {
        'draft' => 'bg-parchment text-charcoal',
        default => 'bg-parchment text-charcoal',
    };
@endphp
<span {{ $attributes->class("inline-flex rounded-full px-3 py-1 text-xs font-medium {$tone}") }}>{{ $label }}</span>
