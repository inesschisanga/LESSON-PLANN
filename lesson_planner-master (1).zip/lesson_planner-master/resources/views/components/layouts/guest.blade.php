<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1"><meta name="csrf-token" content="{{ csrf_token() }}">
    <link rel="icon" href="{{ asset('favicon.svg') }}" type="image/svg+xml">
    <title>{{ $title ?? 'Welcome' }} · Lesson Studio</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>
<body class="min-h-screen bg-canvas text-ink antialiased selection:bg-primary/20">
    <main class="min-h-screen px-5 py-8 sm:px-8 lg:px-12">
        <a href="{{ route('home') }}" class="mx-auto flex w-fit items-center gap-3 text-lg font-medium" aria-label="Lesson Studio home"><img src="{{ asset('lesson-planner-logo.svg') }}" alt="" class="size-10 object-contain">Lesson Studio</a>
        <section class="grid min-h-[calc(100vh-120px)] place-items-center py-10">
            <div class="w-full max-w-md rounded-[24px] border border-black/5 bg-white p-6 sm:p-9">{{ $slot }}</div>
        </section>
    </main>
</body>
</html>
