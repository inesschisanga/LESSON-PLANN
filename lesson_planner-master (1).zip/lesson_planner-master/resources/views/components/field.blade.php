@props(['label', 'name', 'hint' => null, 'required' => false])
<label class="block">
    <span class="text-sm font-medium">{{ $label }}@if ($required)<span class="ml-1 text-red-600" aria-hidden="true">*</span><span class="sr-only"> required</span>@endif</span>
    {{ $slot }}
    @if ($hint)<span class="mt-1 block text-xs text-graphite">{{ $hint }}</span>@endif
    @error($name)<span class="mt-1 block text-xs font-medium text-red-700">{{ $message }}</span>@enderror
</label>
