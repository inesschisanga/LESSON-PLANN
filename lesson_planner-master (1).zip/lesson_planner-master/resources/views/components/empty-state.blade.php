@props([
    'type' => 'lesson',
    'title' => 'Nothing here yet',
    'description' => '',
    'compact' => false,
])

@php
    $icon = match ($type) {
        'search' => 'search-x',
        'queue' => 'inbox',
        default => 'file-plus-2',
    };
@endphp

<div {{ $attributes->class([$compact ? 'px-5 py-8' : 'px-6 py-12 sm:px-10 sm:py-16', 'grid place-items-center text-center']) }}>
    <div @class(['grid place-items-center rounded-[28px] bg-mint text-primary', 'size-20' => $compact, 'size-28' => ! $compact])>
        <i data-lucide="{{ $icon }}" class="{{ $compact ? 'size-10' : 'size-14' }}" stroke-width="1.5" aria-hidden="true"></i>
    </div>
    <div class="max-w-md">
        <h3 class="{{ $compact ? 'mt-4 text-base' : 'mt-6 text-xl' }} font-medium tracking-tight">{{ $title }}</h3>
        @if ($description)
            <p class="mt-2 text-sm leading-6 text-graphite">{{ $description }}</p>
        @endif
        @if (trim($slot))
            <div class="mt-5 flex flex-wrap justify-center gap-3">{{ $slot }}</div>
        @endif
    </div>
</div>
