<x-layouts.app>
    <x-slot:title>Profile settings</x-slot:title><x-slot:eyebrow>Account settings</x-slot:eyebrow><x-slot:actions><a class="secondary-button gap-2" href="{{ route('dashboard') }}"><i data-lucide="arrow-left" class="size-4" aria-hidden="true"></i><span class="hidden sm:inline">Back to dashboard</span><span class="sm:hidden">Back</span></a></x-slot:actions>
    <div class="grid gap-6 xl:grid-cols-[1.15fr_.85fr]">
        <section class="overflow-hidden rounded-[24px] border border-black/5 bg-white">
            <div class="bg-primary px-6 py-7 text-white sm:px-8">
                <div class="flex items-center gap-4"><img src="{{ route('avatars.show', ['seed' => $user->avatarSeed(), 'size' => 72, 'v' => 'moods']) }}" alt="" class="size-16 rounded-2xl bg-white/20 object-cover ring-4 ring-white/20"><div class="min-w-0"><p class="text-xs font-medium uppercase tracking-[.12em] text-white/70">Your profile</p><h2 class="mt-1 truncate text-2xl font-semibold tracking-tight">{{ $user->name }}</h2><p class="mt-1 truncate text-sm text-white/75">{{ $user->email }}</p></div></div>
                <p class="mt-6 max-w-lg text-sm leading-6 text-white/80">Keep your teaching details current so shared lesson plans have the right context.</p>
            </div>
            <form action="{{ route('profile.update') }}" method="POST" class="grid gap-6 p-6 sm:grid-cols-2 sm:p-8">@csrf @method('PATCH')
                <x-field label="Full name" name="name"><input class="form-control" name="name" value="{{ old('name', $user->name) }}" autocomplete="name" required></x-field>
                <x-field label="School" name="school" hint="Shown with your public lesson plans."><input class="form-control" name="school" value="{{ old('school', $user->school) }}" autocomplete="organization"></x-field>
                <div class="sm:col-span-2"><x-field label="Email address" name="email"><input class="form-control" type="email" name="email" value="{{ old('email', $user->email) }}" autocomplete="email" required></x-field></div>
                <div class="sm:col-span-2 flex flex-wrap items-center justify-between gap-3 border-t border-ash pt-6"><p class="text-xs text-graphite">Your email is used for sign in and account notifications.</p><button class="primary-button">Save profile</button></div>
            </form>
        </section>

        <section class="panel self-start">
            <div><p class="section-kicker">Security</p><h2 class="mt-2 text-2xl font-medium tracking-tight">Update password</h2><p class="mt-2 text-sm leading-6 text-graphite">Choose a new password for your Lesson Studio account.</p></div>
            <form action="{{ route('profile.password.update') }}" method="POST" class="mt-7 grid gap-5">@csrf @method('PUT')
                <x-field label="New password" name="password" hint="Use at least 8 characters."><input class="form-control" type="password" name="password" autocomplete="new-password" required></x-field>
                <x-field label="Confirm new password" name="password_confirmation"><input class="form-control" type="password" name="password_confirmation" autocomplete="new-password" required></x-field>
                <button class="primary-button mt-2 w-full">Update password</button>
            </form>
        </section>
    </div>
</x-layouts.app>
