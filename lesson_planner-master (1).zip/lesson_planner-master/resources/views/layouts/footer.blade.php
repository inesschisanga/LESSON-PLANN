<footer class="bg-ink px-5 py-12 text-white sm:px-8 lg:px-10">
    <div class="mx-auto grid max-w-site gap-10 md:grid-cols-[1fr_auto] md:items-end">
        <div>
            <div class="flex items-center gap-3">
                <img src="{{ asset('lesson-planner-logo.svg') }}" alt="" class="size-9 object-contain">
                <span class="text-lg font-medium">Lesson Studio</span>
            </div>
            <p class="mt-5 max-w-md text-sm leading-6 text-white/55">A focused planning and community workspace for secondary-school ICT teachers.</p>
        </div>
        <div class="flex flex-wrap gap-x-7 gap-y-3 text-sm text-white/70">
            <a href="#workflow" class="hover:text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-mint">Workflow</a>
            <a href="#ai-assistance" class="hover:text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-mint">AI assistance</a>
            <a href="#community" class="hover:text-white focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-mint">Community feed</a>
        </div>
    </div>
    <div class="mx-auto mt-12 flex max-w-site flex-col gap-3 border-t border-white/15 pt-6 text-xs text-white/45 sm:flex-row sm:items-center sm:justify-between">
        <p>© {{ date('Y') }} Lesson Studio.</p>
        <p>Teachers remain in control of every lesson.</p>
    </div>
</footer>
