<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="description" content="@yield('description', 'Lesson Studio helps secondary-school ICT teachers plan, improve, and share lessons in one focused workspace.')">
    <link rel="icon" href="{{ asset('favicon.svg') }}" type="image/svg+xml">
    <title>@yield('title', 'Lesson Studio') · Lesson Studio</title>
    @vite(['resources/css/app.css', 'resources/js/app.js'])
</head>

<body class="bg-canvas text-ink antialiased selection:bg-primary/20">
    @include('layouts.nav')
    @yield('content')
    @include('layouts.footer')
</body>

</html>
