<header class="sticky top-0 z-40 border-b border-black/5 bg-white/95 backdrop-blur">
    <nav class="mx-auto flex max-w-site items-center justify-between gap-5 px-5 py-4 sm:px-8 lg:px-10" aria-label="Primary navigation">
        <a href="{{ route('home') }}" class="flex items-center gap-3 rounded-full focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-primary" aria-label="Lesson Studio home">
            <img src="{{ asset('lesson-planner-logo.svg') }}" alt="" class="size-9 object-contain" aria-hidden="true">
            <span class="text-lg font-medium tracking-tight">Lesson Studio</span>
        </a>
        <div class="flex items-center gap-3">
            @guest
                <a href="{{ route('login') }}" class="hidden text-sm font-medium text-graphite underline-offset-4 hover:text-primary hover:underline sm:inline">Log in</a>
                <a href="{{ route('register') }}" class="hidden min-h-10 items-center justify-center rounded-full bg-primary px-5 text-sm font-medium text-white transition-colors hover:bg-primary-dark focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-primary sm:inline-flex">Sign up</a>
            @endguest
            @auth
                <div data-profile-menu class="relative hidden sm:block">
                    <button type="button" data-profile-toggle class="group flex items-center gap-2 rounded-full border border-transparent py-1 pl-1 pr-2 hover:border-ash hover:bg-canvas" aria-label="Open profile menu" aria-haspopup="menu" aria-expanded="false"><img src="{{ route('avatars.show', ['seed' => auth()->user()->avatarSeed(), 'size' => 36, 'v' => 'moods']) }}" alt="" class="size-9 rounded-full object-cover"><span class="max-w-28 truncate text-xs font-medium text-ink">{{ str(auth()->user()->name)->before(' ') }}</span><i data-lucide="chevron-down" class="size-4 text-graphite" aria-hidden="true"></i></button>
                    <div data-profile-dropdown class="absolute right-0 top-full z-50 mt-2 hidden w-56 overflow-hidden rounded-2xl border border-black/5 bg-white p-2" role="menu"><div class="border-b border-ash px-3 py-2.5"><p class="text-sm font-medium">{{ auth()->user()->name }}</p><p class="mt-0.5 truncate text-xs text-graphite">{{ auth()->user()->email }}</p></div><a href="{{ route('dashboard') }}" class="mt-1 flex items-center gap-3 rounded-xl px-3 py-2.5 text-sm text-graphite hover:bg-mint hover:text-primary" role="menuitem"><i data-lucide="layout-dashboard" class="size-4" aria-hidden="true"></i>Open workspace</a><form action="{{ route('logout') }}" method="POST" class="mt-1">@csrf<button type="submit" class="flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left text-sm text-red-700 hover:bg-red-50 hover:text-red-800" role="menuitem"><i data-lucide="log-out" class="size-4" aria-hidden="true"></i>Log out</button></form></div>
                </div>
            @endauth
            <button type="button" data-nav-toggle class="grid size-10 place-items-center rounded-xl border border-ash text-graphite hover:bg-canvas hover:text-primary md:hidden" aria-label="Open navigation" aria-expanded="false" aria-controls="nav-drawer"><i data-lucide="menu" class="size-5" aria-hidden="true"></i></button>
        </div>
    </nav>
</header>
<aside id="nav-drawer" data-nav-drawer class="fixed inset-y-0 right-0 z-50 w-80 translate-x-full border-l border-black/5 bg-white px-6 py-6 text-ink transition-transform duration-200 ease-out md:hidden">
    <div class="flex items-center justify-between">
        <span class="text-sm font-semibold uppercase tracking-[.12em] text-graphite">Menu</span>
        <button type="button" data-nav-close class="grid size-10 place-items-center rounded-xl text-graphite hover:bg-canvas hover:text-primary" aria-label="Close navigation"><i data-lucide="x" class="size-5" aria-hidden="true"></i></button>
    </div>
    <div class="mt-8 grid gap-3 border-t border-ash pt-8">
        @guest
            <a href="{{ route('login') }}" class="secondary-button w-full">Log in</a>
            <a href="{{ route('register') }}" class="primary-button w-full">Sign up</a>
        @endguest
        @auth
            <a href="{{ route('dashboard') }}" class="primary-button w-full">Open workspace</a>
            <form action="{{ route('logout') }}" method="POST">@csrf<button type="submit" class="secondary-button w-full border-red-200 text-red-700 hover:bg-red-50 hover:text-red-800">Log out</button></form>
        @endauth
    </div>
</aside>
<div data-nav-backdrop class="fixed inset-0 z-40 hidden bg-ink/30 md:hidden"></div>
