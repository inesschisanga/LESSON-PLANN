import {
    ArrowLeft,
    ArrowUpRight,
    CircleAlert,
    ChevronDown,
    ChevronRight,
    createIcons,
    Download,
    Eye,
    EyeOff,
    FilePlus2,
    Files,
    FileText,
    Globe2,
    Heart,
    Inbox,
    LayoutDashboard,
    LogOut,
    Menu,
    MessageCircle,
    PenLine,
    Plus,
    Search,
    SearchX,
    Sparkles,
    Upload,
    UserRound,
    Users,
    X,
} from 'lucide';

const iconSet = {
    ArrowLeft,
    ArrowUpRight,
    CircleAlert,
    ChevronDown,
    ChevronRight,
    Download,
    Eye,
    EyeOff,
    FilePlus2,
    Files,
    FileText,
    Globe2,
    Heart,
    Inbox,
    LayoutDashboard,
    LogOut,
    Menu,
    MessageCircle,
    PenLine,
    Plus,
    Search,
    SearchX,
    Sparkles,
    Upload,
    UserRound,
    Users,
    X,
};

const initializeIcons = () => {
    createIcons({ icons: iconSet, attrs: { 'stroke-width': 1.8 } });
};

initializeIcons();

const initializePasswordToggles = () => {
    document.querySelectorAll('input[type="password"]').forEach((input) => {
        if (input.dataset.passwordToggleInitialized !== undefined) {
            return;
        }

        input.dataset.passwordToggleInitialized = 'true';
        const wrapper = document.createElement('div');
        wrapper.className = 'password-field';
        input.parentNode.insertBefore(wrapper, input);
        wrapper.appendChild(input);
        input.classList.remove('mt-2');
        input.classList.add('pr-12');

        const toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'password-toggle';
        toggle.setAttribute('aria-label', 'Show password');
        toggle.setAttribute('title', 'Show password');
        toggle.innerHTML = '<i data-lucide="eye" class="size-4" aria-hidden="true"></i>';
        wrapper.appendChild(toggle);

        toggle.addEventListener('click', () => {
            const shouldShow = input.type === 'password';
            input.type = shouldShow ? 'text' : 'password';
            toggle.setAttribute('aria-label', shouldShow ? 'Hide password' : 'Show password');
            toggle.setAttribute('title', shouldShow ? 'Hide password' : 'Show password');
            toggle.innerHTML = `<i data-lucide="${shouldShow ? 'eye-off' : 'eye'}" class="size-4" aria-hidden="true"></i>`;
            initializeIcons();
        });
    });

    initializeIcons();
};

initializePasswordToggles();

const initializeLiveSearch = () => {
    document.querySelectorAll('[data-live-search]').forEach((form) => {
        const input = form.querySelector('input[name="search"]');
        const resultsKey = form.dataset.liveSearch;
        const resultsSelector = `[data-live-search-results="${resultsKey}"]`;
        let controller;

        if (!input || !resultsKey || !document.querySelector(resultsSelector)) {
            return;
        }

        let timeout;

        input.addEventListener('input', () => {
            window.clearTimeout(timeout);
            controller?.abort();
            input.setAttribute('aria-busy', 'true');

            timeout = window.setTimeout(async () => {
                const url = new URL(form.action || window.location.href, window.location.origin);
                const params = new URLSearchParams(new FormData(form));
                const search = params.get('search')?.trim() ?? '';

                if (search) {
                    params.set('search', search);
                } else {
                    params.delete('search');
                }

                url.search = params.toString();

                if (url.href === window.location.href) {
                    input.removeAttribute('aria-busy');

                    return;
                }

                controller?.abort();
                controller = new AbortController();

                try {
                    const response = await fetch(url.toString(), {
                        headers: {
                            Accept: 'text/html',
                            'X-Requested-With': 'XMLHttpRequest',
                        },
                        signal: controller.signal,
                    });

                    if (!response.ok) {
                        throw new Error(`Search request failed with status ${response.status}`);
                    }

                    const html = await response.text();
                    const nextDocument = new DOMParser().parseFromString(html, 'text/html');
                    const currentResults = document.querySelector(resultsSelector);
                    const nextResults = nextDocument.querySelector(resultsSelector);

                    if (currentResults && nextResults) {
                        currentResults.replaceWith(nextResults);
                        window.history.replaceState({}, '', url.toString());
                        initializeIcons();
                        input.focus();
                        input.setSelectionRange(input.value.length, input.value.length);
                    }
                } catch (error) {
                    if (error.name !== 'AbortError') {
                        window.location.assign(url.toString());
                    }
                } finally {
                    input.removeAttribute('aria-busy');
                }
            }, 350);
        });
    });
};

initializeLiveSearch();

const initializeLikeForms = () => {
    document.querySelectorAll('[data-like-form]').forEach((form) => {
        if (form.dataset.likeInitialized !== undefined) {
            return;
        }

        form.dataset.likeInitialized = 'true';
        form.addEventListener('submit', async (event) => {
            event.preventDefault();

            const button = form.querySelector('[data-like-button]');
            const token = form.querySelector('input[name="_token"]')?.value;

            if (!button || !token || button.disabled) {
                return;
            }

            button.disabled = true;
            button.setAttribute('aria-busy', 'true');

            try {
                const response = await fetch(form.action, {
                    method: 'POST',
                    headers: {
                        Accept: 'application/json',
                        'X-CSRF-TOKEN': token,
                        'X-Requested-With': 'XMLHttpRequest',
                    },
                    body: new FormData(form),
                });

                if (!response.ok) {
                    throw new Error(`Like request failed with status ${response.status}`);
                }

                const result = await response.json();
                const label = button.querySelector('[data-like-label]');
                const icon = button.querySelector('[data-like-icon]');
                const count = document.querySelector(`[data-like-count="${form.dataset.likeForm}"]`);

                label.textContent = result.liked ? 'Liked' : 'Like';
                button.classList.toggle('text-primary', result.liked);
                button.classList.toggle('text-graphite', !result.liked);
                button.classList.toggle('hover:text-primary', !result.liked);
                button.setAttribute('aria-pressed', String(result.liked));
                icon.classList.toggle('fill-current', result.liked);

                if (count) {
                    count.textContent = result.likes_count;
                }
            } catch (error) {
                if (error.name !== 'AbortError') {
                    console.error(error);
                }
            } finally {
                button.disabled = false;
                button.removeAttribute('aria-busy');
            }
        });
    });
};

initializeLikeForms();

const sidebar = document.querySelector('[data-sidebar]');
const sidebarBackdrop = document.querySelector('[data-sidebar-backdrop]');
const sidebarToggle = document.querySelector('[data-sidebar-toggle]');
const sidebarClose = document.querySelector('[data-sidebar-close]');

const setSidebarOpen = (open) => {
    if (!sidebar || !sidebarBackdrop || !sidebarToggle) {
        return;
    }

    sidebar.classList.toggle('-translate-x-full', !open);
    sidebarBackdrop.classList.toggle('hidden', !open);
    sidebarToggle.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('overflow-hidden', open);
};

sidebarToggle?.addEventListener('click', () => setSidebarOpen(true));
sidebarClose?.addEventListener('click', () => setSidebarOpen(false));
sidebarBackdrop?.addEventListener('click', () => setSidebarOpen(false));
sidebar?.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => setSidebarOpen(false));
});

window.addEventListener('resize', () => {
    if (window.innerWidth >= 1024) {
        setSidebarOpen(false);
    }
});

const navDrawer = document.querySelector('[data-nav-drawer]');
const navBackdrop = document.querySelector('[data-nav-backdrop]');
const navToggle = document.querySelector('[data-nav-toggle]');
const navClose = document.querySelector('[data-nav-close]');

const setNavOpen = (open) => {
    if (!navDrawer || !navBackdrop || !navToggle) {
        return;
    }

    navDrawer.classList.toggle('translate-x-full', !open);
    navBackdrop.classList.toggle('hidden', !open);
    navToggle.setAttribute('aria-expanded', String(open));
    document.body.classList.toggle('overflow-hidden', open);
};

navToggle?.addEventListener('click', () => setNavOpen(true));
navClose?.addEventListener('click', () => setNavOpen(false));
navBackdrop?.addEventListener('click', () => setNavOpen(false));
navDrawer?.querySelectorAll('a').forEach((link) => {
    link.addEventListener('click', () => setNavOpen(false));
});

window.addEventListener('resize', () => {
    if (window.innerWidth >= 768) {
        setNavOpen(false);
    }
});

const profileMenu = document.querySelector('[data-profile-menu]');
const profileToggle = document.querySelector('[data-profile-toggle]');
const profileDropdown = document.querySelector('[data-profile-dropdown]');

const setProfileOpen = (open) => {
    if (!profileMenu || !profileToggle || !profileDropdown) {
        return;
    }

    profileDropdown.classList.toggle('hidden', !open);
    profileToggle.setAttribute('aria-expanded', String(open));
};

profileToggle?.addEventListener('click', () => {
    setProfileOpen(profileToggle.getAttribute('aria-expanded') !== 'true');
});

document.addEventListener('click', (event) => {
    if (profileMenu && !profileMenu.contains(event.target)) {
        setProfileOpen(false);
    }
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        setProfileOpen(false);
    }
});

const newLessonMenuWrapper = document.querySelector('[data-new-lesson-menu-wrapper]');
const newLessonToggle = document.querySelector('[data-new-lesson-toggle]');
const newLessonMenu = document.querySelector('[data-new-lesson-menu]');

const setNewLessonMenuOpen = (open) => {
    if (!newLessonMenuWrapper || !newLessonToggle || !newLessonMenu) {
        return;
    }

    newLessonMenu.classList.toggle('hidden', !open);
    newLessonToggle.setAttribute('aria-expanded', String(open));
};

newLessonToggle?.addEventListener('click', () => {
    setNewLessonMenuOpen(newLessonToggle.getAttribute('aria-expanded') !== 'true');
});

document.addEventListener('click', (event) => {
    if (newLessonMenuWrapper && !newLessonMenuWrapper.contains(event.target)) {
        setNewLessonMenuOpen(false);
    }
});

const generatorModal = document.querySelector('[data-generator-modal]');
const generatorForm = document.querySelector('[data-generator-form]');
const generatorFields = document.querySelector('[data-generator-fields]');
const generatorLoading = document.querySelector('[data-generator-loading]');
const generatorError = document.querySelector('[data-generator-error]');
const generatorErrorMessage = document.querySelector('[data-generator-error-message]');
const generatorErrorList = document.querySelector('[data-generator-error-list]');
const generatorSubmit = document.querySelector('[data-generator-submit]');
const generatorClose = document.querySelector('[data-generator-close]');
const generatorCancel = document.querySelector('[data-generator-cancel]');

const clearGeneratorError = () => {
    generatorError?.classList.add('hidden');

    if (generatorErrorMessage) {
        generatorErrorMessage.textContent = '';
    }

    if (generatorErrorList) {
        generatorErrorList.replaceChildren();
    }
};

const showGeneratorError = (message, errors = {}) => {
    if (!generatorError || !generatorErrorMessage || !generatorErrorList) {
        return;
    }

    setGeneratorLoading(false);
    generatorErrorMessage.textContent = message;
    generatorErrorList.replaceChildren();
    Object.values(errors).flat().forEach((error) => {
        const item = document.createElement('li');
        item.textContent = error;
        generatorErrorList.appendChild(item);
    });
    generatorError.classList.remove('hidden');
};

const setGeneratorLoading = (loading) => {
    generatorLoading?.classList.toggle('hidden', !loading);
    generatorFields?.classList.toggle('hidden', loading);

    if (generatorSubmit) {
        generatorSubmit.disabled = loading;
        generatorSubmit.classList.toggle('hidden', loading);
        generatorSubmit.setAttribute('aria-busy', String(loading));
    }

    generatorClose?.toggleAttribute('disabled', loading);
    generatorCancel?.toggleAttribute('disabled', loading);
};

const resetGenerator = () => {
    generatorForm?.reset();
    clearGeneratorError();
    setGeneratorLoading(false);
};

const setGeneratorOpen = (open) => {
    if (!generatorModal) {
        return;
    }

    if (open) {
        generatorModal.classList.remove('hidden');
        generatorModal.classList.add('grid');
        document.body.classList.add('overflow-hidden');
        window.requestAnimationFrame(() => generatorModal.querySelector('input:not([type="hidden"])')?.focus());
    } else {
        generatorModal.classList.add('hidden');
        generatorModal.classList.remove('grid');
        document.body.classList.remove('overflow-hidden');
        resetGenerator();
    }
};

document.querySelectorAll('[data-open-new-lesson]').forEach((button) => {
    button.addEventListener('click', () => {
        setNewLessonMenuOpen(true);
    });
});

document.querySelectorAll('[data-open-generator]').forEach((button) => {
    button.addEventListener('click', () => {
        setNewLessonMenuOpen(false);
        setGeneratorOpen(true);
    });
});

generatorClose?.addEventListener('click', () => setGeneratorOpen(false));
generatorCancel?.addEventListener('click', () => setGeneratorOpen(false));
generatorModal?.addEventListener('click', (event) => {
    if (event.target === generatorModal && !generatorSubmit?.disabled) {
        setGeneratorOpen(false);
    }
});

document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        setNewLessonMenuOpen(false);

        if (!generatorSubmit?.disabled) {
            setGeneratorOpen(false);
        }
    }
});

generatorForm?.addEventListener('submit', async (event) => {
    event.preventDefault();

    if (!generatorForm.reportValidity()) {
        return;
    }

    clearGeneratorError();
    setGeneratorLoading(true);

    try {
        const response = await fetch(generatorForm.action, {
            method: 'POST',
            headers: {
                Accept: 'application/json',
                'X-CSRF-TOKEN': generatorForm.querySelector('input[name="_token"]')?.value ?? '',
                'X-Requested-With': 'XMLHttpRequest',
            },
            body: new FormData(generatorForm),
        });
        const result = await response.json();

        if (!response.ok) {
            showGeneratorError(result.message ?? 'The lesson could not be generated right now. Please retry.', result.errors ?? {});

            return;
        }

        window.location.assign(result.redirect_url);
    } catch (error) {
        console.error(error);
        showGeneratorError('The lesson could not be generated right now. Please check your connection and retry.');
    }
});

const lessonModals = document.querySelectorAll('[data-lesson-modal]');

const setLessonModalOpen = (id, open) => {
    const modal = document.querySelector(`[data-lesson-modal="${id}"]`);

    if (!modal) {
        return;
    }

    modal.classList.toggle('hidden', !open);
    modal.classList.toggle('flex', open);
    document.body.classList.toggle('overflow-hidden', open);
};

document.querySelectorAll('[data-open-lesson]').forEach((button) => {
    button.addEventListener('click', () => setLessonModalOpen(button.dataset.openLesson, true));
});
document.querySelectorAll('[data-close-lesson]').forEach((button) => {
    button.addEventListener('click', () => setLessonModalOpen(button.dataset.closeLesson, false));
});
lessonModals.forEach((modal) => {
    modal.addEventListener('click', (event) => {
        if (event.target === modal) {
            setLessonModalOpen(modal.dataset.lessonModal, false);
        }
    });
});
document.addEventListener('keydown', (event) => {
    if (event.key === 'Escape') {
        lessonModals.forEach((modal) => setLessonModalOpen(modal.dataset.lessonModal, false));
    }
});

document.querySelectorAll('form').forEach((form) => {
    form.addEventListener('submit', (event) => {
        const submitter = event.submitter;

        if (!submitter || submitter.dataset.noLoading !== undefined) {
            return;
        }

        submitter.disabled = true;
        submitter.setAttribute('aria-busy', 'true');
        submitter.dataset.originalLabel = submitter.textContent.trim();
        submitter.innerHTML = '<span class="loading-spinner" aria-hidden="true"></span><span>Working…</span>';
    });
});
