<?php

namespace Tests\Feature;

use App\Models\LessonPlan;
use App\Models\LessonPlanVersion;
use App\Models\User;
use App\Services\LessonPlanDocxService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;
use ZipArchive;

class LessonPlanExportTest extends TestCase
{
    use RefreshDatabase;

    public function test_teacher_can_download_a_docx_containing_the_lesson_evaluation(): void
    {
        $user = User::factory()->create();
        $plan = LessonPlan::factory()->for($user)->create();
        $version = LessonPlanVersion::factory()->for($plan)->create(['created_by' => $user->id]);

        $this->actingAs($user)->get(route('lesson-plans.export', $plan))->assertDownload();

        $path = app(LessonPlanDocxService::class)->generate($version->content);
        $zip = new ZipArchive;
        $this->assertTrue($zip->open($path));
        $document = $zip->getFromName('word/document.xml');
        $zip->close();
        unlink($path);

        $this->assertIsString($document);
        $this->assertStringContainsString('LESSON EVALUATION', $document);
        $this->assertStringContainsString('Most learners explained', $document);
    }
}
