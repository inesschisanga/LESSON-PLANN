<?php

namespace Tests\Feature;

use App\Models\LessonPlan;
use App\Models\LessonPlanVersion;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class LessonPlanManagementTest extends TestCase
{
    use RefreshDatabase;

    public function test_teacher_can_create_and_version_a_complete_lesson_plan(): void
    {
        $user = User::factory()->create();
        $content = LessonPlanVersion::factory()->make(['created_by' => $user->id])->content;
        $response = $this->actingAs($user)->post(route('lesson-plans.store'), $content);

        $plan = LessonPlan::query()->latest('id')->firstOrFail();
        $response->assertRedirect(route('lesson-plans.show', $plan));
        $this->assertDatabaseHas('lesson_plan_versions', ['lesson_plan_id' => $plan->id, 'version_number' => 1]);

        $content['lesson'] = 'Improved introduction to networks';
        $this->actingAs($user)->put(route('lesson-plans.update', $plan), $content)->assertRedirect();
        $this->assertDatabaseHas('lesson_plan_versions', ['lesson_plan_id' => $plan->id, 'version_number' => 2]);
        $this->assertSame('Improved introduction to networks', $plan->fresh()->title);
    }

    public function test_teacher_cannot_edit_another_teachers_lesson(): void
    {
        $owner = User::factory()->create();
        $intruder = User::factory()->create();
        $plan = LessonPlan::factory()->for($owner)->create();
        LessonPlanVersion::factory()->for($plan)->create(['created_by' => $owner->id]);

        $this->actingAs($intruder)->get(route('lesson-plans.edit', $plan))->assertForbidden();
    }
}
