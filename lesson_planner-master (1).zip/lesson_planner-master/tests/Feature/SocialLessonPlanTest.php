<?php

namespace Tests\Feature;

use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use App\Models\LessonPlanVersion;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\DB;
use Tests\TestCase;

class SocialLessonPlanTest extends TestCase
{
    use RefreshDatabase;

    public function test_user_avatars_are_rendered_as_same_origin_svg_images(): void
    {
        $response = $this->get(route('avatars.show', ['seed' => 'Mainza Namz', 'size' => 40]));

        $response->assertOk()
            ->assertHeader('Content-Type', 'image/svg+xml; charset=UTF-8')
            ->assertSee('<svg', false)
            ->assertSee('Mainza Namz', false);
    }

    public function test_legacy_lesson_statuses_are_read_as_drafts(): void
    {
        $plan = LessonPlan::factory()->create();
        DB::table('lesson_plans')->where('id', $plan->id)->update(['status' => 'under_review']);

        $this->assertSame('draft', $plan->fresh()->status->value);
    }

    public function test_lesson_library_loads_the_current_version_without_an_ambiguous_column(): void
    {
        $owner = User::factory()->create();
        $plan = LessonPlan::factory()->for($owner)->create();
        LessonPlanVersion::factory()->for($plan)->create(['created_by' => $owner->id]);

        $this->actingAs($owner)->get(route('lesson-plans.index'))
            ->assertOk()
            ->assertSee($plan->title);
    }

    public function test_lesson_library_can_filter_by_visibility(): void
    {
        $owner = User::factory()->create();
        $publicPlan = LessonPlan::factory()->for($owner)->create(['visibility' => LessonPlanVisibility::Public, 'title' => 'Public networks lesson']);
        $privatePlan = LessonPlan::factory()->for($owner)->create(['visibility' => LessonPlanVisibility::Private, 'title' => 'Private spreadsheets lesson']);
        LessonPlanVersion::factory()->for($publicPlan)->create(['created_by' => $owner->id]);
        LessonPlanVersion::factory()->for($privatePlan)->create(['created_by' => $owner->id]);

        $this->actingAs($owner)->get(route('lesson-plans.index', ['visibility' => 'public']))
            ->assertOk()
            ->assertSee($publicPlan->title)
            ->assertDontSee($privatePlan->title);
    }

    public function test_public_lessons_are_visible_in_the_community_and_can_be_liked_and_commented_on(): void
    {
        $owner = User::factory()->create();
        $visitor = User::factory()->create();
        $plan = LessonPlan::factory()->for($owner)->create(['visibility' => LessonPlanVisibility::Public]);
        LessonPlanVersion::factory()->for($plan)->create(['created_by' => $owner->id]);

        $this->actingAs($visitor)->get(route('community.index'))
            ->assertOk()
            ->assertSee($plan->title);
        $this->actingAs($visitor)->post(route('lesson-plans.like', $plan))->assertRedirect();
        $this->actingAs($visitor)->post(route('lesson-plans.comments.store', $plan), ['body' => 'Useful sequence.'])->assertRedirect();

        $this->assertDatabaseHas('lesson_plan_likes', ['lesson_plan_id' => $plan->id, 'user_id' => $visitor->id]);
        $this->assertDatabaseHas('lesson_plan_comments', ['lesson_plan_id' => $plan->id, 'user_id' => $visitor->id, 'body' => 'Useful sequence.']);
    }

    public function test_likes_can_be_toggled_without_a_full_page_response(): void
    {
        $owner = User::factory()->create();
        $visitor = User::factory()->create();
        $plan = LessonPlan::factory()->for($owner)->create(['visibility' => LessonPlanVisibility::Public]);

        $this->actingAs($visitor)
            ->withHeaders(['Accept' => 'application/json', 'X-Requested-With' => 'XMLHttpRequest'])
            ->post(route('lesson-plans.like', $plan))
            ->assertOk()
            ->assertJson(['liked' => true, 'likes_count' => 1]);

        $this->actingAs($visitor)
            ->withHeaders(['Accept' => 'application/json', 'X-Requested-With' => 'XMLHttpRequest'])
            ->post(route('lesson-plans.like', $plan))
            ->assertOk()
            ->assertJson(['liked' => false, 'likes_count' => 0]);
    }

    public function test_community_search_filters_public_lessons(): void
    {
        $owner = User::factory()->create();
        $matching = LessonPlan::factory()->for($owner)->create(['visibility' => LessonPlanVisibility::Public, 'title' => 'Networks in the classroom']);
        $other = LessonPlan::factory()->for($owner)->create(['visibility' => LessonPlanVisibility::Public, 'title' => 'Spreadsheet formulas']);
        LessonPlanVersion::factory()->for($matching)->create(['created_by' => $owner->id]);
        LessonPlanVersion::factory()->for($other)->create(['created_by' => $owner->id]);

        $this->actingAs(User::factory()->create())->get(route('community.index', ['search' => 'Networks in']))
            ->assertOk()
            ->assertSee($matching->title)
            ->assertDontSee($other->title);
    }

    public function test_private_lessons_stay_out_of_the_community(): void
    {
        $owner = User::factory()->create();
        $plan = LessonPlan::factory()->for($owner)->create(['visibility' => LessonPlanVisibility::Private]);
        LessonPlanVersion::factory()->for($plan)->create(['created_by' => $owner->id]);

        $this->actingAs(User::factory()->create())->get(route('community.index'))
            ->assertOk()
            ->assertDontSee($plan->title);
    }
}
