<?php

namespace Tests\Feature;

use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AuthenticationTest extends TestCase
{
    use RefreshDatabase;

    public function test_guest_can_open_the_login_page(): void
    {
        $this->get(route('login'))
            ->assertOk()
            ->assertSee('Sign in to plan.')
            ->assertSee('Forgot password?');
    }

    public function test_teacher_can_register_and_is_authenticated(): void
    {
        $response = $this->post(route('register'), [
            'name' => 'Natasha Phiri',
            'email' => 'natasha@example.test',
            'password' => 'password',
            'password_confirmation' => 'password',
        ]);

        $response->assertRedirect(route('dashboard'));
        $this->assertAuthenticated();
        $user = User::where('email', 'natasha@example.test')->firstOrFail();
        $this->assertNull($user->school);
        $this->assertNotEmpty($user->avatar_seed);
    }

    public function test_teacher_can_sign_in_and_sign_out(): void
    {
        $user = User::factory()->create(['password' => 'password']);

        $this->post(route('login'), ['email' => $user->email, 'password' => 'password'])
            ->assertRedirect(route('dashboard'));
        $this->assertAuthenticatedAs($user);

        $this->post(route('logout'))->assertRedirect(route('home'));
        $this->assertGuest();
    }

    public function test_guests_are_redirected_away_from_the_workspace(): void
    {
        foreach ([
            route('dashboard'),
            route('profile.edit'),
            route('lesson-plans.index'),
            route('lesson-plans.generate'),
            route('community.index'),
            route('admin.users.index'),
        ] as $url) {
            $this->get($url)->assertRedirect(route('login'));
        }
    }

    public function test_authenticated_teachers_are_redirected_from_guest_auth_pages(): void
    {
        $user = User::factory()->create();

        $this->actingAs($user)->get(route('login'))->assertRedirect(route('dashboard'));
        $this->actingAs($user)->get(route('register'))->assertRedirect(route('dashboard'));
    }

    public function test_authenticated_dashboard_shows_school_onboarding_when_profile_is_incomplete(): void
    {
        $user = User::factory()->create(['school' => null]);

        $this->actingAs($user)
            ->get(route('dashboard'))
            ->assertOk()
            ->assertSee('Complete your profile')
            ->assertSee('Add your school so lesson plans have the right context.');
    }
}
