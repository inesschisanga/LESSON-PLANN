<?php

namespace Tests\Feature;

use App\Contracts\LessonPlanGenerator;
use App\Models\LessonPlanVersion;
use App\Models\User;
use App\Services\LessonPlannerService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Config;
use Illuminate\Support\Facades\Http;
use Tests\TestCase;

class GeneratedLessonPlanTest extends TestCase
{
    use RefreshDatabase;

    public function test_generated_lesson_is_stored_in_session_for_teacher_check(): void
    {
        $user = User::factory()->create();
        $generated = LessonPlanVersion::factory()->make(['created_by' => $user->id])->content;
        $fake = $this->mock(LessonPlanGenerator::class);
        $fake->shouldReceive('generate')->once()->withArgs(fn (array $input) => $input['topic'] === 'Networks')->andReturn($generated);

        $response = $this->actingAs($user)->post(route('lesson-plans.generate.store'), [
            'school' => 'Kamwala Secondary', 'teacher' => $user->name,
            'subject' => 'ICT', 'class' => 'Form 3', 'topic' => 'Networks', 'lesson' => 'LAN basics',
            'duration' => 40, 'references' => 'ICT syllabus',
            'prior_knowledge' => 'Computer hardware', 'teaching_materials' => 'Computers',
        ]);

        $response->assertRedirect(route('lesson-plans.generated.preview'));
        $response->assertSessionHas('generated_lesson_plan', $generated);
    }

    public function test_modal_generation_request_returns_preview_url_as_json(): void
    {
        $user = User::factory()->create();
        $generated = LessonPlanVersion::factory()->make(['created_by' => $user->id])->content;
        $fake = $this->mock(LessonPlanGenerator::class);
        $fake->shouldReceive('generate')->once()->andReturn($generated);

        $response = $this->actingAs($user)
            ->withHeaders(['Accept' => 'application/json', 'X-Requested-With' => 'XMLHttpRequest'])
            ->post(route('lesson-plans.generate.store'), [
                'school' => 'Kamwala Secondary', 'teacher' => $user->name,
                'subject' => 'ICT', 'class' => 'Form 3', 'topic' => 'Networks', 'lesson' => 'LAN basics',
                'duration' => 40, 'references' => 'ICT syllabus',
                'prior_knowledge' => 'Computer hardware', 'teaching_materials' => 'Computers',
            ]);

        $response->assertOk()->assertJsonPath('redirect_url', route('lesson-plans.generated.preview', [], false));
    }

    public function test_google_response_normalizes_date_and_duration_before_schema_validation(): void
    {
        Config::set('services.google_ai.api_key', 'test-key');
        Config::set('services.google_ai.model', 'test-model');

        $generated = LessonPlanVersion::factory()->make()->content;
        $generated['date'] = 'not-a-date';
        $generated['duration'] = '40 minutes';

        Http::fake([
            'https://generativelanguage.googleapis.com/*' => Http::response([
                'candidates' => [['content' => ['parts' => [['text' => json_encode($generated)]]]]],
            ], 200),
        ]);

        $plan = app(LessonPlannerService::class)->generate([
            'school' => 'Kamwala Secondary', 'teacher' => 'Teacher', 'date' => '2026-10-10',
            'subject' => 'ICT', 'class' => 'Form 3', 'topic' => 'Networks', 'lesson' => 'LAN basics',
            'duration' => 40, 'references' => 'ICT syllabus',
            'prior_knowledge' => 'Computer hardware', 'teaching_materials' => 'Computers',
        ]);

        $this->assertSame('2026-10-10', $plan['date']);
        $this->assertSame(40, $plan['duration']);
    }
}
