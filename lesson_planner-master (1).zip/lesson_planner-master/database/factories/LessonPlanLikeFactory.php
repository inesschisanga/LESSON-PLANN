<?php

namespace Database\Factories;

use App\Models\LessonPlan;
use App\Models\LessonPlanLike;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<LessonPlanLike>
 */
class LessonPlanLikeFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'lesson_plan_id' => LessonPlan::factory(),
            'user_id' => User::factory(),
        ];
    }
}
