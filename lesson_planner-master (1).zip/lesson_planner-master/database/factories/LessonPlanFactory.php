<?php

namespace Database\Factories;

use App\LessonPlanStatus;
use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use App\Models\User;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<LessonPlan>
 */
class LessonPlanFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'user_id' => User::factory(),
            'title' => 'Introduction to computer networks',
            'topic' => 'Computer networks',
            'class_level' => 'Form 3',
            'lesson_date' => now()->addWeek()->toDateString(),
            'duration_minutes' => 40,
            'status' => LessonPlanStatus::Draft,
            'visibility' => LessonPlanVisibility::Private,
        ];
    }
}
