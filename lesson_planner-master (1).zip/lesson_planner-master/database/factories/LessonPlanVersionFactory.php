<?php

namespace Database\Factories;

use App\Models\LessonPlan;
use App\Models\LessonPlanVersion;
use App\Models\User;
use App\Support\LessonPlanSchema;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<LessonPlanVersion>
 */
class LessonPlanVersionFactory extends Factory
{
    /**
     * Define the model's default state.
     *
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $content = LessonPlanSchema::blank();
        $content['school'] = 'Kamwala Secondary School';
        $content['teacher'] = fake()->name();
        $content['class'] = 'Form 3';
        $content['topic'] = 'Computer networks';
        $content['lesson'] = 'Introduction to local area networks';
        $content['lesson_components']['general_competence'] = 'Use digital systems safely and effectively.';
        $content['lesson_components']['specific_competence'] = 'Explain how devices communicate on a local network.';
        $content['lesson_components']['lesson_goal'] = 'Understand the purpose and basic structure of a local network.';
        $content['lesson_components']['rationale'] = 'Network literacy supports practical ICT use.';
        $content['lesson_components']['prior_knowledge'] = 'Learners can identify common computer hardware.';
        $content['lesson_components']['references'] = ['Zambian Secondary School ICT Syllabus'];
        $content['lesson_components']['teaching_materials'] = ['Network diagram', 'Computers'];
        $content['lesson_components']['expected_standards'] = ['Learners accurately identify network components.'];
        $content['lesson_evaluation'] = ['Most learners explained the data path correctly.'];

        foreach ($content['teaching_learning_activities'] as $index => $activity) {
            $content['teaching_learning_activities'][$index]['duration'] = $index === 1 ? '20 minutes' : '5 minutes';
            $content['teaching_learning_activities'][$index]['teacher_activity'] = 'Guide the '.mb_strtolower($activity['stage']).' activity.';
            $content['teaching_learning_activities'][$index]['learner_activity'] = 'Complete the '.mb_strtolower($activity['stage']).' task.';
            $content['teaching_learning_activities'][$index]['assessment_criteria'] = 'Learners demonstrate the expected skill.';
        }

        return [
            'lesson_plan_id' => LessonPlan::factory(),
            'version_number' => 1,
            'content' => $content,
            'created_by' => User::factory(),
        ];
    }
}
