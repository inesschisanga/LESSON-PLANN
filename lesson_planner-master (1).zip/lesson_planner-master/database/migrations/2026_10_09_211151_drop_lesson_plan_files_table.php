<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::dropIfExists('lesson_plan_files');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Removed feature is intentionally not restored.
    }
};
