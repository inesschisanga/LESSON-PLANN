<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::dropIfExists('reviews');
        Schema::dropIfExists('review_submissions');
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        // Removed tables are intentionally not restored.
    }
};
