<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    /**
     * Run the migrations.
     */
    public function up(): void
    {
        Schema::create('lesson_plans', function (Blueprint $table) {
            $table->id();
            $table->foreignId('user_id')->constrained()->cascadeOnDelete();
            $table->string('title');
            $table->string('topic');
            $table->string('class_level');
            $table->date('lesson_date')->nullable();
            $table->unsignedSmallInteger('duration_minutes');
            $table->string('status')->default('draft');
            $table->timestamps();

            $table->index(['user_id', 'status', 'updated_at']);
            $table->index(['user_id', 'topic']);
        });
    }

    /**
     * Reverse the migrations.
     */
    public function down(): void
    {
        Schema::dropIfExists('lesson_plans');
    }
};
