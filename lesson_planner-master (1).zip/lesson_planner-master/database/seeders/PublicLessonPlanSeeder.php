<?php

namespace Database\Seeders;

use App\LessonPlanStatus;
use App\LessonPlanVisibility;
use App\Models\LessonPlan;
use App\Models\LessonPlanVersion;
use App\Models\User;
use App\Support\LessonPlanSchema;
use Illuminate\Database\Seeder;

class PublicLessonPlanSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        foreach ($this->lessons() as $lesson) {
            $user = User::firstOrCreate(
                ['email' => $lesson['email']],
                [
                    'name' => $lesson['teacher'],
                    'school' => $lesson['school'],
                    'password' => 'password',
                ],
            );

            $plan = LessonPlan::updateOrCreate(
                [
                    'user_id' => $user->id,
                    'title' => $lesson['title'],
                ],
                [
                    'topic' => $lesson['topic'],
                    'class_level' => $lesson['class'],
                    'lesson_date' => $lesson['date'],
                    'duration_minutes' => $lesson['duration'],
                    'status' => LessonPlanStatus::Draft,
                    'visibility' => LessonPlanVisibility::Public,
                ],
            );

            LessonPlanVersion::updateOrCreate(
                [
                    'lesson_plan_id' => $plan->id,
                    'version_number' => 1,
                ],
                [
                    'content' => $this->content($lesson),
                    'created_by' => $user->id,
                ],
            );
        }
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function lessons(): array
    {
        return [
            [
                'email' => 'amina.banda@lessonplanner.test',
                'teacher' => 'Amina Banda',
                'school' => 'Kamwala Secondary School',
                'title' => 'Introduction to local area networks',
                'topic' => 'Computer networks',
                'class' => 'Form 3',
                'duration' => 40,
                'date' => now()->addDays(3)->toDateString(),
                'goal' => 'Learners explain the purpose of a local area network and identify the devices that connect computers in a classroom.',
                'prior_knowledge' => 'Learners can identify common computer hardware and describe how files are stored.',
                'materials' => ['Network diagram', 'Router and switch images', 'Sticky notes'],
                'references' => ['Zambian Secondary School ICT Syllabus', 'School ICT handbook'],
            ],
            [
                'email' => 'brian.phiri@lessonplanner.test',
                'teacher' => 'Brian Phiri',
                'school' => 'Matero Boys Secondary School',
                'title' => 'Spreadsheet formulas for a household budget',
                'topic' => 'Spreadsheet formulas',
                'class' => 'Form 2',
                'duration' => 40,
                'date' => now()->addDays(5)->toDateString(),
                'goal' => 'Learners use SUM, AVERAGE, and simple arithmetic formulas to build and interpret a household budget.',
                'prior_knowledge' => 'Learners can enter data into rows and columns and format a basic spreadsheet.',
                'materials' => ['Computer lab', 'Budget worksheet', 'Projector'],
                'references' => ['Zambian Secondary School ICT Syllabus', 'Spreadsheet software help guide'],
            ],
            [
                'email' => 'chipo.mulenga@lessonplanner.test',
                'teacher' => 'Chipo Mulenga',
                'school' => 'Chilenje Secondary School',
                'title' => 'Digital footprints and cyber safety',
                'topic' => 'Cyber safety',
                'class' => 'Form 1',
                'duration' => 35,
                'date' => now()->addDays(8)->toDateString(),
                'goal' => 'Learners describe how online actions create a digital footprint and choose safer responses to common online risks.',
                'prior_knowledge' => 'Learners use phones or shared computers to access websites and messaging services.',
                'materials' => ['Scenario cards', 'Cyber safety poster', 'Board markers'],
                'references' => ['Zambian Secondary School ICT Syllabus', 'Child online safety guidance'],
            ],
            [
                'email' => 'esther.tembo@lessonplanner.test',
                'teacher' => 'Esther Tembo',
                'school' => 'Mandevu Secondary School',
                'title' => 'Designing tables for a school library database',
                'topic' => 'Database design',
                'class' => 'Form 4',
                'duration' => 45,
                'date' => now()->addDays(10)->toDateString(),
                'goal' => 'Learners organise library information into related tables and explain why consistent fields improve data quality.',
                'prior_knowledge' => 'Learners understand rows, columns, and the difference between text and numeric data.',
                'materials' => ['Library record cards', 'Database diagram', 'Exercise sheet'],
                'references' => ['Zambian Secondary School ICT Syllabus', 'Introductory database notes'],
            ],
            [
                'email' => 'luka.sikazwe@lessonplanner.test',
                'teacher' => 'Luka Sikazwe',
                'school' => 'Kalingalinga Secondary School',
                'title' => 'Web page structure with HTML',
                'topic' => 'Web design fundamentals',
                'class' => 'Form 3',
                'duration' => 40,
                'date' => now()->addDays(12)->toDateString(),
                'goal' => 'Learners create a simple web page using headings, paragraphs, links, and an accessible page structure.',
                'prior_knowledge' => 'Learners can save text files and navigate folders using a file manager.',
                'materials' => ['Text editor', 'HTML reference card', 'Browser'],
                'references' => ['Zambian Secondary School ICT Syllabus', 'HTML element reference'],
            ],
            [
                'email' => 'mutinta.zulu@lessonplanner.test',
                'teacher' => 'Mutinta Zulu',
                'school' => 'Libala Secondary School',
                'title' => 'Algorithms and flowcharts for everyday tasks',
                'topic' => 'Algorithms and flowcharts',
                'class' => 'Form 2',
                'duration' => 40,
                'date' => now()->addDays(15)->toDateString(),
                'goal' => 'Learners write a sequence of precise steps and represent the sequence using standard flowchart symbols.',
                'prior_knowledge' => 'Learners can describe familiar routines in the correct order.',
                'materials' => ['Flowchart symbol cards', 'Large paper', 'Markers'],
                'references' => ['Zambian Secondary School ICT Syllabus', 'Problem-solving activity guide'],
            ],
        ];
    }

    /**
     * @param  array<string, mixed>  $lesson
     * @return array<string, mixed>
     */
    private function content(array $lesson): array
    {
        $content = LessonPlanSchema::blank();
        $content['school'] = $lesson['school'];
        $content['teacher'] = $lesson['teacher'];
        $content['date'] = $lesson['date'];
        $content['class'] = $lesson['class'];
        $content['duration'] = $lesson['duration'];
        $content['topic'] = $lesson['topic'];
        $content['lesson'] = $lesson['title'];
        $content['enrollment'] = ['boys' => 24, 'girls' => 26];
        $content['visibility'] = LessonPlanVisibility::Public->value;
        $content['lesson_components'] = array_merge($content['lesson_components'], [
            'general_competence' => 'Apply ICT concepts to solve practical classroom and everyday problems.',
            'specific_competence' => 'Communicate an ICT idea clearly using appropriate terms, examples, and representations.',
            'lesson_goal' => $lesson['goal'],
            'rationale' => 'The lesson connects ICT concepts to practical situations learners recognise and can discuss.',
            'prior_knowledge' => $lesson['prior_knowledge'],
            'references' => $lesson['references'],
            'teaching_materials' => $lesson['materials'],
            'expected_standards' => ['Learners explain the main idea accurately and complete the practical activity with limited support.'],
        ]);
        $content['teaching_learning_activities'] = [
            ['stage' => 'Introduction', 'duration' => '5 minutes', 'teacher_activity' => 'Connect the lesson topic to a familiar classroom or home example.', 'learner_activity' => 'Share prior experiences and respond to opening questions.', 'assessment_criteria' => 'Learners contribute a relevant example.'],
            ['stage' => 'Lesson Development', 'duration' => '15 minutes', 'teacher_activity' => 'Model the main concept using the prepared examples and explain each step.', 'learner_activity' => 'Observe the model, ask questions, and record key points.', 'assessment_criteria' => 'Learners identify the key parts of the concept.'],
            ['stage' => 'Class Exercise', 'duration' => '12 minutes', 'teacher_activity' => 'Guide pairs through a practical task and provide targeted prompts.', 'learner_activity' => 'Complete the task collaboratively and compare answers.', 'assessment_criteria' => 'Learners apply the concept correctly in the exercise.'],
            ['stage' => 'Conclusion', 'duration' => '5 minutes', 'teacher_activity' => 'Review the main idea and invite learners to explain the most important step.', 'learner_activity' => 'Summarise the lesson in their own words.', 'assessment_criteria' => 'Learners state the central idea clearly.'],
            ['stage' => 'Homework', 'duration' => '3 minutes', 'teacher_activity' => 'Set a short extension activity linked to the lesson goal.', 'learner_activity' => 'Record the task and ask clarifying questions.', 'assessment_criteria' => 'Learners can explain what they will practise next.'],
        ];
        $content['lesson_evaluation'] = ['Most learners met the expected standard during the practical activity.'];

        return $content;
    }
}
